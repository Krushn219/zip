export const CARS = [
  {
    id: 1,
    brand: 'BMW',
    color: 'gold',
    model: 'BMW X5',
  },
];
