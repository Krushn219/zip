import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Project } from 'src/project/entities/project.entity';
import { ProjectService } from 'src/project/project.service';
import { Repository } from 'typeorm';
import { EmployeeCreateDTO } from './dto/create.employee.input';
import { Employee } from './entities/employee.entity';

@Injectable()
export class EmployeeService {
  constructor(
    @InjectRepository(Employee)
    private employeeRepository: Repository<Employee>,
    private projectService: ProjectService,
  ) {}

  async findAll(): Promise<Employee[]> {
    return this.employeeRepository.find();
  }

  async create(employee: EmployeeCreateDTO): Promise<Employee> {
    const emp = this.employeeRepository.create(employee); //shared DTO
    return this.employeeRepository.save(emp);
  }

  async findOne(id: any) {
    return this.employeeRepository.findOne({ where: { id: id } });
  }

  async getProject(id: string): Promise<Project> {
    //to resolve project data || to fetch data from projectID stored in employee schema
    return this.projectService.findOne(id);
  }
}
