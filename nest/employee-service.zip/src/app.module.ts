import { Module } from '@nestjs/common';
import { EmployeeModule } from './employee/employee.module';
import { MongooseModule } from '@nestjs/mongoose';
import { MONGOOSE_CONNECTION } from './employee/app.properties';

@Module({
  imports: [EmployeeModule, MongooseModule.forRoot(MONGOOSE_CONNECTION)],
})
export class AppModule {}
