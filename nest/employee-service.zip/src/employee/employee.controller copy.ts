// import {
//   Body,
//   Controller,
//   Delete,
//   Get,
//   NotFoundException,
//   Param,
//   Post,
//   Put,
//   Query,
//   UsePipes,
//   ValidationPipe,
// } from '@nestjs/common';
// import { EmployeeTierValidationPipe } from 'src/employee-tier-validation.pipe';
// import { EmployeeStatus, EmployeeTier } from './Employee.enum';
// import { EmployeeService } from './employee.service';
// import { EmployeeCreateDto } from './EmployeeCreate.dto';
// import { EmployeeSearchDto } from './EmployeeSearch.dto';
// import { EmployeeUpdateDto } from './EmployeeUpdate.dto';

// @Controller('employee')
// export class EmployeeController {
//   constructor(private employeeService: EmployeeService) {}

//   //   @Get()
//   //   getServer() {
//   //     return 'Hello..';
//   //   }

//   @Get()
//   @UsePipes(ValidationPipe)
//   getAllEmployee(@Query() param: EmployeeSearchDto) {
//     if (Object.keys(param).length) {
//       //   console.log('filter');
//       return this.employeeService.employeeSearch(param);
//     } else {
//       //   console.log(param);
//       return this.employeeService.getAllEmployees();
//     }
//   }

//   @Post()
//   @UsePipes(ValidationPipe)
//   @UsePipes(new EmployeeTierValidationPipe())
//   createEmployee(@Body() employeeCreateDto: EmployeeCreateDto) {
//     return this.employeeService.createEmployee(employeeCreateDto);
//     // return this.employeeService;
//   }

//   @Get(':id')
//   getEmployeeById(@Param('id') id: string) {
//     return this.employeeService.getEmployeeById(id);
//   }

//   @Put('/:id/city')
//   updateEmployee(
//     @Param('id') id: string,
//     @Body() employeeUpdateDto: EmployeeUpdateDto,
//   ) {
//     employeeUpdateDto.id = id;
//     return this.employeeService.updateEmployee(employeeUpdateDto);
//   }

//   @Delete('/:id')
//   deleteEmployee(@Param('id') id: string) {
//     if (!this.employeeService.deleteEmployee(id)) {
//       throw new NotFoundException('Employee Does not Exists');
//     }
//     return 'Deleted Success..';
//   }
// }
