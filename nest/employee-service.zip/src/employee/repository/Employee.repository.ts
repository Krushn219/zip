import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Employee, EmployeeDocument } from '../schemas/Employee.schema';
import { Model } from 'mongoose';
import { EmployeeCreateDto } from '../dto/EmployeeCreate.dto';

@Injectable()
export class EmployeeRepository {
  constructor(
    @InjectModel(Employee.name) private employeeModel: Model<EmployeeDocument>,
  ) {}

  async create(createEmployeeDTO: EmployeeCreateDto): Promise<Employee> {
    const newEmployee = new this.employeeModel(createEmployeeDTO);

    return newEmployee.save();
  }

  async findAll(): Promise<Employee[]> {
    return await this.employeeModel.find();
  }
}
