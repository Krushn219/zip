import { IsNotEmpty } from 'class-validator';

export class VehicleCreateDTO {
  id: string;
  @IsNotEmpty()
  make: string;
  model: string;
  vin: string;
  @IsNotEmpty()
  employeeId: string;
}
