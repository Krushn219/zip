export interface EmployeeUpdateDto {
  id: string;
  city: string;
}
