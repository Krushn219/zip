import { Injectable, NotFoundException } from '@nestjs/common';
import { EmployeeStatus, EmployeeTier } from '../Employee.enum';
import { v1 as uuid } from 'uuid';
import { EmployeeUpdateDto } from '../dto/EmployeeUpdate.dto';
import { EmployeeCreateDto } from '../dto/EmployeeCreate.dto';
import { Employee } from '../schemas/Employee.schema';
import { EmployeeRepository } from '../repository/Employee.repository';

@Injectable()
export class EmployeeService {
  // private employees: Employee[] = [];

  constructor(private employeeRepository: EmployeeRepository) {}

  async getAllEmployees(): Promise<Employee[]> {
    return this.employeeRepository.findAll();
  }

  async createEmployee(
    employeeCreateDto: EmployeeCreateDto,
  ): Promise<Employee> {
    return this.employeeRepository.create(employeeCreateDto);
  }
}
