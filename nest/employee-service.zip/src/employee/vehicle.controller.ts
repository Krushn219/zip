import { Body, Controller, Get, Post } from '@nestjs/common';
import { VehicleCreateDTO } from './dto/VehicleCreate.dto';
import { Vehicle } from './schemas/Vehicle.schema';
import { VehicleService } from './services/vehicle.service';

@Controller('vehicles')
export class VehicleController {
  constructor(private vehicleService: VehicleService) {}

  @Post()
  async create(@Body() vehicleCreateDto: VehicleCreateDTO): Promise<Vehicle> {
    return await this.vehicleService.create(vehicleCreateDto);
  }

  @Get()
  async getAll() {
    return this.vehicleService.getAll();
  }
}
