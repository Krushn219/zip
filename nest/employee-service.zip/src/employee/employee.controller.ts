import {
  Body,
  Controller,
  Delete,
  Get,
  NotFoundException,
  Param,
  Post,
  Put,
  Query,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { EmployeeTierValidationPipe } from 'src/employee-tier-validation.pipe';
import { EmployeeStatus, EmployeeTier } from './Employee.enum';
import { EmployeeService } from './services/employee.service';
import { EmployeeCreateDto } from './dto/EmployeeCreate.dto';
import { EmployeeUpdateDto } from './dto/EmployeeUpdate.dto';
import { Employee } from './schemas/Employee.schema';
import { EmployeeSearchDto } from '../employee/dto/EmployeeSearch.dto';

@Controller('employee')
export class EmployeeController {
  constructor(private employeeService: EmployeeService) {}

  //   @Get()
  //   getServer() {
  //     return 'Hello..';
  //   }

  @Get()
  @UsePipes(ValidationPipe)
  async getAllEmployee(@Query() param: EmployeeSearchDto): Promise<Employee[]> {
    return await this.employeeService.getAllEmployees();
  }

  @Post()
  @UsePipes(ValidationPipe)
  @UsePipes(new EmployeeTierValidationPipe())
  createEmployee(
    @Body() employeeCreateDto: EmployeeCreateDto,
  ): Promise<Employee> {
    return this.employeeService.createEmployee(employeeCreateDto);
    // return this.employeeService;
  }

  //   @Get(':id')
  //   getEmployeeById(@Param('id') id: string) {
  //     return this.employeeService.getEmployeeById(id);
  //   }

  //   @Put('/:id/city')
  //   updateEmployee(
  //     @Param('id') id: string,
  //     @Body() employeeUpdateDto: EmployeeUpdateDto,
  //   ) {
  //     employeeUpdateDto.id = id;
  //     return this.employeeService.updateEmployee(employeeUpdateDto);
  //   }

  //   @Delete('/:id')
  //   deleteEmployee(@Param('id') id: string) {
  //     if (!this.employeeService.deleteEmployee(id)) {
  //       throw new NotFoundException('Employee Does not Exists');
  //     }
  //     return 'Deleted Success..';
  //   }
}
