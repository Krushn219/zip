import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { EmployeeController } from './employee.controller';
import { EmployeeRepository } from './repository/Employee.repository';
import { EmployeeService } from './services/employee.service';
import { Employee, EmployeeSchema } from './schemas/Employee.schema';
import { VehicleController } from './vehicle.controller';
import { Vehicle, VehicleSchema } from './schemas/Vehicle.schema';
import { VehicleService } from './services/vehicle.service';
import { VehicleRepository } from './repository/vehicle.reposetory';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Employee.name, schema: EmployeeSchema },
      { name: Vehicle.name, schema: VehicleSchema },
    ]),
  ],
  controllers: [EmployeeController, VehicleController],
  providers: [
    EmployeeService,
    EmployeeRepository,
    VehicleService,
    VehicleRepository,
  ],
})
export class EmployeeModule {}
