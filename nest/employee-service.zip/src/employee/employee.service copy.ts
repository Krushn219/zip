// import { Injectable, NotFoundException } from '@nestjs/common';
// import { EmployeeStatus, EmployeeTier } from './Employee.enum';
// import { v1 as uuid } from 'uuid';
// import { EmployeeSearchDto } from './EmployeeSearch.dto';
// import { EmployeeUpdateDto } from './EmployeeUpdate.dto';
// import { EmployeeCreateDto } from './EmployeeCreate.dto';
// import { Employee } from './schemas/Employee.schema';
// import { EmployeeRepository } from './Employee.repository';

// @Injectable()
// export class EmployeeService {
//   // private employees: Employee[] = [];

//   constructor(private employeeRepository: EmployeeRepository) {}

//   getAllEmployees(): Promise<Employee[]> {
//     return this.employeeRepository.findAll();
//   }

//   createEmployee(employeeCreateDto: EmployeeCreateDto): Promise<Employee> {
//     return this.employeeRepository.create(employeeCreateDto);
//   }

//   // employeeSearch(employeeSearchDto: EmployeeSearchDto) {
//   // const { status, name } = employeeSearchDto;
//   // let employees = this.getAllEmployees();

//   // if (status) {
//   //   employees = employees.filter((employee) => (employee.status = status));
//   // }

//   // if (name) {
//   //   employees = employees.filter(
//   //     (employee) =>
//   //       employee.firstName.includes(name) || employee.lastName.includes(name),
//   //   );
//   // }
//   // return employees;
//   // }

//   // getEmployeeById(id: string): Employee {
//   //   const employees = this.getAllEmployees();
//   //   const employee = employees.find((employee) => employee.id === id);
//   //   if (!employee) {
//   //     throw new NotFoundException(`${id} does not Exists..`);
//   //   }
//   //   return employee;
//   // }

//   // updateEmployee(employeeUpdateDto: EmployeeUpdateDto): Employee {
//   // const { id, city } = employeeUpdateDto;
//   //   const employee = this.getEmployeeById(id);
//   //   employee.nearestCity = city;
//   //   return employee;
//   // }

//   // deleteEmployee(id: string): boolean {
//   //   const employees = this.getAllEmployees();
//   //   this.employees = employees.filter((employee) => employee.id != id);
//   //   return employees.length != this.employees.length;
//   // }
// }
