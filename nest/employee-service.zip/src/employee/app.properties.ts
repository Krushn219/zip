export const MONGOOSE_CONNECTION =
  'mongodb+srv://admin:admin@cluster0.o6j4w.mongodb.net/nest_employee?retryWrites=true&w=majority';
