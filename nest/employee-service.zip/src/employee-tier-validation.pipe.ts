import {
  ArgumentMetadata,
  BadRequestException,
  Injectable,
  PipeTransform,
} from '@nestjs/common';
import { EmployeeTier } from './employee/Employee.enum';

@Injectable()
export class EmployeeTierValidationPipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata) {
    // console.log(value.tier);
    if (!(value.tier in EmployeeTier)) {
      throw new BadRequestException(`Not a valid tier`);
    }
    return value;
  }
}
