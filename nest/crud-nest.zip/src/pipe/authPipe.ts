import {
  PipeTransform,
  Injectable,
  ArgumentMetadata,
  BadRequestException,
} from '@nestjs/common';

@Injectable()
export class authPipe implements PipeTransform {
  transform(value: any, metadata: ArgumentMetadata) {
    console.log('OK', value);
    if (value == '22') {
      throw new BadRequestException('Invalid..');
    }
    return value;
  }
}
