import { IsString, IsInt } from 'class-validator';

export class CreatePostDto {
  @IsInt()
  id: number;

  @IsString()
  name: string;

  @IsString()
  email: string;
}
