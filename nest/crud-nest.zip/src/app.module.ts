import {
  Module,
  NestModule,
  MiddlewareConsumer,
  RequestMethod,
} from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsersController } from './users/users.controller';
import { EmployeeModule } from './employee/employee.module';
import { BlogsService } from './blogs/blogs.service';

import { AuthMiddleware } from './middleware/auth';
import { AuthMiddleware2 } from './middleware/auth2';

import { APP_FILTER, APP_GUARD } from '@nestjs/core';
import { HttpExceptionFilter } from './exception/http.filter';
import { AuthGaurd } from './guards/auth.guard';
import { MulterModule } from '@nestjs/platform-express';

import { MongooseModule } from '@nestjs/mongoose';
import { UsersModule } from './users/user.module';
import { UserModule } from './user/user.module';

@Module({
  imports: [
    MongooseModule.forRoot(
      'mongodb+srv://admin:admin@cluster0.o6j4w.mongodb.net/nest?retryWrites=true&w=majority',
    ),
    EmployeeModule,
    UsersModule,
    MulterModule.register({
      dest: './uploads',
    }),
    UserModule,
  ],
  controllers: [AppController, UsersController],
  providers: [
    AppService,
    BlogsService,
    // {
    //   // provide: APP_FILTER,
    //   // useClass: HttpExceptionFilter,
    // },
    // {
    //   // To Use Guard On Perticuler Module
    //   provide: APP_GUARD,
    //   useClass: AuthGaurd,
    // },
  ],
})
// export class AppModule {}
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(AuthMiddleware, AuthMiddleware2)
      // .exclude({
      //   path:'users/blog-list', method:RequestMethod.GET
      // })
      // .forRoutes('posts')
      .forRoutes(UsersController);
    // .forRoutes({
    //   path:'users/blog-list', method:RequestMethod.GET
    // })
  }
}
