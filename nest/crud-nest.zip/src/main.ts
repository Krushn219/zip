import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { HttpExceptionFilter } from './exception/http.filter';
import { AuthGaurd } from './guards/auth.guard';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  // app.useGlobalPipes(new ValidationPipe()); //To Use Pipe Globally...
  // app.useGlobalFilters(new HttpExceptionFilter()); // To Use Exception Globally..
  // app.useGlobalGuards(new AuthGaurd()); //To Use Guards Gloabally..
  await app.listen(3000);
}
bootstrap();
