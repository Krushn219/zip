import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable, of } from 'rxjs';
import { tap, map } from 'rxjs/operators';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  intercept(
    context: ExecutionContext,
    next: CallHandler<any>,
  ): Observable<any> | Promise<Observable<any>> {
    const request = context.switchToHttp().getRequest();
    // console.log(request.headers);
    // console.log('First Call');
    // return next
    //   .handle()
    //   .pipe(tap(() => console.log('Last Call::Login Successfully...')));

    // return next.handle().pipe(
    //   map((data) => {
    //     return {
    //       ...data,
    //       newToken: 'krushnavandan',
    //     };
    //   }),
    // );

    /**************** Data From Cache *******/
    const redisCache = false; // set true when in Use
    if (redisCache) {
      return of([
        {
          id: 1,
          msg: 'Data from cache',
        },
      ]);
    }
    return next.handle();
  }
}
