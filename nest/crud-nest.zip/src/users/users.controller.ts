import {
  Controller,
  Get,
  Post,
  All,
  Body,
  Param,
  HttpCode,
  Query,
  DefaultValuePipe,
  ParseArrayPipe,
  UsePipes,
  ValidationPipe,
  ParseIntPipe,
  HttpException,
  HttpStatus,
  UseFilters,
  ForbiddenException,
  BadRequestException,
  UseGuards,
  UseInterceptors,
  UploadedFile,
  UploadedFiles,
} from '@nestjs/common';
import { identity } from 'rxjs';
import { BlogsService } from '../blogs/blogs.service';

import { authPipe } from '../pipe/authPipe';

import { CreatePostDto } from '../pipe/CreatePostDto';

// import { HttpExceptionFilter } from '../exception/http.filter';

import { AuthGaurd } from 'src/guards/auth.guard';

import { LoggingInterceptor } from 'src/interceptors/logging.interceptors';
import {
  FileFieldsInterceptor,
  FileInterceptor,
  FilesInterceptor,
} from '@nestjs/platform-express';
import { profile } from 'console';

@Controller('users')
// @UseInterceptors(LoggingInterceptor) //To Use Interceptors in al routes of this module
export class UsersController {
  constructor(private blogsService: BlogsService) {}

  // console.log("UserController is Running...");

  @Get()
  userInfo(): string {
    return 'Welcome To Users Page..';
  }

  @Get('history')
  userHistory(): object {
    return { id: 1, text: 'Hello World..' };
  }

  @Post('addUser')
  // @All('addUser')
  addUser(@Body() record: any): string {
    console.log(record);
    return 'User Added Successfully..';
  }

  @Get('list/:id')
  // @HttpCode(404)
  getUserById(@Param() record: any): string {
    console.log(record);
    return 'User By Id' + record.id;
  }

  /****** For Validation 
     * 
     * ParseIntPipe ex:-
     *  @Post('list/:id')
    // @HttpCode(404)
        getUserById(@Param(''id', ParseIntPipe) record:any):string{

        console.log(record);
        return "User By Id"+record.id
    }
     */

  @Get('filter')
  // @HttpCode(404)
  getFilterUser(@Query() record: any): string {
    console.log(record);
    return 'Filtered Users' + record.id + ' ' + record.name;
  }

  @Get('version*card')
  detailPage(): string {
    return 'Detail Page';
  }

  @Get('blog-list')
  async blogList(): Promise<any[]> {
    return this.blogsService.findData();
  }

  @Post('blog-add')
  blogAdd(@Body() record: any) {
    this.blogsService.create(record);
    return record;
  }

  //pagination

  @Post('list')
  // detailById(@Query('page', new DefaultValuePipe(0)) page : number):string {//import DeFaultValuePipe
  //     console.log(page,'===')
  //     return "List user"+page
  // }

  // detailById(@Query('id', new ParseArrayPipe({items:Number,separator:','})) id : number[]):string {
  //     console.log(id,'===')
  //     return "List user"+ id
  // }
  // @Post

  /*** Custom Pipe *********/
  // @UsePipes(new authPipe())
  // detailById(@Query('id') id : number[]):string {
  //     console.log(id,'===')
  //     return "List user"+ id
  // }
  @UsePipes(ValidationPipe)
  detailById(@Body() CreatePostDto: CreatePostDto) {
    console.log(CreatePostDto);
    return 'List User';
  }

  /************* Excaption Filter *****/
  @Get('info/:id')
  //   @UseFilters(new HttpExceptionFilter())
  postInfo(@Param('id', ParseIntPipe) id: number): object {
    if (id == 12) {
      // throw new HttpException('Forebidden', HttpStatus.FORBIDDEN);
      //   throw new HttpException(
      //     {
      //       status: HttpStatus.BAD_REQUEST,
      //       error: 'Custom error',
      //     },
      //     HttpStatus.BAD_REQUEST,
      //   );
      //   throw BadRequestException;
    }
    return {
      id: id,
      data: 'NA',
    };
  }

  /*************** Guard *************/
  @Get('blog-lists')
  //   @UseGuards(AuthGaurd)
  blogLists() {
    return 'Blog List';
  }

  /*************** Interceptions *************/
  @Get('blog-lists-interception')
  blogListsInterception(): object {
    console.log('Api Call');
    return {
      data: 'Post List Data',
      id: 12,
      item: [{ name: 'test' }],
    };
  }

  /************** File Upload *******************/
  //Upload Single Image
  //   @Post('post-add')
  //   @UseInterceptors(FileInterceptor('profile'))
  //   postAdd(@UploadedFile() profile: Express.Multer.File): object {
  //     console.log(profile);
  //     return {
  //       msg: 'File Uploaded...',
  //     };
  //   }

  /************************* Validations (Multiple Images by diffrent Fields) *****************/
  //   @Post('post-add')
  //   @UseInterceptors(
  //     FileFieldsInterceptor([
  //       {
  //         name: 'profile',
  //         maxCount: 2,
  //       },
  //       {
  //         name: 'profile2',
  //         maxCount: 1,
  //       },
  //     ]),
  //   )
  //   postAdd(
  //     @UploadedFiles()
  //     profile: {
  //       profile?: Express.Multer.File[];
  //       profile2?: Express.Multer.File[];
  //     },
  //   ): object {
  //     console.log(profile);
  //     return {
  //       msg: 'File Uploaded...',
  //     };
  //   }

  /************************** No Need Of FieldName like Profile for Upload/ Multiple file Upload *****************/
  @Post('post-add')
  @UseInterceptors(FilesInterceptor('profile'))
  postAdd(@UploadedFiles() profile: Array<Express.Multer.File>) {
    // console.log('Hello world...');
    // console.log(profile);
    return {
      msg: 'File Uploaded',
    };
  }
}
