import { Injectable, NestMiddleware } from '@nestjs/common';
import {Request, Response, NextFunction} from 'express';

// interface Blog{
//     name:string,
//     id:number
// }

@Injectable()
export class AuthMiddleware2 implements NestMiddleware {

    use(req:Request ,res:Response , next:NextFunction){
        console.log("Requests2 are Coming...",req.url);
        next();
    }
}
