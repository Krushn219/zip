import { Injectable } from '@nestjs/common';
import { BookModel } from './book.model';

@Injectable()
export class AppService {
  public books: BookModel[] = [
    { title: 'Harry Porter 1', author: 'JK Rowling', published: 2012 },
    { title: 'Harry Porter 2', author: 'JK Rowling', published: 2013 },
    { title: 'Harry Porter 3', author: 'JK Rowling', published: 2014 },
  ];

  getHello(): string {
    return 'Hello World!';
  }

  getAllBooks(): BookModel[] {
    return this.books;
  }
}
