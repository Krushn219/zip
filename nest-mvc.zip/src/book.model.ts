export interface BookModel {
  title: string;
  author: string;
  published: number;
}
