const express = require("express");
const { userInfo } = require("os");
const port = process.env.PORT || 5000;
const app = express();
const http = require("http").Server(app);

const path = require("path");
const io = require("socket.io")(http);

app.get("/", (req, res) => {
  var options = {
    root: path.join(__dirname),
  };
  var fileName = "index.html";
  res.sendFile(fileName, options);
});

io.on("connection", (socket) => {
  console.log("User Connected...");

  socket.on("setUserName", function (data) {
    console.log(data + "user Connected");
    if (user.indexOf(data) > -1) {
      socket.emit(
        "userExists",
        data + "username is already in use!, pleaseuse another name"
      );
    } else {
      users.push(data);
      socket.emit("setUser", { username: data });
    }
  });

  socket.on("disconnect", () => {
    console.log("A User Disconnected...");
  });
});

// app.listen(port, (err) => {
//   if (err) {
//     console.log("Something Went Wrong...");
//   }
//   console.log("Server is running on port::", port);
// });

http.listen(port, function () {
  console.log("Server is running on Port::", port);
});
