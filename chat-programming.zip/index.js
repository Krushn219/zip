const express = require("express");

const app = express();

const http = require("http").Server(app);

const port = 4500;

const path = require("path");
const { connected } = require("process");

const io = require("socket.io")(http);

app.get("/", (req, res) => {
  var options = {
    root: path.join(__dirname),
  };
  var fileName = "index.html";
  res.sendFile(fileName, options);
});

var users = 0;
var roomNo = 1;
var full = 0;

io.on("connection", (socket) => {
  console.log("A user connected..");
  /************ Broadcasting **********/
  // users++;
  // io.sockets.emit("broadcast", { message: users + "users connected!" });
  // socket.emit("newUser", { message: "Hello...welcome" });

  // socket.broadcast.emit("newUser", { message: users + "users connected..." });

  // For welcome msg to first user
  // socket.emit("broadcast", { message: users + "users connected!" });

  // setTimeout(function () {
  //   // socket.send("Sending Message From server side using pre-reserved events..");
  //   socket.emit("myCustomEvent", {
  //     data: "A custom Event From Server Side...",
  //   });
  // }, 3000);

  /*** catching emit event from  CLIENT side */
  // socket.on("eventClient", function (data) {
  //   console.log(data);
  // });

  /********************** Namespace *************/
  // io.emit("nameSpace", "testing for name space");

  /********************** Rooms / Channels *************/
  socket.join("room-" + roomNo);
  io.sockets
    .in("room-" + roomNo)
    .emit("connectedRoom", "You are connected to room no::" + roomNo); // Here io is a default namespace variable

  // limit in room
  full++;
  if (full >= 2) {
    full = 0;
    roomNo++;
  }
  socket.on("disconnect", () => {
    console.log("A user disconnected..");

    // users--;
    // io.sockets.emit("broadcast", { message: users + "users connected!" });
    // socket.emit("newUser", { message: users + "users connected!" });
  });
});

// *****************  io.of('/')  ***default name space ******************
var cnsp = io.of("/custom-namespace");
cnsp.on("connection", function (socket) {
  console.log("A User Connected...");

  cnsp.emit("customNameSpace", "tester for custom namespace...");

  socket.on("disconnect", function () {
    console.log("A User Disconnected...");
  });
});

http.listen(port, function () {
  console.log("Server is running on Port::", port);
});
