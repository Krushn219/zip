const mongoose = require('mongoose');
const topplaceSchema = mongoose.Schema({
    image: {
        type: String,
        // required: [true, "Please Enter topplace-image"],
    },
    key: {
        type: String,
    },
    city: {
        type: String,
        required: [true, "Please Enter city"],
    },
    accommodation: {
        type: String,
        required: [true, "Please Enter accommodation"],
    },
    start_price: {
        type: Number,
        required: [true, "Please Enter start_price"],
    },
},
    { timestamps: true });
module.exports = mongoose.model('topplace', topplaceSchema);