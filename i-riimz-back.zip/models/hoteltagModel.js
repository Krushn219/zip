const mongoose = require('mongoose');
const validator = require("validator");

const hoteltagSchema = mongoose.Schema({

    hotel_id: {
        type: String,
        trim: true,
        // required: [true, "Please Enter hotel_id"],
    },
    tags: [{
        // type: String,
        // trim: true,
        // required: [true, "Please Enter tags"],
    }],
    nots: {
        type: String,
        trim: true,
        // required: [true, "Please Enter nots"],
    },
},
    { timestamps: true });
module.exports = mongoose.model('hoteltag', hoteltagSchema);