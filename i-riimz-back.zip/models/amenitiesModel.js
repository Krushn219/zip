const mongoose = require("mongoose");

const amenitiesSchema = mongoose.Schema(
    {
        name: {
            type: String,
            trim: true,
            // required: [true, "Please Enter name"],
        },
        icon: {
            type: String,
            // required: [true, "Please Enter icon"],
        },
        status: {
            type: Boolean,
            default: false,
            // required: [true, "Please Enter status"],
        },
    },
    { timestamps: true }
);

module.exports = mongoose.model("amenities", amenitiesSchema);
