
const mongoose = require("mongoose");

const customerhotelSchema = mongoose.Schema({
    user_name: {
        type: String,
        trim: true,
        // required: [true, "Please Enter user_name"],
    },
    hotel_name: {
        type: String,
        // required: [true, "Please Enter hotel_name"],
        unique: false
    },
    hotel_email: {
        type: String,
        trim: true,
        // unique: false
        // required: [true, "Please Enter email"],
    },
    hotel_address: {
        type: String,
        trim: true,
        // required: [true, "Please Enter address"],
    },
    hotel_mobile: {
        type: Number,
        trim: true,
        // required: [true, "Please Enter mobile Num."],
    },
    created: {
        type: Date,
        default: Date.now(),
    },
},
    { timestamps: true }
);

module.exports = mongoose.model("customerhotel", customerhotelSchema);














