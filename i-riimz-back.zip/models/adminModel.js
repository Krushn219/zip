const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const adminSchema = new mongoose.Schema({
    admin_name: {
        type: String,
        trim: true,
        required: [true, "Please Enter Your name"],
        maxLength: [50, "name cannot exceed 50 characters"],
        minLength: [2, "name should have more than 2 characters"],
    },
    admin_email: {
        type: String,
        unique: true,
        trim: true,
        validate: [validator.isEmail, "Please Enter a valid Email"],
    },
    password: {
        type: String,
        select: false,
        required: [true, "Please Enter Your Password"],
        // minLength: [8, "Password should be greater than 8 characters"],
    },
    admin_mobile: {
        type: Number,
        trim: true,
        // required: [true, "Please Enter Your phone num."],
        // minLength: [10, "Password should be greater than 10 characters"],
    },
    access_control: {
        type: String,
        trim: true,
        default: "admin",
        // required: [true, "Please Enter  access_control"],
    },
    status: {
        type: Number,
        default: 1,
        enum: [0, 1],
    },

    resetPasswordToken: String,
    resetPasswordExpire: Date,
},
    { timestamps: true });

adminSchema.pre("save", async function (next) {
    if (!this.isModified("password")) {
        next();
    }

    this.password = await bcrypt.hash(this.password, 10);
});

// JWT TOKEN
adminSchema.methods.getJWTToken = function () {
    return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRE,
    });
};

// Compare Password
adminSchema.methods.comparePassword = async function (password) {
    return await bcrypt.compare(password, this.password);
};

// Generating Password Reset Token
adminSchema.methods.getResetPasswordToken = function () {
    // Generating Token
    const resetToken = crypto.randomBytes(20).toString("hex");
    // Hashing and adding resetPasswordToken to adminSchema
    this.resetPasswordToken = crypto
        .createHash("sha256")
        .update(resetToken)
        .digest("hex");

    this.resetPasswordExpire = Date.now() + 15 * 60 * 1000;

    return resetToken;
};

module.exports = mongoose.model("admin", adminSchema);
