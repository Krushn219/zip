const mongoose = require("mongoose");

const hotelReviewsSchema = mongoose.Schema(
    {
        hotel_id: {
            type: Number,
            trim: true,
            // required: [true, "Please Enter hotel_id"],
        },
        username: {
            type: String,
            trim: true,
            // required: [true, "Please Enter user_id"],
        },
        title: {
            type: String,
            trim: true,
            // required: [true, "Please Enter title"],
        },
        description: {
            trim: true,
            type: String,
            // required: [true, "Please Enter review"],
        },
        happywithcheckin: {
            type: Number,
            default: 0,
            enum: [0, 1, 2],
            // required: [true, "Please Enter review"],
        },
        happywithroom: {
            type: Number,
            default: 0,
            enum: [0, 1, 2],
            // required: [true, "Please Enter review"],
        },
        happywithlocation: {
            type: Number,
            default: 0,
            enum: [0, 1, 2],
            // required: [true, "Please Enter review"],
        },
        didyoulike: [{
            trim: true,
            type: String,
            // required: [true, "Please Enter review"],
        }],
        didNotLike: [{
            trim: true,
            type: String,
            // required: [true, "Please Enter review"],
        }],
        rating: {
            type: Number,
            default: 0,
            // required: [true, "Please Enter status"],
        },
        ratings: {
            type: Number,
            default: 0,
        },
        numOfReviews: {
            type: Number,
            default: 0,
        },
        status: {
            type: String,
            // default: "Approved",
            enum: ["Approved", "Rejected"],
        },
        reviewstatus: {
            type: String,
            enum: ["checkIn", "checkOut"],
        },
        created: {
            type: Date,
            default: Date.now(),
        },
    },
    { timestamps: true }
);

module.exports = mongoose.model("hotelReviews", hotelReviewsSchema);
