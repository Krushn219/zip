const mongoose = require("mongoose");

const roomsSchema = mongoose.Schema(
    {
        ax_room_id: {
            type: String,
            // required: [true, "Please Enter ax_room_id"],
        },
        active: {
            type: Boolean,
            default: true,
            // required: [true, "Please Enter active"],
        },
        room_name: {
            type: String,
            // required: [true, "Please Enter room_name"],
        },
        rate_plan_json: {
            type: String,
            // required: [true, "Please Enter rate_plan_json"],
        },
        ax_hotel_id: {
            type: String,
            // required: [true, "Please Enter ax_hotel_id"],
        },
        hotel_id: {
            type: mongoose.Schema.ObjectId,
            ref: "hotels",
            // required: [true, "Please Enter Your hotel_id"],
        },
        cover_photo: {
            type: String,
            // required: [true, "Please Enter cover_photo"],
        },
        room_video_url: {
            type: String,
            // required: [true, "Please Enter room_video_url"],
        },
        created: {
            type: Date,
            default: Date.now(),
        },
    },
    { timestamps: true }
);
module.exports = mongoose.model("rooms", roomsSchema);
