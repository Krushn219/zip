const mongoose = require("mongoose");

const hotelsSchema = mongoose.Schema({
    ax_hotel_id: {
        type: String,
        trim: true,
        // required: [true, "Please Enter ax_hotel_id"],
    },
    hotel_name: {
        type: String,
        // required: [true, "Please Enter Your hotel_name"],
        unique: false
    },
    hotel_email: {
        type: String,
        // required: [true, "Please Enter Your email"],
        unique: false
    },
    hotel_address: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  address"],
    },
    hotel_mobile: {
        type: Number,
        trim: true,
        // required: [true, "Please Enter  mobile Num."],
    },
    hotel_phone: {
        type: Number,
        trim: true,
        // required: [true, "Please Enter  phone Num."],
    },
    hotel_city: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  city"],
    },
    hotel_state: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  state"],
    },
    hotel_country: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  country"],
    },
    hotel_pincode: {
        type: Number,
        trim: true,
        // required: [true, "Please Enter  pincode"],
    },
    active: {
        type: Boolean,
        default: false,
    },
    // user_id: {
    //     type: mongoose.Schema.ObjectId,
    //     ref: "user",
    //     // required: [true, "Please Enter  user_id"],
    // },
    admin_id: {
        type: mongoose.Schema.ObjectId,
        ref: "admin",
        // required: [true, "Please Enter  user_id"],
    },
    auth_string: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  auth_string"],
    },
    password_reset_otp: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  password_reset_otp"],
    },
    free_cancellation_status: {
        type: Boolean,
        default: false,
    },
    free_cancellation_prior_days: {
        type: Boolean,
        default: false,
    },
    cancellation_charges: {
        type: Number,
        default: 0.00,
    },
    about_hotel: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  about_hotel"],
    },
    staymaker_rating: {
        type: Boolean,
        default: false,
    },
    customer_rating: {
        type: Boolean,
        default: false,
    },
    started_year: {
        type: Number,
        trim: true,
        // required: [true, "Please Enter  started_year"],
    },
    intro_video: {
        type: String,
        trim: true,
        // required: [true, "Please Enter  intro_video"],
    },
    amenities: [
        {
            type: mongoose.Schema.ObjectId,
            ref: "amenities",
            require: true,
        },
    ],
    created: {
        type: Date,
        default: Date.now(),
    },
},
    { timestamps: true }
);

module.exports = mongoose.model("hotels", hotelsSchema);










