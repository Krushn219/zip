const mongoose = require("mongoose");
const validator = require("validator");


const enquirySchema = new mongoose.Schema({
    name: {
        type: String,
        trim: true,
        required: [true, "Please Enter Your name"],
        maxLength: [50, "name cannot exceed 50 characters"],
        minLength: [2, "name should have more than 2 characters"],
    },
    email: {
        type: String,
        unique: true,
        trim: true,
        validate: [validator.isEmail, "Please Enter a valid Email"],
    },
    mobile_no: {
        type: Number,
        trim: true,
        required: [true, "Please Enter Your phone Number"],
        minLength: [10, "Password should be greater than 10 characters"],
    },
    company_name: {
        type: String,
        trim: true,
        required: [true, "Please Enter company_name"],
    },
    company_city: {
        type: String,
        trim: true,
        required: [true, "Please Enter company_city"],
    },
},
    { timestamps: true });

module.exports = mongoose.model("enquiry", enquirySchema);
