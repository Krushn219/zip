const mongoose = require('mongoose');
const connection = require('../config/database')

const otpSchema = new mongoose.Schema({
    _id: String,
    mobile: {
        type: String
    },
    otp: {
        type: Number,
        select: false,
    },
    expiresIn: {
        type: Number
    },
    status: {
        type: String,
        default: "Register",
        enum: ["Register", "ForgrtPass", "Booking", "hotel"],
    },
}, {
    timestamps: true,
});

module.exports = mongoose.model("otps", otpSchema);


