const mongoose = require("mongoose");

const hotel_policiesSchema = mongoose.Schema(
    {
        hotel_id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "hotel",
            required: [true, "Please Enter hotel_id"],
        },
        checkIn: {
            type: String,
            // required: [true, "Please Enter title"],
        },
        checkOut: {
            type: String,
            // required: [true, "Please Enter review"],
        },
        Children_and_Extra_Beds: {
            type: String,
            default: 'Not allowed',
            // enum: ['Allowed', 'Not allowed']
        },
        Local_ID: {
            type: String,
            default: 'Not allowed',
            enum: ['Allowed', 'Not allowed']
        },
        Couple_Friendly: {
            type: String,
            default: 'Not allowed',
            enum: ['Allowed', 'Not allowed']
        },
        Foreign_Guest: {
            type: String,
            default: 'Not allowed',
            enum: ['Allowed', 'Not allowed']
        },
        created: {
            type: Date,
            default: Date.now(),
        },

    },
    { timestamps: true }
);

module.exports = mongoose.model("hotel_policies", hotel_policiesSchema);
