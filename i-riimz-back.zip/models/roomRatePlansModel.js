const mongoose = require("mongoose");

const roomRatePlansSchema = mongoose.Schema(
    {
        ax_rateplan_id: {
            type: String,
            // required: [true, "Please Enter Your ax_rateplan_id"],
        },
        rate_plan_name: {
            type: String,
            // required: [true, "Please Enter rate_plan_name"],
        },
        hotel_id: {
            type: mongoose.Schema.ObjectId,
            ref: "hotel",
            // required: [true, "Please Enter Your hotel_id"],
        },
        room_id: {
            type: mongoose.Schema.ObjectId,
            ref: "room",
            // required: [true, "Please Enter room_id"],
        },
        price_date: {
            type: Date,
            // required: [true, "Please Enter price_date"],
        },
        ota_ids: {
            type: String,
            // required: [true, "Please Enter ota_ids"],
        },
        price_json: {
            type: String,
            // required: [true, "Please Enter price_json"],
        },
        active: {
            type: Number,
            default: '1'
            // required: [true, "Please Enter active"],
        },
        occupancies: [
            {
                type: mongoose.Schema.ObjectId,
                ref: "occupancy",
                require: true,
            },
        ],
        start_date: {
            type: Date,
            // required: [true, "Please Enter start_date"],
        },
        end_date: {
            type: Date,
            // required: [true, "Please Enter endDate"],
        },
        commissionPerc: {
            type: String,
            default: "0"
            // required: [true, "Please Enter Your commissionPerc"],
        },
        taxPerc: {
            type: String,
            default: "0"
            // required: [true, "Please Enter Your taxPerc"],
        },
        currency: {
            type: String,
            enum: ['INR', 'USD']
            // required: [true, "Please Enter Your currency"],
        },
        created: {
            type: Date,
            default: Date.now()
        },
    },
    { timestamps: true }
);
module.exports = mongoose.model("room_rate_plans", roomRatePlansSchema);
