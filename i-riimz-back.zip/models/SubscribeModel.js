const mongoose = require('mongoose');
const validator = require("validator");

const SubscribeSchema = mongoose.Schema({

    email: {
        type: String,
        unique: true,
        trim: true,
        validate: [validator.isEmail, "Please Enter a valid Email"],
    },

},
    { timestamps: true });
module.exports = mongoose.model('Subscribe', SubscribeSchema);