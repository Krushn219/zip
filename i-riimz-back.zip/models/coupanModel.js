const mongoose = require('mongoose');

const coupanSchema = mongoose.Schema({
    Coupon_Name: {
        type: String,
        trim: true,
        required: [true, "Please Enter Your name"],
    },
    Coupon_Code: {
        type: String,
        unique: true,
        trim: true,
        required: [true, "Please Enter Coupon_Code"],
    },
    Valid_From: {
        type: Date,
        default: Date.now(),
        required: [true, "Please Enter Valid_From"],
    },
    Valid_To: {
        type: Date,
        required: [true, "Please Enter Valid_To"],
    },
    User_Type: {
        type: String,
        trim: true,
        // required: [true, "Please Enter User_Type"],
    },
    Offer_Type: {
        type: String,
        trim: true,
        // required: [true, "Please Enter Offer_Type"],
    },
    Offer_Value: {
        type: String,
        trim: true,
        // required: [true, "Please Enter Offer_Value"],
    },
    status: {
        type: Number,
        default: 0,
        enum: [0, 1],
    },
    image: {
        type: String,
        required: [true, "Please Enter banner"],
        unique: false
    },
    key: {
        type: String,
    },
},
    { timestamps: true });
module.exports = mongoose.model('coupan', coupanSchema);