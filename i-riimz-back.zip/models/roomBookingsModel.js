const mongoose = require("mongoose");
const moment = require('moment-timezone');
var date = moment(new Date());
var d = date.tz('Asia/Kolkata').format();
// const dateIndia = moment.tz(Date.now(), "Asia/Kolkata");

const rooms_bookinsSchema = mongoose.Schema(
    {
        user: {
            type: mongoose.Schema.ObjectId,
            ref: "users",
            // required: true
        },
        bookingId: {
            type: String,
            // required: [true, "Please Enter bookingId"],
        },
        hotelId: {
            type: String,
            required: [true, "Please Enter hotel_id"],
        },
        hotelname: {
            type: String,
            required: [true, "Please Enter hotel_name"],
        },
        checkInDate: {
            type: Date,
            // default: Date.now(),
            required: [true, "Please Enter checkInDate"],
        },
        checkOutDate: {
            type: Date,
            // default: Date.now(),
            required: [true, "Please Enter checkOutDate"],
        },
        amount: {
            type: Number,
            // required: [true, "Please Enter totalAmount"],
        },
        customerEmail: {
            type: String,
            required: [true, "Please Enter email"],
        },
        customerName: {
            type: String,
            required: [true, "Please Enter customer Name"],
        },
        contactNo: {
            type: String,
            // required: [true, "Please Enter contact No"],
        },
        noOfGuest: {
            type: Number,
            trim: true,
            // required: [true, "Please Enter no_Of_Guest"],
        },
        tax: {
            type: Number,
            trim: true,
            // required: [true, "Please Enter no_Of_Guest"],
        },
        CancelledAt: {
            type: Date,
        },
        DatenowAt: {
            type: Date,
            // default: d
        },
        discription: {
            type: String,
        },
        paymentStatus: {
            type: String,
            default: "All",
            enum: ["Cancelled", "Confirmed", "Pending", "no_show", "All"],
        },
    },
    { timestamps: true }
);
module.exports = mongoose.model("rooms_bookings", rooms_bookinsSchema);
