const mongoose = require("mongoose");
const validator = require("validator");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");

const usersSchema = mongoose.Schema(
    {
        full_name: {
            type: String,
            trim: true,
            // required: [true, "Please Enter Your name"],
        },
        email: {
            type: String,
            unique: true,
            trim: true,
            // required: true,
            // validate: [validator.isEmail, "Please Enter a valid Email"],
        },
        password: {
            type: String,
            select: false,
            required: [true, "Please Enter Your password"],
            // minLength: [8, "password should be greater than 8 characters"],
        },
        mobile: {
            type: Number,
            trim: true,
            required: [true, "Please Enter mobile"],
        },
        pincode: {
            type: Number,
            trim: true,
            // required: [true, "Please Enter Your pincode"],
        },
        auth_string: {
            type: String,
            trim: true,
            // required: [true, "Please Enter auth_string"],
        },
        active: {
            type: Boolean,
            default: true,
            // required: [true, "Please Enter active"],
        },
        mobile_verify_code: {
            type: String,
            trim: true,
            // required: [true, "Please Enter mobile_verify_code"],
        },
        mobile_verified: {
            type: Boolean,
            default: false
            // required: [true, "Please Enter Your mobile_verified"],
        },
        reward_login_otp: {
            type: String,
            trim: true,
            // required: [true, "Please Enter reward_login_otp"],
        },
        created: {
            type: Date,
            default: Date.now(),
        },
        resetpasswordToken: String,
        resetpasswordExpire: Date,
    },
    { timestamps: true }
);

usersSchema.pre("save", async function (next) {
    if (!this.isModified("password")) {
        next();
    }

    this.password = await bcrypt.hash(this.password, 10);
});

// JWT TOKEN
usersSchema.methods.getJWTToken = function () {
    return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRE,
    });
};

// Compare password
usersSchema.methods.comparepassword = async function (password) {
    return await bcrypt.compare(password, this.password);
};

// Generating password Reset Token
usersSchema.methods.getResetpasswordToken = function () {
    // Generating Token
    const resetToken = crypto.randomBytes(20).toString("hex");
    // Hashing and adding resetpasswordToken to usersSchema
    this.resetpasswordToken = crypto
        .createHash("sha256")
        .update(resetToken)
        .digest("hex");

    this.resetpasswordExpire = Date.now() + 15 * 60 * 1000;

    return resetToken;
};

module.exports = mongoose.model("users", usersSchema);
