const mongoose = require('mongoose');
const bannerSchema = mongoose.Schema({
    image: {
        type: String,
        required: [true, "Please Enter banner"],
        unique: false
    },
    key: {
        type: String,
    }
},
    { timestamps: true });
module.exports = mongoose.model('banner', bannerSchema);