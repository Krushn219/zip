const mongoose = require("mongoose");

const bookinDataSchema = mongoose.Schema(
    {
        data: {}
    },
    { timestamps: true }
);
module.exports = mongoose.model("BookingData", bookinDataSchema);
