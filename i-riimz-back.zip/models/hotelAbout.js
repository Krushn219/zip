const mongoose = require('mongoose');
const aboutHotelSchema = mongoose.Schema({
    hotel_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "hotel",
        // required: [true, "Please Enter hotel_id"],
    },
    admin_id: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "admin",
        // required: [true, "Please Enter hotel_id"],
    },
    content: {
        type: String,
        trim: true,
        required: [true, "Please Enter blog content "],
    },

    createdAt: {
        type: Date,
        default: Date.now(),
    },
},
    { timestamps: true });
module.exports = mongoose.model('aboutHotel', aboutHotelSchema);