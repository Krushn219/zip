const mongoose = require('mongoose');
const blogSchema = mongoose.Schema({
    image: {
        type: String,
        // required: [true, "Please Enter Your image"],
        unique: false
    },
    key: {
        type: String,
    },
    title: {
        type: String,
        trim: true,
        // required: [true, "Please Enter blog title"],
    },
    content: {
        type: String,
        trim: true,
        // required: [true, "Please Enter blog content "],
    },
    type: {
        type: String,
        trim: true,
        // required: [true, "Please Enter blog type "],
    },
    city: {
        type: String,
        trim: true,
        // required: [true, "Please Enter city "],
    },
    author: {
        type: String,
        trim: true,
        // required: [true, "Please Enter blog author "],
    },
    created_At: {
        type: Date,
        default: Date.now(),
    },
},
    { timestamps: true });
module.exports = mongoose.model('blog', blogSchema);