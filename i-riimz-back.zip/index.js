
const express = require("express");
const errorMiddleware = require("./middleware/error");
const cron = require("node-cron");
const moment = require("moment");
const port = process.env.PORT || 3001;
require('dotenv').config()
const path = require("path");
const bodyParser = require("body-parser");
const db = require("./config/database");
const exphbs = require('express-handlebars');
const helpers = require('./utils/handlebarsHelpers');

const app = express();
const morgan = require("morgan");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const session = require("express-session");



// Configure Handlebars
app.engine(
    'handlebars',
    exphbs.engine({
        helpers: helpers, // Register the custom helpers
    })
);
app.set('view engine', 'handlebars');

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use("/uploads", express.static(path.join(__dirname + "/uploads")));
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(morgan("tiny"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(
    session({
        name: "i-roomz",
        secret: "i-roomz-backend",
        saveUninitialized: "failed",
        resave: "failed",
        cookie: {
            maxAge: 1000 * 60 * 100,
        },
    })
);




// routes path

app.get("/", (req, res) => {
    res.status(200).json({ status: 200, message: "Stage server is running" });

});

const cronJobController = require("./controllers/CronjobController");

/* --------------- CHRON JOB: check for checkin review mail (every 2:00 PM) --------------- */

cron.schedule(" 00 13 * * *", function () {
    const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
    console.log(currentTime, ": Hello from cron checkinreview mail function");
    // cronJobController.Sendcheckinmail()
});

/* --------------- CHRON JOB: check for checkOut review mail (every minute) --------------- */
// cron.schedule("*/30 * * * * *", function () { }
// cron.schedule("*/5 * * * *", function () {

cron.schedule("* * * * *", function () {
    const currentTime = moment().format('YYYY-MM-DD HH:mm:ss');
    console.log(currentTime, ": Hello from cron checkOutreview mail function");
    cronJobController.SendcheckOutmail()
});

app.use("/v1/admin/api", require("./routes/adminRoute"));
app.use("/v1/agent/api", require("./routes/agentRoute"));
app.use("/v1/amenities/api", require("./routes/amenitiesRoute"));
app.use("/v1/banner/api", require("./routes/bannerRoute"));
app.use("/v1/blog/api", require("./routes/BlogsRoute"));
app.use("/v1/coupan/api", require("./routes/coupanRoute"));
app.use("/v1/customerhotel/api", require("./routes/customerhotelRoute"));
app.use("/v1/enquiry/api", require("./routes/enquiryRoute"));
app.use("/v1/polices/api", require("./routes/hotelPoliciesRoute"));
app.use("/v1/aboutHotel/api", require("./routes/hotelAboutRoute"));
app.use("/v1/review/api", require("./routes/hotelReviewsRoute"));
app.use("/v1/hotel/api", require("./routes/hotelsRoute"));
app.use("/v1/payments/api", require("./routes/paymentsRoute"));
app.use("/v1/booking/api", require("./routes/BookingRoute"));
app.use("/v1/roomRatePlan/api", require("./routes/roomRatePlansRoute"));
app.use("/v1/rooms/api", require("./routes/roomsRoute"));
app.use("/v1/topplace/api", require("./routes/topplaceRoute"));
app.use("/v1/travelagent/api", require("./routes/travelagentRoute"));
app.use("/v1/user/api", require("./routes/userRoute"));
app.use("/v1/Subscribe/api", require("./routes/SubscribeRoute"));
app.use("/v1/hoteltag/api", require("./routes/hoteltagRoute"));
app.use("/v1/booking_data/api", require("./routes/bookinData"));

// global error handler
app.use(errorMiddleware);

app.listen(port, (err) => {
    if (err) {
        console.log("something wrong");
        return "failed";
    }
    console.log("server running on port:", port);
});

