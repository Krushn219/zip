const express = require('express');
const router = express.Router();
const {
    createhotels,
    getallhotels,
    getsinglehotels,
    updatehotels,
    deletehotels,
    Roomhotels,
    verifyhotels
} = require("../controllers/customerhotelController");

//send otp

router
    .route("/Roomhotels")
    .post(Roomhotels);

//verifyotp

router
    .route("/verifyotp")
    .post(verifyhotels);

//Create

router
    .route("/create")
    .post(createhotels);

//Get All

router
    .route("/all")
    .get(getallhotels);

//Get Single

router
    .route("/single/:id")
    .get(getsinglehotels);

// Update hotels

router
    .route("/update/:id")
    .put(updatehotels)

// Delete Single hotel

router
    .route("/delete/:id")
    .delete(deletehotels);

module.exports = router;