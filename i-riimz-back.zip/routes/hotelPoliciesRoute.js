const express = require('express');
const router = express.Router();
const {
    createhotel_policies,
    getallhotel_policies,
    getsinglehotel_policies,
    updatehotel_policies,
    deletehotel_policies
} = require("../controllers/hotelPoliciesController");

//Create

router
    .route("/create")
    .post(createhotel_policies);

//Get All

router
    .route("/all")
    .get(getallhotel_policies);

//Get Single

router
    .route("/single/:id")
    .get(getsinglehotel_policies);

// Update hotel_policies

router
    .route("/update/:id")
    .put(updatehotel_policies)

// Delete Single hotel_policie

router
    .route("/delete/:id")
    .delete(deletehotel_policies);

module.exports = router;