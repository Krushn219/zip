const express = require('express');
const router = express.Router();
const {
    createhoteltag,
    getallhoteltag,
    getsinglehoteltag,
    hoteltageByHotel,
    updatehoteltag,
    deletehoteltag,
    hoteltagefilter
} = require("../controllers/hoteltagController");

//Create

router
    .route("/create")
    .post(createhoteltag);

//Get All

router
    .route("/all")
    .get(getallhoteltag);

//Get Single

router
    .route("/single/:id")
    .get(getsinglehoteltag);

//Get Single

router
    .route("/hotelId/:hotelId")
    .get(hoteltageByHotel);

// Update hoteltag

router
    .route("/update/:id")
    .put(updatehoteltag)

// Delete Single agent

router
    .route("/delete/:id")
    .delete(deletehoteltag);


router
    .route("/filter/:tags")
    .get(hoteltagefilter);

module.exports = router;