const express = require('express');
const router = express.Router();
const {
    createenquirys,
    getallenquirys,
    getsingleenquirys,
    updateenquirys,
    deleteenquirys,
} = require("../controllers/enquiryController");

//Create

router
    .route("/create")
    .post(createenquirys);

//Get All

router
    .route("/all")
    .get(getallenquirys);

//Get Single

router
    .route("/single/:id")
    .get(getsingleenquirys);

// Update enquirys

router
    .route("/update/:id")
    .put(updateenquirys)

// Delete Single enquiry

router
    .route("/delete/:id")
    .delete(deleteenquirys);


module.exports = router;