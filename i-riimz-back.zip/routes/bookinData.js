const express = require('express');
const router = express.Router();
const {
    createBookingData,
    getAllBookingData,
    getSingleBookingData,
    updateBookingData
} = require("../controllers/bookingDataController");

//Create

router
    .route("/create")
    .post(createBookingData);

//Get All

router
    .route("/all")
    .get(getAllBookingData);

//Get Single

router
    .route("/single/:bookingId")
    .get(getSingleBookingData);

// Update

router
    .route("/:id")
    .put(updateBookingData);




module.exports = router;