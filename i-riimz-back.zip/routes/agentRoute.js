const express = require('express');
const router = express.Router();
const {
    createagents,
    getallagents,
    getsingleagents,
    updateagents,
    deleteagents
} = require("../controllers/agentController");

//Create

router
    .route("/create")
    .post(createagents);

//Get All

router
    .route("/all")
    .get(getallagents);

//Get Single

router
    .route("/single/:id")
    .get(getsingleagents);

// Update agents

router
    .route("/update/:id")
    .put(updateagents)

// Delete Single agent

router
    .route("/delete/:id")
    .delete(deleteagents);

module.exports = router;