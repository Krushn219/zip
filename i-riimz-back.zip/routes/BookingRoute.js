const express = require('express');
const router = express.Router();
const {
    createRoomBooking,
    getAllRoomBooking,
    getSingleRoomBooking,
    updateRoomBooking,
    deleteRoomBooking,
    bookingByHotel,
    bookingByHoteldate,
    bookingByHotelstatus,
    bookingByHotelall,
    Roombooking,
    verifyRoombooking,
    updateBooking,
    getCancelledStatus,
    getConfirmedStatus,
    getPendingStatus,
    getuserRoomBooking,
    sendmail,
    sendcancelmail,
    filtersBookingday,
    filtersBookingweek,
    filtersBookingmonth,
    filtersBookingyear,
    UpcomingBookingday,
    Upcomingbookingweek,
    UpcomingBookingmonth,
    UpcomingBookingyear,
    ConfirmedBookingday,
    Confirmedbookingweek,
    ConfirmedBookingmonth,
    ConfirmedBookingyear,
    recentBookingday,
    recentBookingweek,
    recentBookingmonth,
    recentBookingyear
} = require("../controllers/BookingController");

router
    .route("/Roombooking")
    .post(Roombooking);

router
    .route("/verifyotp")
    .post(verifyRoombooking);

//Create

router
    .route("/create")
    .post(createRoomBooking);

//Get All

router
    .route("/all")
    .get(getAllRoomBooking);

//Get Single

router
    .route("/single/:id")
    .get(getSingleRoomBooking);

router
    .route("/singleuser/:user_id")
    .get(getuserRoomBooking);


// Update hotels

router
    .route("/update/:id")
    .put(updateRoomBooking)

// Update hotels status

router
    .route("/updateBooking/:bookingId")
    .put(updateBooking)

// get booking Confirmed

router
    .route("/Confirmed")
    .get(getConfirmedStatus);

// get booking Pending

router
    .route("/Pending")
    .get(getPendingStatus);

// get booking Cancelled

router
    .route("/Cancelled")
    .get(getCancelledStatus);

// Delete Single hotel

router
    .route("/delete/:id")
    .delete(deleteRoomBooking);

// Booking By Hotel Id
router
    .route("/hotelId/:hotelId")
    .get(bookingByHotel);

// Booking By Hotel date

router
    .route("/hotel/:firstday/:lastDay")
    .get(bookingByHoteldate);

// Booking By Hotel status

router
    .route("/hotel/:firstday/:lastDay/:status")
    .get(bookingByHotelstatus);

// Booking By Hotel status(all)

router
    .route("/status/hotel/:firstday/:lastDay")
    .get(bookingByHotelall);

// sendmail booking

router
    // .route("/sendmail/:email/:bookingId")
    // .post(sendmail);

    //changes by krushnavandan 0n 8/7/23
    .route("/sendmail/:email/:bookingId")
    .post(sendmail);

// sendcancelmail booking

router
    .route("/sendcancelmail/:bookingId")
    .post(sendcancelmail);

/* --------------- Total Bookings --------------- */

// day Bookings

router
    .route("/Bookingsall/day")
    .get(filtersBookingday);

// week Bookings

router
    .route("/Bookingsall/week")
    .get(filtersBookingweek);

// month Bookings

router
    .route("/Bookingsall/month")
    .get(filtersBookingmonth);

// year Bookings

router
    .route("/Bookingsall/year")
    .get(filtersBookingyear);

/* --------------- Upcoming Bookings --------------- */

// day Bookings

router
    .route("/Upcoming/day")
    .get(UpcomingBookingday);

// week Bookings

router
    .route("/Upcoming/week")
    .get(Upcomingbookingweek);

// month Bookings

router
    .route("/Upcoming/month")
    .get(UpcomingBookingmonth);

// year Bookings

router
    .route("/Upcoming/year")
    .get(UpcomingBookingyear);

/* --------------- Confirmed Bookings --------------- */

// day Bookings

router
    .route("/Confirmed/day")
    .get(ConfirmedBookingday);

// week Bookings

router
    .route("/Confirmed/week")
    .get(Confirmedbookingweek);

// month Bookings

router
    .route("/Confirmed/month")
    .get(ConfirmedBookingmonth);

// year Bookings

router
    .route("/Confirmed/year")
    .get(ConfirmedBookingyear);

/* --------------- recent Bookings chart --------------- */

// day Bookings

router
    .route("/recent/day")
    .get(recentBookingday);

// week Bookings

router
    .route("/recent/week")
    .get(recentBookingweek);

// month Bookings

router
    .route("/recent/month")
    .get(recentBookingmonth);

// year Bookings

router
    .route("/recent/year")
    .get(recentBookingyear);

module.exports = router;