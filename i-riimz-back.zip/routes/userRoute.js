const express = require("express");
const {
    register,
    registerUser,
    login,
    deleteRecord,
    logout,
    singleUser,
    getallUsers,
    verifyotp,
    updateusers,
    forgetpassword,
    verifyforgetpassword,
    updatePassword
} = require("../controllers/UserController");

const { isAuthenticatedUser, authorizeRoles } = require("../middleware/auth");

const router = express.Router();

router.route("/register").post(register);

router.route("/registerUser").post(registerUser);

router.route("/verifyotp").post(verifyotp);

router.route("/login").post(login);

router.route("/forgetpassword/:mobile").post(forgetpassword);

router.route("/verifyforgetpassword/:mobile").post(verifyforgetpassword);

router.route("/updatePassword/:mobile").put(updatePassword);

router.route("/updateusers/:mobile").put(updateusers);

router.route("/logout").get(logout);

router.route("/singleRecord/:mobile").get(singleUser);

router.route("/all").get(getallUsers);

router.route("/deleteRecord/:id").delete(deleteRecord);



module.exports = router;