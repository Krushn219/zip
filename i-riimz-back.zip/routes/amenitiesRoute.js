const express = require('express');
const multer = require('multer');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const {
    createamenitiess,
    getallamenitiess,
    getsingleamenitiess,
    updateamenitiess,
    deleteamenitiess,
    aminitiesToHotel
} = require("../controllers/amenitiesController");

// multer image

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const filePath = "uploads/" + "/amenities";
        fs.mkdirSync(filePath, { recursive: true })
        cb(null, filePath)
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname))
    }
})
let upload = multer({
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 * 5,
    },
}).single("image");

//Create
router
    .route("/create")
    .post(upload, createamenitiess);

//Get All
router
    .route("/all")
    .get(getallamenitiess);

//Get Single
router
    .route("/single/:id")
    .get(getsingleamenitiess);

// Update amenitiess
router
    .route("/update/:id")
    .put(upload, updateamenitiess)

// Delete Single amenities
router
    .route("/delete/:id")
    .delete(deleteamenitiess);

// Aminities pushing in Hotel DATA
router.route("/select/hotelId/:hotelId").put(aminitiesToHotel)

module.exports = router;