const express = require('express');
const router = express.Router();
const {
    createHotelAbout,
    getAllAboutHotel,
    getSingleAboutHotel,
    updateAboutHotel,
    deleteAboutHotel,
    getAboutHotelByUser
} = require("../controllers/hotelAboutController");

//Create
router
    .route("/create")
    .post(createHotelAbout);


//Get All
router
    .route("/all")
    .get(getAllAboutHotel);


//Get Single About Hotel
router
    .route("/single/:id")
    .get(getSingleAboutHotel);


// Update About Hotels
router
    .route("/update/:id")
    .put(updateAboutHotel)


// Delete Single About Hotel
router
    .route("/delete/:id")
    .delete(deleteAboutHotel);


// Get About Hotel By Hotel & AdminUser 
router
    .route("/:hotelId")
    .get(getAboutHotelByUser);

module.exports = router;