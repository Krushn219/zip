const express = require("express");
const {
    registeradmin,
    login,
    deleteRecord,
    editRecord,
    logout,
    singleadmin,
    updatePassword,
    forgetpassword,
    getalladmins
} = require("../controllers/adminController");
const { isAuthenticatedUser, authorizeRoles } = require("../middleware/auth");

const router = express.Router();

router.route("/register").post(registeradmin);

router.route("/login").post(login);

router.route("/logout").get(logout);

router.route("/singleRecord/:id").get(singleadmin);

router.route("/all").get(getalladmins);

router.route("/editRecord/:id").put(editRecord);

router.route("/deleteRecord/:id").delete(deleteRecord);

router.route("/forgetpassword").post(forgetpassword);

router.route("/password/update/:email").put(updatePassword);

module.exports = router;