const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const router = express.Router();

const {
    createRoom,
    getAllRooms,
    getSingleRoom,
    updateRoom,
    deleteRoom,
    RoomByHotel
} = require("../controllers/roomController");

// multer image

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const filePath = "uploads/" + "/rooms";
        fs.mkdirSync(filePath, { recursive: true })
        cb(null, filePath)
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname))
    }
})
let upload = multer({
    storage: storage,
    // limits: {
    //   fileSize: 1024 * 1024 * 5,
    // },
}).single("cover_photo");

//Create

router
    .route("/create")
    .post(upload, createRoom);

//Get All

router
    .route("/all")
    .get(getAllRooms);

//Get Single

router
    .route("/single/:id")
    .get(getSingleRoom);

// Update blogs

router
    .route("/update/:id")
    .put(upload, updateRoom)

// Delete Single Blog

router
    .route("/delete/:id")
    .delete(deleteRoom);

// Rooms By Hotel Id
router
    .route("/hotelId/:hotelId")
    .get(RoomByHotel);

module.exports = router;