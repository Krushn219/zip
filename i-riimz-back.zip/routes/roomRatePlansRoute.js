const express = require('express');
const router = express.Router();
const {
    createRoomRatePlan,
    getAllRoomRatePlan,
    getSingleRoomRatePlan,
    updateRatePlan,
    deleteRoomRatePlan,
    hotelRoomRatePlan
} = require("../controllers/roomRatePlanController");

//Create

router
    .route("/create")
    .post(createRoomRatePlan);

//Get All

router
    .route("/all")
    .get(getAllRoomRatePlan);

//Get Single

router
    .route("/single/:id")
    .get(getSingleRoomRatePlan);

// Update 
router
    .route("/update/:id")
    .put(updateRatePlan)

// Delete Single 

router
    .route("/delete/:id")
    .delete(deleteRoomRatePlan);

// Room Rate Plan By Hotel Id
router
    .route("/hotelId/:hotelId")
    .get(hotelRoomRatePlan);

module.exports = router;