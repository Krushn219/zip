const express = require('express');
const router = express.Router();
const {
    createtravelagent,
    getalltravelagent,
    getsingletravelagent,
    updatetravelagent,
    deletetravelagent
} = require("../controllers/travelagentController");

//Create

router
    .route("/create")
    .post(createtravelagent);

//Get All

router
    .route("/all")
    .get(getalltravelagent);

//Get Single

router
    .route("/single/:id")
    .get(getsingletravelagent);

// Update travelagent

router
    .route("/update/:id")
    .put(updatetravelagent)

// Delete Single enquiry

router
    .route("/delete/:id")
    .delete(deletetravelagent);

module.exports = router;