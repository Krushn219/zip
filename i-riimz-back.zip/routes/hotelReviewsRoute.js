const express = require('express');
const router = express.Router();

const {
    createcheckInReview,
    createcheckOutReview,
    getAllReviews,
    getSingleReview,
    updateReview,
    deleteReview,
    hotelReview,
    updateReviewStatus,
    checkInReviews,
    checkOutReviews,
    allhotelReview,
    getcheckInReviews
} = require("../controllers/hotelReviewController");

//create checkIn Review

router
    .route("/createcheckIn/:hotel_id")
    .post(createcheckInReview);

//create checkOut Review

router
    .route("/createcheckOut/:hotel_id")
    .post(createcheckOutReview);

//Get All

router
    .route("/all")
    .get(getAllReviews);

router
    .route("/allReviews/:reviewstatus")
    .get(getcheckInReviews);

//Get Single

router
    .route("/single/:id")
    .get(getSingleReview);

// Update reviews

router
    .route("/update/:id")
    .put(updateReview)

// Delete Single review

router
    .route("/delete/:id")
    .delete(deleteReview);

// Update reviews status

router
    .route("/updateStatus/:id")
    .put(updateReviewStatus);

// Review By Hotel Id

router
    .route("/hotelId/:hotelId")
    .get(hotelReview);

// Review By all Hotel Id

router
    .route("/allhotel")
    .get(allhotelReview);
// router
//     .route("/adminId/:adminId/hotelId/:hotelId")
//     .get(hotelReview); 

//get checkIn Reviews

router
    .route("/checkInReviews")
    .get(checkInReviews);

//get checkOut Reviews

router
    .route("/checkOutReviews")
    .get(checkOutReviews);

module.exports = router;