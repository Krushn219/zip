const express = require("express");
const {
    paypayment,
    paymentResponse,
    paymentAtHotel
} = require("../controllers/PaymentController");

const { isAuthenticatedUser, authorizeRoles } = require("../middleware/auth");
const router = express.Router();

router.route("/success").post(paypayment);
router.route("/pay-res").get(paymentResponse);
router.route("/pay-at-hotel/:id").post(paymentAtHotel);

module.exports = router;
