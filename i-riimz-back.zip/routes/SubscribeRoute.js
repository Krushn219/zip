const express = require('express');
const router = express.Router();
const {
    createSubscribe,
    getallSubscribe,
    Subscribelist,
    getsingleSubscribe,
    updateSubscribe,
    deleteSubscribe
} = require("../controllers/SubscribeController");

//Create

router
    .route("/create")
    .post(createSubscribe);

//Get All

router
    .route("/all")
    .get(getallSubscribe);

// Subscribe alldow.

router
    .route("/csvlist")
    .get(Subscribelist);

//Get Single

router
    .route("/single/:id")
    .get(getsingleSubscribe);

// Update Subscribe

router
    .route("/update/:id")
    .put(updateSubscribe)

// Delete Single agent

router
    .route("/delete/:id")
    .delete(deleteSubscribe);

module.exports = router;