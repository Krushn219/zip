const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const {
    createcoupans,
    getallcoupans,
    getsinglecoupans,
    updatecoupans,
    deletecoupans,
    getdatecoupans
} = require("../controllers/coupanController");
// multer image

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        // cb(null, path.join(__dirname, "..", AVATAR_PATH))
        // cb(null, path.join('uploads'))
        const filePath = "uploads/" + "/";
        fs.mkdirSync(filePath, { recursive: true })
        cb(null, filePath)
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + "-" + Date.now() + path.extname(file.originalname))
    }
})
// aws image

let upload = multer({
    // storage: multer.memoryStorage(),
    storage: storage,
    limits: {
        fileSize: 1024 * 1024 * 5,
    },
    fileFilter: function (req, file, done) {
        if (
            file.mimetype === "image/jpeg" ||
            file.mimetype === "image/png" ||
            file.mimetype === "image/webp" ||
            file.mimetype === "image/svg+xml" ||
            file.mimetype === "image/jpg"
        ) {
            done(null, true);
        } else {
            //prevent the upload
            var newError = new Error("File type is incorrect");
            newError.name = "MulterError";
            done(newError, false);
        }
    },
}).single("image");
//Create

router
    .route("/create")
    .post(upload, createcoupans);

//Get All

router
    .route("/all")
    .get(getallcoupans);

// selected-date(coupan)

router
    .route("/date/all")
    .get(getdatecoupans);

//Get Single

router
    .route("/single/:id")
    .get(getsinglecoupans);

// Update coupans

router
    .route("/update/:id")
    .put(upload, updatecoupans)

// Delete Single coupan

router
    .route("/delete/:id")
    .delete(deletecoupans);

module.exports = router;