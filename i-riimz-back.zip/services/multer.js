const multer = require('multer');
const path = require('path')

const ALLOWED_FORMAT = ['image/jpeg', 'image/png', 'image/jpg'];
// var resizer = sharp().resize(200, 200).png()

const uploadFolder = path.join(__dirname, '../uploads');
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadFolder)
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
    cb(null, file.fieldname + '-' + uniqueSuffix + '.' + file?.originalname?.split('.')[1])
  }
})

exports.upload = multer({
  storage,
  fileFilter: function (req, file, cb) {

    if (ALLOWED_FORMAT.includes(file.mimetype)) {

      cb(null, true);
    } else {
      cb(new Error('Not supported file format!'), false);
    }
  }
});




