<!-- i-Roomz details -->

name = i-Roomz.com

<!-- cronTime: '00 */3 * * * * ' => Executes in every 3 seconds. -->

<!-- cronTime: '* */1 * * * * ' => MEANING LESS. Executes every one second. -->

<!-- cronTime: '00 */1 * * * * ' => Executes every 1 minute. -->

<!-- cronTime: '00 30 11 * * 0-5 ' => Runs every weekday (Monday to Friday) @ 11.30 AM -->

<!-- cronTime: '00 56 17 * * * ' => Will execute on every 5:56 PM -->

<!-- [Title](https://handlebarsjs.com/guide/builtin-helpers.html#if) -->
