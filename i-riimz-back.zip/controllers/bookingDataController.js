const ApiFeatures = require("../utils/apifeatures");
const ErrorHandler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const BookingData = require("../models/bookingData");


// create Booking

module.exports.createBookingData = catchAsyncErrors(async (req, res) => {

    try {

        const bookingData = await BookingData.create(req.body)
        if (!bookingData) {
            return res.status(400).json({
                status: false,
                message: error
            });
        }
        return res.status(201).json({
            status: true,
            msg: "Booking Data Created Successfully..."
        });

    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }
});

//get all Booking

module.exports.getAllBookingData = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;
    try {
        let totalBooking = await BookingData.countDocuments();
        // const sort = {};
        const sort = { createdAt: -1 };

        if (req.query.sortBy && req.query.hotel) {
            sort[req.query.sortBy] = req.query.booking === "desc" ? -1 : 1;
        }

        const apiFeature = new ApiFeatures(BookingData.find().sort(sort), req.query)
            .filter()
            .search()
            .pagination(resultPerPage)
        let bookingData = await apiFeature.query;

        let filteredBookingCount = bookingData.length;

        return res.status(200).json({
            status: true,
            totalBooking,
            filteredBooking: filteredBookingCount,
            page: req.query.page,
            limit: resultPerPage,
            bookingData,
        });

    } catch (error) {
        return res.status(404).json({
            success: false,
            message: error.messager
        })
    }


});

//getSingle hotel

module.exports.getSingleBookingData = catchAsyncErrors(async (req, res, next) => {
    try {

        let bookingData = await BookingData.findOne({ "data.bookingId": req.params.bookingId })
        if (!bookingData) {
            return next(new ErrorHandler("Booking Not Found", 404));
        } else {
            return res.status(200).json({
                status: true,
                bookingData,
            });
        }
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

});

// update Status

module.exports.updateBookingData = catchAsyncErrors(async (req, res, next) => {
    try {
        const bookingId = req.params.id;
        const updatedStatus = "CANCELLED";

        let bookingData = await BookingData.findOne({ "data.bookingId": bookingId })
        if (!bookingData) {
            return next(new ErrorHandler("Booking Not Found", 404));
        }

        const id = await bookingData.id;

        const updatedBookingData = await BookingData.findByIdAndUpdate(
            id,
            { "data.bookingStatus": updatedStatus },
            { new: true }
        );

        if (!updatedBookingData) {
            return res.status(404).json({
                status: false,
                message: "Booking data not found",
            });
        }

        return res.status(200).json({
            status: true,
            msg: "Updated Successfully....",
            data: updatedBookingData,
        });
    } catch (error) {
        console.log("error+++", error);
        return res.status(400).json({
            status: false,
            message: error,
        });
    }
}
)