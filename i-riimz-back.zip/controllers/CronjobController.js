const axios = require("axios");
const moment = require("moment");
const ApiFeatures = require("../utils/apifeatures");
const Booking = require("../models/roomBookingsModel");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const date_IST = require("../utils/new_date");
const { reviewEmail, serviceEmail } = require("../utils/sendmailerurl");

module.exports.Sendcheckinmail = catchAsyncErrors(async () => {
    try {
        var check_date = moment().format('YYYY-MM-DDT00:00:00.000+00:00')
        const apiFeature = new ApiFeatures(Booking.find({
            "checkInDate": { '$eq': check_date }, "paymentStatus": { '$eq': "Confirmed" }
        }))
        let Bookings = await apiFeature.query;
        for (let i = 0; i < Bookings.length; i++) {
            var id = Bookings[i].bookingId
            const config = {
                headers: {
                    "X-SF-API-KEY": process.env.X_SF_API_KEY
                }
            }
            await axios
                .get(
                    `https://api.stayflexi.com/core/api/v1/beservice/bookinginfo?bookingId=${id}`,
                    config,
                    null)
                .then(async function (response) {
                    const new_date = date_IST();
                    var date = new_date.toLocaleString();
                    var checkin = moment(new Date(date.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('DD MMM YYYY')
                    var actualdate = moment(new Date(response.data.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('DD MMM YYYY')

                    if (response.data.bookingStatus == "CONFIRMED" && checkin == actualdate) {
                        // var mail = "drashtigreewebsolutions@gmail.com"
                        var mail = response.data.customerDetails.emailId
                        var hotel_id = response.data.hotelId
                        var hotel_name = response.data.hotelName
                        await serviceEmail(mail, hotel_id, hotel_name)
                    }
                })
                .catch(function (error) {
                    return console.log("error.message:--", error);
                })
        }
    } catch (error) {
        console.log("error:--", error);
    }
});

module.exports.SendcheckOutmail = catchAsyncErrors(async () => {
    try {
        var checkOut_Date = moment().subtract(1, 'days').format('YYYY-MM-DDT00:00:00.000+00:00')
        const apiFeature = new ApiFeatures(Booking.find({
            "checkOutDate": { '$eq': checkOut_Date }, "paymentStatus": { '$eq': "Confirmed" }
        }))
        let Bookings = await apiFeature.query;


        for (let i = 0; i < Bookings.length; i++) {
            var id = Bookings[i].bookingId

            const config = {
                headers: {
                    "X-SF-API-KEY": process.env.X_SF_API_KEY
                }
            };
            await axios
                .get(
                    `https://api.stayflexi.com/core/api/v1/beservice/bookinginfo?bookingId=${id}`,
                    config,
                    null)
                .then(async function (response) {

                    function date_IST() {
                        return moment().tz('Asia/Kolkata').toDate();
                    }

                    const new_date = date_IST();
                    var date = new_date.toLocaleString();
                    var checkin = moment(new Date(date.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).subtract(1, 'days').format('DD MMM YYYY')
                    var checkintime = moment(new Date(date.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('hh:mm A')
                    var actualdate = moment(new Date(response.data.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('DD MMM YYYY')
                    var actualdatetime = moment(new Date(response.data.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('hh:mm A')

                    if (response.data.bookingStatus == "CONFIRMED" && checkintime == actualdatetime && checkin == actualdate) {

                        // var mail = "drashtigreewebsolutions@gmail.com"

                        var mail = response.data.customerDetails.emailId
                        var hotel_id = response.data.hotelId
                        var hotel_name = response.data.hotelName
                        await reviewEmail(mail, hotel_id, hotel_name)
                    }
                })
                .catch(function (error) {
                    return console.log("error.message:--", error);
                })
        }
    } catch (error) {
        console.log("error:--", error);
    }
});
