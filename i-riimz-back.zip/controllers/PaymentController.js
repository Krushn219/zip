const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const payment = require("../models/paymentsModel");
const Booking = require("../models/roomBookingsModel");
const crypto = require("crypto");
const moment = require("moment");
require("dotenv").config();

// payment success

module.exports.paypayment = catchAsyncErrors(async (req, res, next) => {
    try {
        const {
            orderCreationId,
            razorpayPaymentId,
            razorpayOrderId,
            razorpaySignature,
        } = req.body;

        if (req.body.status === "Cancelled") {
            const Bookings = await Booking.findById(
                req.body.orderUniqueId
            );
            if (!Bookings) {
                return next(new ErrorHandler("Booking not found with this Id", 404));
            }
            // Bookings.paymentStatus = req.body.status;
            // var date = new Date()
            // Bookings.discription = "razorpay manual cancel";
            // Bookings.CancelledAt = moment(date).subtract(330, 'minutes').toDate();
            // await Bookings.save({ validateBeforeSave: false });
            // if (Bookings) {
            await Bookings.remove();
            // }
            return res.status(200).json({
                // Bookings,
                success: true,
            });
        }

        const shasum = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET);
        shasum.update(`${razorpayOrderId}|${razorpayPaymentId}`);
        const digest = shasum.digest("hex");

        if (digest !== razorpaySignature)
            return res.status(400).json({ msg: "Transaction not legit!" });

        const Ordercreate = await payment.create({
            razorpay: {
                order_Creation_Id: orderCreationId,
                razorpay_Payment_Id: razorpayPaymentId,
                razorpay_Order_Id: razorpayOrderId,
                razorpay_Signature: razorpaySignature,
            },
        });

        if (!Ordercreate) {
            return res.status(400).json({ msg: "Something Went Wrong.." });
        }

        const Bookings = await Booking.findById(
            req.body.orderUniqueId
        );

        if (!Bookings) {
            return next(new ErrorHandler("Booking not found with this Id", 404));
        }
        Bookings.paymentStatus = "Confirmed"
        Bookings.bookingId = orderCreationId
        await Bookings.save({ validateBeforeSave: false });

        return res.json({
            msg: "Success",
            orderId: razorpayOrderId,
            paymentId: razorpaySignature,
        });
    } catch (error) {
        res.status(500).send(error);
    }
});

// paymentResponse

module.exports.paymentResponse = catchAsyncErrors(async (req, res) => {
    const payments = await payment.find();
    return res.status(200).json({
        payments,
    });
});

//payment at hotel

module.exports.paymentAtHotel = catchAsyncErrors(async (req, res) => {
    const id = req.params.id

    console.log("id++++", id)

    const {
        bookingId
    } = req.body;
    try {
        const bookingData = await Booking.findById(id)
        if (!bookingData) {
            return next(new ErrorHandler("Booking not found with this Id", 404));
        }


        bookingData.bookingId = bookingId
        await bookingData.save({ validateBeforeSave: false });

        return res.status(200).json({
            msg: "Success",

        });
    } catch (error) {
        res.status(500).send(error);
    }
})
