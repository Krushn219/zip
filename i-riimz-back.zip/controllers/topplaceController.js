const topplace = require("../models/topplaceModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const AWS = require("aws-sdk");
const fs = require("fs");

const bucketName = process.env.AWS_S3_BUCKET_NAME;
const awsConfig = {
    accessKeyId: process.env.AWS_S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_S3_SECRET_ACCESS_KEY,
    // region: process.env.region,
};
const S3 = new AWS.S3(awsConfig);
// create topplaces

module.exports.createtopplaces = catchAsyncErrors(async (req, res) => {

    var img = [];
    var imgkey = [];

    //upload to s3

    const uploadToS3 = (fileData, minetype, name) => {
        return new Promise((resolve, reject) => {
            const params = {
                Bucket: bucketName,
                Key: `topplace/${name}`,
                Body: fileData,
                ContentType: minetype,
            };
            S3.upload(params, async (err, data) => {
                if (err) {
                    console.log(err);
                    return reject(err);
                }
                img.push(data.Location);
                imgkey.push(data.Key);
                return resolve(data);
            });

        },
        );
    };

    if (req.file) {
        const pathname = req.file.path;
        const minetype = req.file.mimetype;
        const fileContent = fs.readFileSync(pathname)
        var string = pathname.split("/");
        const name = string[1]
        var imgname = req.file.filename
        await uploadToS3(fileContent, minetype, imgname);
    }
    const image = img[0];
    const key = imgkey[0];

    const topplaces = await topplace.create({
        image: image,
        key: key,
        city: req.body.city,
        accommodation: req.body.accommodation,
        start_price: req.body.start_price
    });

    let resultHandler = function (err) {
        if (err) {
            console.log("Unlink Failed", err);
        } else {
            console.log("File Deleted");
        }
    }

    fs.unlink(req.file.path, resultHandler);
    if (!topplaces) {
        return res.status(500).send("Topplaces Cannot Be Created");
    }
    return res.status(201).json({
        status: true,
        topplaces,
    });
});

//get all topplace

module.exports.getalltopplaces = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totaltopplace = await topplace.countDocuments();
    // const sort = {};
    const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.topplace) {
        sort[req.query.sortBy] = req.query.topplace === "desc" ? -1 : 1;
    }
    const apiFeature = new ApiFeatures(topplace.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let topplaces = await apiFeature.query;
    let filteredtopplaceCount = topplaces.length;

    return res.status(200).json({
        status: true,
        totaltopplace,
        filteredtopplace: filteredtopplaceCount,
        page: req.query.page,
        limit: resultPerPage,
        topplaces,
    });
});
// module.exports.getalltopplaces = catchAsyncErrors(async (req, res) => {
//   const topplaces = await topplace.find();
//   const total = await topplace.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     topplaces,
//   });
// })

//getSingle topplace

module.exports.getsingletopplaces = catchAsyncErrors(async (req, res, next) => {
    let topplaces = await topplace.findById(req.params.id);
    if (!topplaces) {
        return next(new errorhandaler("Topplaces Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            topplaces,
        });
    }
});

//Update topplace

module.exports.updatetopplaces = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let topplaces = await topplace.findById(id);
    if (!topplaces) {
        return res.status(404).json({ msg: "Cannot Found Topplaces.." });
    }
    if (!req.file) {
        const data = {
            city: req.body.city || topplaces.city,
            accommodation: req.body.accommodation || topplaces.accommodation,
            start_price: req.body.start_price || topplaces.start_price,
            image: topplaces.image,
        };
        const updatetopplace = await topplace.findByIdAndUpdate(id, data, {
            new: true,
        });
        return res.status(200).json({
            status: true,
            msg: "Updated Successfully...",
            updatetopplace,
        });
    }

    var img = [];
    var imgkey = [];

    //upload to s3

    const uploadToS3 = (fileData, minetype, name) => {
        return new Promise((resolve, reject) => {
            const params = {
                Bucket: bucketName,
                Key: `topplace/${name}`,
                Body: fileData,
                ContentType: minetype,
            };
            S3.upload(params, async (err, data) => {
                if (err) {
                    console.log(err);
                    return reject(err);
                }
                imgkey.push(data.Key);
                img.push(data.Location);
                return resolve(data);
            });

        },
        );
    };

    if (req.file) {
        const pathname = req.file.path;
        const minetype = req.file.mimetype;
        const fileContent = fs.readFileSync(pathname)
        var string = pathname.split("/");
        var imgname = req.file.filename
        const name = string[1]
        await uploadToS3(fileContent, minetype, imgname);
    }
    const image = img[0];
    const key = imgkey[0];

    const data = {
        city: req.body.city || topplaces.city,
        accommodation: req.body.accommodation || topplaces.accommodation,
        start_price: req.body.start_price || topplaces.start_price,
        image: image,
        key: key,
    };
    var finddata = await topplace.findById(id);

    const updatetopplace = await topplace.findByIdAndUpdate(id, data, {
        new: true,
    });
    S3.deleteObject({
        Bucket: bucketName,
        Key: finddata.key
    }, async function (err) {
        if (err) {
            return res.status(500).json({
                message: err
            });
        }
    })
    let resultHandler = function (err) {
        if (err) {
            console.log("Unlink Failed", err);
        } else {
            console.log("File Deleted");
        }
    }

    fs.unlink(req.file.path, resultHandler);
    if (!topplaces) {
        return res.status(500).send("Topplaces Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updatetopplace,
    });
});

//Delete topplace

module.exports.deletetopplaces = catchAsyncErrors(async (req, res) => {
    try {
        const finddata = await topplace.findById(req.params.id);
        S3.deleteObject({
            Bucket: bucketName,
            Key: data.key
        }, async function (err) {
            await finddata.remove();
            if (err) {
                return res.status(500).json({
                    message: err
                });
            } else {
                return res.status(200).json({
                    message: "topplace Deleted Successfully"
                });
            }
        })
        if (!finddata) {
            return res.status(400).json({
                message: "topplace Not Found"
            });
        }
    } catch (err) {

        return res.status(500).json({ err });
    }
});
