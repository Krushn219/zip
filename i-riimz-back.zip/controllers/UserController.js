const ErrorHandler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const User = require("../models/userModel");
const sendToken = require("../utils/jwtToken");
const ApiFeatures = require("../utils/apifeatures");
const sendSms = require("../utils/sendSms");
const otps = require("../models/otp");
const generateOTPFunc = require("../utils/otp");
const shortid = require("shortid");

// Register user

module.exports.registerUser = catchAsyncErrors(async (req, res, next) => {
    try {
        //Validate mobile input
        const mobile = req.body.mobile;
        if (!mobile) {
            return next(new ErrorHandler("Mobile Number Is Required...", 404));
        }
        const oldUser = await User.findOne({ mobile }).select("+password");
        if (!oldUser) {
            return res.status(401).json({ message: "User Does Not Exist. Please Check" });
        }
        const isPasswordMatched = await oldUser.comparepassword(req.body.Currentpass);
        if (!isPasswordMatched) {
            return res.status(400).json({
                status: false,
                message: "Password Does Not Match..",
            });
        }
        return res.status(200).json({
            status: true,
            msg: "User Verified  Successfully...",
            oldUser,
        });
    } catch (error) {
        return res.status(404).json({
            msg: "Something Went Wrong..",
            error,
        });
    }
});

// Register 

module.exports.register = catchAsyncErrors(async (req, res, next) => {
    try {
        //Validate mobile input
        const mobile = req.body.mobile;
        if (!mobile) {
            return next(new ErrorHandler("Mobile Number Is Required...", 404));
        }
        //generate OTP
        const generate6digitOTp = generateOTPFunc();
        const _id = `otp_${shortid.generate()}`;

        const otpData = new otps({
            _id,
            mobile,
            otp: generate6digitOTp,
            expiresIn: new Date(Date.now() + 5 * 60 * 1000).getTime(),
        });
        const Otp = await otps.findOne({ mobile, status: "Register" });
        if (Otp) {
            await Otp.remove();
        }
        await otpData.save();

        const data = {
            otp: generate6digitOTp,
        };
        await sendSms(mobile, data.otp);

        // console.log("await sendSms(mobile, data.otp);", await sendSms(mobile, data.otp));

        res.status(200).json({
            status: true,
            msg: "OTP sent to your mobile number.Please check",
            // otpData,
        });
    } catch (error) {
        res.status(404).json({
            msg: "Something Went Wrong..",
            error,
        });
    }
});

// verifyotp user

module.exports.verifyotp = catchAsyncErrors(async (req, res, next) => {
    const { mobile, otp } = req.body;

    // Validate user input
    if (!(mobile && otp)) {
        return res.status(400).json({ message: "Mobile Number Or OTP Not Found" });
    }

    const userOtp = await otps.findOne({ mobile, otp, status: "Register" });

    if (!userOtp) {
        return res.status(400).json({ message: "Invalid Mobile Number or OTP" });
    } else {
        // check if user already exist
        const oldUser = await User.findOne({ mobile });
        if (oldUser) {
            const userOtp = await otps.findOne({ status: "Register", mobile });
            if (!userOtp) {
                return res.status(401).json({ message: "User Does Not Exist. Please Check Otp" });
            }
            await userOtp.remove();

            return res.status(200).json({
                message: "User Already Exist. Please Login",
                oldUser
            });
        }
        return res.status(201).json({
            msg: "User Verified  Successfully..."
        });
    }
});

// Login User

module.exports.login = catchAsyncErrors(async (req, res, next) => {
    const { full_name, email, password, mobile } = req.body;

    //Validate user input

    const oldUser = await User.findOne({ mobile });
    if (oldUser) {
        return res.status(401).json({ message: "User Already Exist. Please Check" });
    } else {
        if (!(email && password && full_name && mobile)) {
            return next(new ErrorHandler("All Inputs Are Required...", 404));
        }
        if (req.body.password !== req.body.confirmPassword) {
            return res.json({
                status: false,
                message: "Password Does Not Match..",
            });
        }
        // Create user in our database
        const user = await User.create({
            full_name,
            email: email.toLowerCase(), // sanitize: convert email to lowercase
            password,
            mobile,
            mobile_verified: true,
            // role: req.body.role || "user",
        });
        const userOtp = await otps.findOne({ status: "Register", mobile });
        if (!userOtp) {
            return res.status(401).json({ message: "User Does Not Exist. Please Check" });
        }
        await userOtp.remove();

        return res.status(201).json({
            msg: "User Verified And Created Successfully...",
            user,
        });
    }
});

// Logout User

// module.exports.logout = catchAsyncErrors(async (req, res, next) => {
//     res.cookie("token", null, {
//         expires: new Date(Date.now()),
//         httpOnly: true,
//     });

//     res.status(200).json({
//         status: true,
//         message: "Logged Out",
//     });
//     next();
// });
module.exports.logout = catchAsyncErrors(async (req, res, next) => {
    try {
        if (req.session) {
            req.session.destroy()
            res.status(200).json({
                status: true,
                message: "Logged Out",
            });
            next();
        }

    } catch (error) {
        console.log(error.message);
        return res.status(200).json({
            status: false,
            message: error
        })
    }
});
// Delete User

module.exports.deleteRecord = catchAsyncErrors(async (req, res, next) => {
    let id = req.params.id;
    const Record = await User.findByIdAndDelete({ _id: id });
    if (!Record) {
        return res.json({
            status: false,
            message: "User No Found..",
        });
    }
    res.status(200).json({
        status: true,
        msg: "User Deleted Successfully...",
    });
});

// Single User

module.exports.singleUser = catchAsyncErrors(async (req, res, next) => {
    var mobile = req.params.mobile
    const Details = await User.findOne({ mobile })
    if (!Details) {
        return res.json({
            status: false,
            message: "Details No Found..",
        });
    }
    res.status(200).json({
        status: true,
        Details,
    });
});

// Get All User

exports.getallUsers = catchAsyncErrors(async (req, res, next) => {
    const Userall = await User.find();
    if (!Userall) {
        return next(new ErrorHandler("User Not Found...", 404));
    }
    let count = Userall.length;

    return res.status(200).json({
        status: true,
        user: count,
        Userall,
    });
});

// Update users

module.exports.updateusers = catchAsyncErrors(async (req, res) => {
    let mobile = req.params.mobile;
    let users = await User.findOne({ mobile });
    if (!users) {
        return res.status(404).json({ msg: "Cannot Found Users.." });
    }
    const data = {
        full_name: req.body.full_name || users.full_name,
        email: req.body.email || users.email,
        mobile: users.mobile,
        password: users.password,
    };
    var id = users._id

    const updateusers = await User.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updateusers,
    });

});

// fotget password

module.exports.forgetpassword = catchAsyncErrors(async (req, res, next) => {
    try {
        //Validate mobile input
        const mobile = req.params.mobile;
        if (!mobile) {
            return next(new ErrorHandler("Mobile Number Is Required...", 404));
        }
        //generate OTP

        const generate6digitOTp = generateOTPFunc();
        const _id = `otp_${shortid.generate()}`;

        const otpData = new otps({
            _id,
            mobile,
            status: "ForgrtPass",
            otp: generate6digitOTp,
            expiresIn: new Date(Date.now() + 5 * 60 * 1000).getTime(),
        });
        const Otp = await otps.findOne({ mobile, status: "ForgrtPass" });
        if (Otp) {
            await Otp.remove();
        }

        await otpData.save();

        const data = {
            otp: generate6digitOTp,

        };
        await sendSms(mobile, data.otp);

        res.status(200).json({
            status: true,
            msg: "Otp Sent To Your Mobile Number Please Check",
            // otpData,
        });
    } catch (error) {
        res.status(404).json({
            message: "Unable To Send Mobile",
            error: error
        });
    }
});

// fotget password

module.exports.verifyforgetpassword = catchAsyncErrors(async (req, res, next) => {

    const { otp, password } = req.body;
    var mobile = req.params.mobile

    // Validate user input
    if (!(mobile && otp)) {
        return res.status(400).json({ message: "Mobile Number Or OTP Not Found" });
    }

    const userOtp = await otps.findOne({ mobile, otp, status: "ForgrtPass" });
    if (!userOtp) {
        return res.status(400).json({ message: "Invalid Mobile Or Otp" });
    }
    // check if user already exist
    const oldUser = await User.findOne({ mobile });
    if (oldUser) {
        const userOtp = await otps.findOne({ mobile, status: "ForgrtPass" });
        if (!userOtp) {
            return res.status(400).json({ message: "User Does Not Exist. Please Check" });
        }
        await userOtp.remove();
    }

    const user = await User.findOne({ mobile });
    try {
        user.password = req.body.password;
        await user.save();
        return res.json({
            status: true,
            user
        });
    } catch (error) {
        return res.status(400).send({
            status: false,
            message: "Unable To Send Mobile",
            error
        });
    }
});

// update password

exports.updatePassword = catchAsyncErrors(async (req, res, next) => {
    try {
        var mobile = req.params.mobile
        const user = await User.findOne({ mobile }).select("+password");
        if (!user) {
            return res.status(400).json({
                status: false,
                message: "User Does Not Exist..",
            });
        }
        const isPasswordMatched = await user.comparepassword(req.body.Currentpass);
        if (!isPasswordMatched) {
            return res.status(400).json({
                status: false,
                message: "Password Does Not Match..",
            });
        }
        if (req.body.password == req.body.Currentpass) {
            return res.status(400).json({
                status: false,
                message: "Please Enter Different Password",
            });
        }

        user.password = req.body.password;
        await user.save();

        return res.status(200).json({
            status: true,
            user
        });

    } catch (error) {
        return res.status(400).json({
            status: false,
            message: "Unable To Send Mobile",
            error: error
        });
    }

});