const Subscribe = require("../models/SubscribeModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const Errorhandler = require("../utils/errorhandler");
const CsvParser = require("json2csv").Parser;

// create Subscribes

module.exports.createSubscribe = catchAsyncErrors(async (req, res) => {
    const Subscribes = await Subscribe.create(req.body);
    if (!Subscribes) {
        return res.status(500).send("Something went wrong!!");
    }
    return res.status(200).json({
        status: true,
        message: "Email-Id Subscribed Successfully",
        Subscribes,
    });
});

//get all Subscribe

module.exports.getallSubscribe = catchAsyncErrors(async (req, res, next) => {

    const resultPerPage = Number(req.query.limit) || 10;
    let totalSubscribe = await Subscribe.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.Subscribe) {
        sort[req.query.sortBy] = req.query.Subscribe === "desc" ? -1 : 1;
    }
    const apiFeature = new ApiFeatures(Subscribe.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let Subscribes = await apiFeature.query;
    let filteredSubscribeCount = Subscribes.length;

    return res.status(200).json({
        status: true,
        totalSubscribe,
        filteredSubscribe: filteredSubscribeCount,
        page: req.query.page,
        limit: resultPerPage,
        Subscribes,
    });
});

// Subscribes list

module.exports.Subscribelist = catchAsyncErrors(async (req, res, next) => {
    try {
        const sort = {};
        if (req.query.sortBy && req.query.hotel) {
            sort[req.query.sortBy] = req.query.subscribe === "desc" ? -1 : 1;
        }
        const apiFeature = new ApiFeatures(Subscribe.find().sort(sort), req.query)
            .filter()
            .search()

        let Subscribes = await apiFeature.query;
        if (Subscribes.length == 0) {
            return next(new Errorhandler("Subscribe Not Found", 404));
        }
        var subscribe = [];

        Subscribes.forEach((obj) => {
            const { email, createdAt } = obj;
            var Date = obj.createdAt
            var CreatedAt = Date.toLocaleDateString();
            subscribe.push({ email, CreatedAt });
        });

        const csvFields = ["email", "CreatedAt"];
        const csvParser = new CsvParser({ csvFields });
        const csvData = csvParser.parse(subscribe);
        let rgx = /"/g;
        let removedQuotes = csvData.replace(rgx, '');
        const csvFileTxt = removedQuotes.toString()

        return res.status(200).end(
            csvFileTxt
        );
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

})

// module.exports.getallSubscribe = catchAsyncErrors(async (req, res) => {
//   const Subscribes = await Subscribe.find();
//   const total = await Subscribe.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     Subscribes,
//   });
// })

//getSingle Subscribe

module.exports.getsingleSubscribe = catchAsyncErrors(async (req, res, next) => {
    let Subscribes = await Subscribe.findById(req.params.id);
    if (!Subscribes) {
        return next(new errorhandaler("Subscribe Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            Subscribes,
        });
    }
});

//Update Subscribe

module.exports.updateSubscribe = catchAsyncErrors(async (req, res) => {

    let id = req.params.id;
    let Subscribes = await Subscribe.findById(id);
    if (!Subscribes) {
        return res.status(404).json({ msg: "Cannot Found Subscribe.." });
    }
    const data = {
        email: req.body.email || Subscribes.email,
    };
    try {
        const updatedSubscribe = await Subscribe.findByIdAndUpdate(id, data, {
            new: true,
        });
        return res.status(200).json({
            status: true,
            msg: "Updated Successfully....",
            updatedSubscribe,
        });
    } catch (error) {
        res.status(400).json({
            status: false,
            error,
        });
    }

});

//Delete Subscribe

module.exports.deleteSubscribe = catchAsyncErrors(async (req, res) => {
    try {
        const data = await Subscribe.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({
                message: "Subscribe Not Found"
            });
        }
        return res.status(200).json({
            message:
                "Subscribe Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({ err });
    }
});
