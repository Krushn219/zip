const ErrorHandler = require("../utils/errorhandler");
const admin = require("../models/adminModel");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const sendToken = require("../utils/jwtToken");
const bcrypt = require("bcryptjs");
const ApiFeatures = require("../utils/apifeatures");
const { forgetEmail } = require("../utils/sendmailerurl");
// Register admin

module.exports.registeradmin = catchAsyncErrors(async (req, res, next) => {
    const { email, password, name } = req.body;

    const isadminExist = await admin.findOne({ admin_email: req.body.email });

    if (isadminExist) {
        return res.status(401).json({
            status: false, message: 'Admin Already Exist With This Email Please Try With Different Email'
        });
        // return res.status(409).send("admin Already Exist. Please Login");
    }

    const Admin = await admin.create({
        admin_email: email,
        admin_name: name,
        // admin_mobile: mobile,
        password,

    });

    sendToken(Admin, 200, res);
});

// Login admin

module.exports.login = catchAsyncErrors(async (req, res, next) => {
    const { email, password } = req.body;
    // checking if admin has given password and email both
    if (!email || !password) {
        return res.json({
            status: false,
            message: "Please Enter Email & Password",
        });
    }
    const adminData = await admin.findOne({ admin_email: email }).select("+password");
    if (!adminData) {
        return res.json({
            status: false,
            message: "Invalid Email Or Password",
        });
    }
    const isPasswordMatched = await adminData.comparePassword(password);
    if (!isPasswordMatched) {
        return res.json({
            status: false,
            message: "Invalid Credentials..",
        });
    }
    sendToken(adminData, 200, res);
});

// Logout admin

module.exports.logout = catchAsyncErrors(async (req, res, next) => {
    res.cookie("token", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
    });

    res.status(200).json({
        status: true,
        message: "Logged Out",
    });
    next();
});

// Delete admin

module.exports.deleteRecord = catchAsyncErrors(async (req, res, next) => {
    let id = req.params.id;
    const Record = await admin.findByIdAndDelete({ _id: id });
    if (!Record) {
        return res.json({
            status: false,
            message: "Admin Not Found..",
        });
    }
    return res.status(200).json({
        status: true,
        msg: "Admin Deleted Successfully...",
    });
});

// Single admin

module.exports.singleadmin = catchAsyncErrors(async (req, res, next) => {
    const Details = await admin.findById(req.params.id);
    if (!Details) {
        return res.json({
            status: false,
            message: "Admin Details No found..",
        });
    }
    return res.status(200).json({
        status: true,
        Details,
    });
});

//get all admin

module.exports.getalladmins = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totaladmin = await admin.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.admin) {
        sort[req.query.sortBy] = req.query.admin === "desc" ? -1 : 1;
    }
    const apiFeature = new ApiFeatures(admin.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let admins = await apiFeature.query;
    let filteredadminCount = admins.length;

    return res.status(200).json({
        status: true,
        totaladmin,
        filteredadmin: filteredadminCount,
        page: req.query.page,
        limit: resultPerPage,
        admins,
    });
});

// Forget admin

module.exports.forgetpassword = catchAsyncErrors(async (req, res, next) => {
    const { email } = req.body;
    const checking = await admin.findOne({ admin_email: email });
    if (checking) {
        try {
            await forgetEmail(email)
            await res.status(200).json({
                status: true,
                msg: "Email Sent To Your Mail...Please Check",
            })

        } catch (err) {
            res.send({
                status: false,
                message: "Unable To Send email",
                err
            });
        }
    }
    else {
        res.send({
            status: false,
            message: "unable to send email",
            err
        });
    }

});

// Updatepassword admin

module.exports.updatePassword = catchAsyncErrors(async (req, res, next) => {
    const Admin = await admin.findOne({ admin_email: req.params.email });
    if (!Admin) {
        return res.json({
            status: false,
            message: "Admin does not exist..",
        });
    }
    if (req.body.newPassword !== req.body.confirmPassword) {
        return res.json({
            status: false,
            message: "password does not match..",
        });
    }
    Admin.password = req.body.newPassword;
    await Admin.save();
    return res.json({
        status: true,
        Admin
    });
});


module.exports.editRecord = catchAsyncErrors(async (req, res, next) => {
    const adminDetails = await admin.findById(req.params.id)
    if (!adminDetails) {
        return res.json({
            status: false,
            message: "admin not found..",
        });
    }
    try {
        if (req.body.password) {
            const hashpassword = bcrypt.hashSync(req.body.password, 10)
            const data = {
                admin_name: req.body.name || adminDetails.admin_name,
                admin_email: req.body.email || adminDetails.admin_email,
                admin_mobile: req.body.mobile || adminDetails.admin_mobile,
                access_control: req.body.access_control || adminDetails.access_control,
                status: req.body.status || adminDetails.status,
                // password: adminDetails.password || hashpassword,
            }
            const Details = await admin.findByIdAndUpdate(req.params.id, data, {
                new: true
            });
            return res.status(201).json({
                status: true,
                Details,
                message: "admin Updated Successfully",
            });
        }
        const data = {
            admin_name: req.body.name || adminDetails.admin_name,
            admin_email: req.body.email || adminDetails.admin_email,
            admin_mobile: req.body.mobile || adminDetails.admin_mobile,
            password: adminDetails.password,
            access_control: req.body.access_control || adminDetails.access_control,
            status: req.body.status || adminDetails.status,
        }
        const Details = await admin.findByIdAndUpdate(req.params.id, data, {
            new: true
        });
        return res.status(201).json({
            status: true,
            Details,
            message: "admin Updated Successfully",
        });
    } catch (error) {
        return res.status(404).json({
            status: "failed",
            error: error,
        });
    }
});