const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const Review = require("../models/hotelReviewsModel");

// create checkIn Review 

module.exports.createcheckInReview = catchAsyncErrors(async (req, res) => {

    const review = await Review.create(
        {
            hotel_id: req.params.hotel_id,
            username: req.body.username,
            title: req.body.title,
            description: req.body.description,
            happywithcheckin: req.body.happywithcheckin,
            happywithroom: req.body.happywithroom,
            happywithlocation: req.body.happywithlocation,
            didyoulike: req.body.didyoulike,
            didNotLike: req.body.didNotLike,
            reviewstatus: req.body.reviewstatus
        }
    );
    if (!review) {
        return res.status(500).send("Review Cannot Be Created");
    }
    return res.status(201).json({
        status: true,
        review,
    });
});

// create checkOut Review

module.exports.createcheckOutReview = catchAsyncErrors(async (req, res) => {

    // const hotelData = await Review.findOne({ hotel_id: req.body.hotel_id })

    const review = await Review.create(
        {
            hotel_id: req.params.hotel_id,
            username: req.body.username,
            title: req.body.title,
            description: req.body.description,
            rating: req.body.rating,
            reviewstatus: req.body.reviewstatus
        }
    );
    if (!review) {
        return res.status(500).send("Review Cannot Be Created");
    }
    return res.status(201).json({
        status: true,
        review,
    });
});

//get Reviewstatus

module.exports.getcheckInReviews = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit)
    let totalReviews = await Review.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.ReviewBy) {
        sort[req.query.sortBy] = req.query.ReviewBy === "desc" ? -1 : 1;
    }
    const apiFeature = new ApiFeatures(Review.find({ "reviewstatus": { '$eq': req.params.reviewstatus } }).sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let reviews = await apiFeature.query;
    let filteredReviewCount = reviews.length;

    return res.status(200).json({
        status: true,
        totalReviews,
        filteredReview: filteredReviewCount,
        page: req.query.page,
        limit: resultPerPage,
        reviews,
    });
});

//get all Reting & Review

module.exports.getAllReviews = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit)
    let totalReviews = await Review.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.ReviewBy) {
        sort[req.query.sortBy] = req.query.ReviewBy === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(Review.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let reviews = await apiFeature.query;
    let filteredReviewCount = reviews.length;

    return res.status(200).json({
        status: true,
        totalReviews,
        filteredReview: filteredReviewCount,
        page: req.query.page,
        limit: resultPerPage,
        reviews,
    });
});
// module.exports.getallReviews = catchAsyncErrors(async (req, res) => {
//   const Reviews = await Review.find();
//   const total = await Review.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     Reviews,
//   });
// })

//getSingle Review

module.exports.getSingleReview = catchAsyncErrors(async (req, res, next) => {
    let review = await Review.findById(req.params.id);
    if (!review) {
        return next(new errorhandaler("Review Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            review,
        });
    }
});

//Update Review

module.exports.updateReview = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let review = await Review.findById(id);

    if (!review) {
        return res.status(404).json({ msg: "Cannot Found Review.." });
    }

    const data = {
        hotel_id: req.body.hotel_id || review.hotel_id,
        username: req.body.username,
        title: req.body.title || review.title,
        description: req.body.description || review.description,
        rating: req.body.rating || review.rating,
        reviewstatus: req.body.reviewstatus || review.reviewstatus
    };
    const updateReview = await Review.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updateReview,
    });

});

//Delete Review

module.exports.deleteReview = catchAsyncErrors(async (req, res) => {

    try {
        const data = await Review.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({
                message: "Review Not Found"
            });
        }
        return res.status(200).json({
            status: true,
            message: "Review Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            err
        });
    }
});

// Review By Hotel Id

module.exports.hotelReview = catchAsyncErrors(async (req, res) => {
    const hotelReview = await Review.find({
        "hotel_id": { '$eq': req.params.hotelId },
        "status": { '$eq': "Approved" }
    });

    if (!hotelReview) {
        return res.status(400).json({
            status: false,
            message: "Reviews Not Found with this hotel id ..."
        })
    }
    try {
        let avg = 0;
        const total = hotelReview.length;
        hotelReview.forEach((rev) => {
            avg = avg + rev.rating / total;
        });

        return res.status(200).json({
            status: true,
            totalReview: total,
            rating: parseFloat(avg.toFixed(2)),
            hotelReview
        })
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        })
    }
})

// Review By all Hotel Id

module.exports.allhotelReview = catchAsyncErrors(async (req, res) => {
    try {
        const hotel = await Review.find();
        var element = [];
        for (let i = 0; i < hotel.length; i++) {
            element.push(hotel[i].hotel_id)
        }
        var uniqueArray = Array.from(new Set(element));
        var Reviews = []
        for (let i = 0; i < uniqueArray.length; i++) {
            var id = uniqueArray[i]
            var Confirmeddata = await Review.aggregate([
                {
                    $match: {
                        hotel_id: { $eq: id },
                        status: { $eq: "Approved" }
                    }
                },
                {
                    $group: {
                        _id: "$hotel_id",
                        averageQuantity: { $avg: "$rating" },
                        Review: { $count: {} }, // or { $sum: 1 } prior to Mongo 5
                        data: { $push: "$$ROOT" },
                    },
                }
            ]);
            if (Confirmeddata.length > 0) {
                Reviews.push(Confirmeddata)
            }
        }
        return res.status(200).json({
            status: true,
            Reviews
        })
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        })
    }
})

// update Review Status -- Admin

exports.updateReviewStatus = catchAsyncErrors(async (req, res, next) => {
    const Reviews = await await Review.findById(req.params.id);
    if (!Reviews) {
        return next(new errorhandaler("Review Not Found With This Id", 404));
    }
    var Status = req.body.status;

    if (Status === "Approved") {
        Reviews.status = "Approved";
    }

    if (Status === "Rejected") {
        Reviews.status = "Rejected";
    }

    await Reviews.save({ validateBeforeSave: false });
    res.status(200).json({
        status: true,
        Reviews,
    });
});

//get checkIn Review

module.exports.checkInReviews = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalReviews = await Review.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.ReviewBy) {
        sort[req.query.sortBy] = req.query.ReviewBy === "desc" ? -1 : 1;
    }

    var status = "checkIn"
    const apiFeature = new ApiFeatures(Review.find({ reviewstatus: status }).sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let reviews = await apiFeature.query;
    let filteredReviewCount = reviews.length;

    return res.status(200).json({
        status: true,
        totalReviews,
        filteredReview: filteredReviewCount,
        page: req.query.page,
        limit: resultPerPage,
        reviews,
    });
});

//get checkOut Review

module.exports.checkOutReviews = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalReviews = await Review.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.ReviewBy) {
        sort[req.query.sortBy] = req.query.ReviewBy === "desc" ? -1 : 1;
    }

    var status = "checkOut"
    const apiFeature = new ApiFeatures(Review.find({ reviewstatus: status }).sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let reviews = await apiFeature.query;
    let filteredReviewCount = reviews.length;

    return res.status(200).json({
        status: true,
        totalReviews,
        filteredReview: filteredReviewCount,
        page: req.query.page,
        limit: resultPerPage,
        reviews,
    });
});