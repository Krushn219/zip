const banner = require("../models/bannerModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const AWS = require("aws-sdk");
const fs = require("fs");

const bucketName = process.env.AWS_S3_BUCKET_NAME;
const awsConfig = {
	accessKeyId: process.env.AWS_S3_ACCESS_KEY_ID,
	secretAccessKey: process.env.AWS_S3_SECRET_ACCESS_KEY,
	// region: process.env.region,
};
const S3 = new AWS.S3(awsConfig);

// create banners

module.exports.createbanners = catchAsyncErrors(async (req, res) => {
	var img = [];
	var imgkey = [];

	//upload to s3

	const uploadToS3 = (fileData, minetype, name) => {
		return new Promise((resolve, reject) => {
			const params = {
				Bucket: bucketName,
				// Key: `OfferBanner/${Date.now().toString()}.jpg`,
				Key: `OfferBanner/${name}`,
				Body: fileData,
				ContentType: minetype,
			};
			S3.upload(params, async (err, data) => {
				if (err) {
					console.log(err);
					return reject(err);
				}
				img.push(data.Location);
				imgkey.push(data.Key);
				return resolve(data);
			});

		},
		);
	};

	if (req.file) {
		const pathname = req.file.path;
		const minetype = req.file.mimetype;
		const fileContent = fs.readFileSync(pathname)
		var string = pathname.split("/");
		const name = string[1]
		var imgname = req.file.filename
		await uploadToS3(fileContent, minetype, imgname);
	}
	const image = img[0];
	const key = imgkey[0];

	const banners = await banner.create({
		image: image,
		key: key,
	});

	let resultHandler = function (err) {
		if (err) {
			console.log("Unlink Failed", err);
		} else {
			console.log("File Deleted");
		}
	}

	fs.unlink(req.file.path, resultHandler);
	if (!banners) {
		return res.status(500).send("Banners Cannot Be Created");
	}
	return res.status(200).json({
		status: true,
		banners,
	});
});

//get all banner

module.exports.getallbanners = catchAsyncErrors(async (req, res, next) => {
	const resultPerPage = Number(req.query.limit);

	let totalbanner = await banner.countDocuments();
	const sort = {};
	// const sort = { createdAt: -1 };

	if (req.query.sortBy && req.query.banner) {
		sort[req.query.sortBy] = req.query.banner === "desc" ? -1 : 1;
	}

	const apiFeature = new ApiFeatures(banner.find().sort(sort), req.query)
		.filter()
		.search()
		.pagination(resultPerPage);
	let banners = await apiFeature.query;
	let filteredbannerCount = banners.length;

	return res.status(200).json({
		status: true,
		totalbanner,
		filteredbanner: filteredbannerCount,
		page: req.query.page,
		limit: resultPerPage,
		banners,
	});
});
// module.exports.getallbanners = catchAsyncErrors(async (req, res) => {
//   const banners = await banner.find();
//   const total = await banner.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     banners,
//   });
// })

//getSingle banner

module.exports.getsinglebanners = catchAsyncErrors(async (req, res, next) => {
	let banners = await banner.findById(req.params.id);
	if (!banners) {
		return next(new errorhandaler("Banners Not Found", 404));
	} else {
		return res.status(200).json({
			status: true,
			banners,
		});
	}
});

//Update banner

module.exports.updatebanners = catchAsyncErrors(async (req, res, next) => {
	let id = req.params.id;
	let banners = await banner.findById(id);
	if (!banners) {
		return res.status(404).json({ msg: "Cannot Found Banners.." });
	}
	try {
		var img = [];
		var imgkey = [];

		//upload to s3
		const uploadToS3 = (fileData, minetype, name) => {
			return new Promise((resolve, reject) => {
				const params = {
					Bucket: bucketName,
					Key: `OfferBanner/${name}`,
					Body: fileData,
					ContentType: minetype,
				};
				S3.upload(params, async (err, data) => {       
					if (err) {
						console.log(err);
						return reject(err);
					}
					img.push(data.Location);
					imgkey.push(data.Key);
					return resolve(data);
				});
			})
		};

		if (req.file) {
			const pathname = req.file.path;
			const minetype = req.file.mimetype;
			const fileContent = fs.readFileSync(pathname)
			var string = pathname.split("/");
			const name = string[1]
			var imgname = req.file.filename
			await uploadToS3(fileContent, minetype, imgname);
		}
		const image = img[0];
		const key = imgkey[0];

		const data = {
			image: image,
			key: key,
		};

		var finddata = await banner.findById(id);
		try {
			const updatedbanner = await banner.findByIdAndUpdate(id, data,
				{
					new: true,
					runValidators: true,
					useFindAndModify: "Failed",
				}
			);
			S3.deleteObject({
				Bucket: bucketName,
				Key: finddata.key
			}, async function (err) {
				if (err) {
					return res.status(500).json({
						message: err
					});
				}
			})
			let resultHandler = function (err) {
				if (err) {
					console.log("Unlink Failed", err);
				} else {
					console.log("File Deleted");
				}
			}

			fs.unlink(req.file.path, resultHandler);
			return res.status(200).json({
				status: true,
				msg: "Updated Successfully...",
				updatedbanner,
			});
		} catch (error) {
			res.status(404).json({
				status: "Failed",
				error: error,
			});
		}
	}
	catch (error) {
		return res.status(500).json({
			status: "Failed",
			error,
		});
	}
});

//Delete banner

module.exports.deletebanners = catchAsyncErrors(async (req, res) => {

	try {
		const finddata = await banner.findById(req.params.id);
		S3.deleteObject({
			Bucket: bucketName,
			Key: data.key
		}, async function (err) {
			await finddata.remove();
			if (err) {
				return res.status(500).json({
					message: err
				});
			} else {
				return res.status(200).json({
					message: "Banner Deleted Successfully"
				});
			}
		})
		if (!finddata) {
			return res.status(400).json({
				message: "Banner Not Found"
			});
		}
	} catch (err) {

		return res.status(500).json({ err });
	}

});
