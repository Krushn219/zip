const customerhotel = require("../models/customerhotelModel");
const ApiFeatures = require("../utils/apifeatures");
const ErrorHandler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const otps = require("../models/otp");
const generateOTPFunc = require("../utils/otp");
const sendSms = require("../utils/sendSms");
const shortid = require("shortid");
// Room hotels

module.exports.Roomhotels = catchAsyncErrors(async (req, res, next) => {
    try {
        //Validate mobile input
        const mobile = req.body.mobile;
        if (!mobile) {
            return next(new ErrorHandler("Mobile Number Is Required...", 404));
        }
        //generate OTP

        const generate6digitOTp = generateOTPFunc();
        const _id = `otp_${shortid.generate()}`;

        const otpData = new otps({
            _id,
            mobile,
            status: "hotel",
            otp: generate6digitOTp,
            expiresIn: new Date(Date.now() + 5 * 60 * 1000).getTime(),
        });
        const Otp = await otps.findOne({ mobile, status: "hotel" });
        if (Otp) {
            await Otp.remove();
        }

        await otpData.save();
        const data = {
            otp: generate6digitOTp,

        };
        await sendSms(mobile, data.otp);

        res.status(200).json({
            status: true,
            msg: "Otp Sent To Your Mobile Number. Please Check",
            // otpData,
        });
    } catch (error) {
        res.status(404).json({
            message: "Unable To Send Mobile",
            error: error
        });
    }
});

// verify hotels

module.exports.verifyhotels = catchAsyncErrors(async (req, res, next) => {
    try {
        const { otp, mobile } = req.body;

        // Validate user input
        if (!(mobile && otp)) {
            return res.status(400).json({ message: "Mobile Number Or OTP Not Found" });
        }
        const Otp = await otps.findOne({ mobile, otp, status: "hotel" });

        if (!Otp) {
            return res.status(400).json({ message: "Invalid Mobile Or Otp" });
        }
        else {
            await Otp.remove();
            return res.status(200).json({
                status: true,
            });
        }
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        })
    }
});

// create hotels

module.exports.createhotels = catchAsyncErrors(async (req, res) => {
    try {
        const customerhotels = await customerhotel.create(req.body);
        if (!customerhotels) {
            return res.status(500).send("Something went wrong!!");
        }
        return res.status(201).json({
            status: true,
            message: "Details Submitted Successfully",
            customerhotels,
        });
    } catch (error) {
        return res.status(500).json({
            status: true,
            message: error
        })
    }
});

//get all hotel

module.exports.getallhotels = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;
    let totalhotel = await customerhotel.countDocuments();
    // const sort = {};
    const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.hotel) {
        sort[req.query.sortBy] = req.query.hotel === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(customerhotel.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let customerhotels = await apiFeature.query;
    let filteredhotelCount = customerhotels.length;

    return res.status(200).json({
        status: true,
        totalhotel,
        filteredhotel: filteredhotelCount,
        page: req.query.page,
        limit: resultPerPage,
        customerhotels,
    });
});

//getSingle hotel

module.exports.getsinglehotels = catchAsyncErrors(async (req, res, next) => {
    let customerhotels = await customerhotel.findById(req.params.id);
    if (!customerhotels) {
        return next(new ErrorHandler("Customerhotels Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            customerhotels,
        });
    }
});

//Update hotel

module.exports.updatehotels = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let customerhotels = await customerhotel.findById(id);
    if (!customerhotels) {
        return res.status(404).json({ msg: "Cannot Found Customerhotel.." });
    }

    const data = {
        hotel_name: req.body.hotel_name || customerhotel.hotel_name,
        hotel_name: req.body.hotel_name || customerhotel.hotel_name,
        hotel_email: req.body.hotel_email || customerhotel.hotel_email,
        hotel_address: req.body.hotel_address || customerhotel.hotel_address,
        hotel_mobile: req.body.hotel_mobile || customerhotel.hotel_mobile,

    };
    const updatehotel = await customerhotel.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updatehotel,
    });
});

//Delete hotel

module.exports.deletehotels = catchAsyncErrors(async (req, res) => {
    try {
        const data = await customerhotel.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({ message: "Customerhotel Not Found" });
        }
        return res.status(200).json({ message: "Customerhotel Deleted Successfully" });
    } catch (err) {
        return res.status(500).json({ err });
    }
});
