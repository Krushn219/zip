const enquiry = require("../models/enquiryModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

// create enquirys

module.exports.createenquirys = catchAsyncErrors(async (req, res) => {

    const { name, email, mobile_no, company_name, company_city } = req.body;
    const enquirys = await enquiry.create(
        req.body
    );
    if (!enquirys) {
        return res.status(500).send("Enquirys Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        enquirys,
    });
});

//get all enquiry

module.exports.getallenquirys = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalenquiry = await enquiry.countDocuments();
    // const sort = {};
    const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.enquiry) {
        sort[req.query.sortBy] = req.query.enquiry === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(enquiry.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let enquirys = await apiFeature.query;
    let filteredenquiryCount = enquirys.length;

    return res.status(200).json({
        status: true,
        totalenquiry,
        filteredenquiry: filteredenquiryCount,
        page: req.query.page,
        limit: resultPerPage,
        enquirys,
    });
});
// module.exports.getallenquirys = catchAsyncErrors(async (req, res) => {
//   const enquirys = await enquiry.find();
//   const total = await enquiry.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     enquirys,
//   });
// })

//getSingle enquiry

module.exports.getsingleenquirys = catchAsyncErrors(async (req, res, next) => {
    let enquirys = await enquiry.findById(req.params.id);
    if (!enquirys) {
        return next(new errorhandaler("Enquirys Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            enquirys,
        });
    }
});

//Update enquiry

module.exports.updateenquirys = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let enquirys = await enquiry.findById(id);
    if (!enquirys) {
        return res.status(404).json({ msg: "Cannot Found Enquirys.." });
    }
    const data = {
        name: req.body.name || enquirys.name,
        email: req.body.email || enquirys.email,
        mobile_no: req.body.mobile_no || enquirys.mobile_no,
        company_name: req.body.company_name || enquirys.company_name,
        company_city: req.body.company_city || enquirys.company_city,
        status: req.body.status || enquirys.status,
    };
    const updateenquiry = await enquiry.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updateenquiry,
    });

});

//Delete enquiry

module.exports.deleteenquirys = catchAsyncErrors(async (req, res) => {
    try {
        const data = await enquiry.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({
                message: "Enquiry Not Found"
            });
        }
        return res.status(200).json({
            message:
                "Enquiry Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({ err });
    }
});

