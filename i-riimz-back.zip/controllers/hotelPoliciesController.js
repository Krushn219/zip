const hotel_policie = require("../models/hotel_policiesModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const Hotel = require("../models/hotelsModel");

// create hotel_policies

module.exports.createhotel_policies = catchAsyncErrors(async (req, res) => {

    const hotelData = await Hotel.findById(req.body.hotel_id);

    if (!hotelData) {
        return res.status(404).json({
            status: false,
            message: "Hotel Does Not Exists..."
        })
    }

    const hotel_policies = await hotel_policie.create(req.body);
    if (!hotel_policies) {
        return res.status(500).send("Hotel_policies Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        hotel_policies,
    });
});

//get all hotel_policie

module.exports.getallhotel_policies = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalhotel_policie = await hotel_policie.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.hotel_policie) {
        sort[req.query.sortBy] = req.query.hotel_policie === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(hotel_policie.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let hotel_policies = await apiFeature.query;
    let filteredhotel_policieCount = hotel_policies.length;

    return res.status(200).json({
        status: true,
        totalhotel_policie,
        filteredhotel_policie: filteredhotel_policieCount,
        page: req.query.page,
        limit: resultPerPage,
        hotel_policies,
    });
});

//getSingle hotel_policie

module.exports.getsinglehotel_policies = catchAsyncErrors(async (req, res, next) => {
    let hotel_policies = await hotel_policie.findById(req.params.id);
    if (!hotel_policies) {
        return next(new errorhandaler("Hotel_policies Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            hotel_policies,
        });
    }
});

//Update hotel_policie

module.exports.updatehotel_policies = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let hotelPolicies = await hotel_policie.findById(id);
    if (!hotelPolicies) {
        return res.status(404).json({ msg: "Cannot Found Hotel_policies.." });
    }
    const data = {
        hotel_id: req.body.hotel_id || hotelPolicies.hotel_id,
        checkIn: req.body.checkIn || hotelPolicies.checkIn,
        checkOut: req.body.checkOut || hotelPolicies.checkOut,
        Children_and_Extra_Beds: req.body.Children_and_Extra_Beds || hotelPolicies.Children_and_Extra_Beds,
        Local_ID: req.body.Local_ID || hotelPolicies.Local_ID,
        Couple_Friendly: req.body.Couple_Friendly || hotelPolicies.Couple_Friendly,
        Foreign_Guest: req.body.Foreign_Guest || hotelPolicies.Foreign_Guest
    };
    const updatehotel_policie = await hotel_policie.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        data: updatehotel_policie,
    });
});

//Delete hotel_policie

module.exports.deletehotel_policies = catchAsyncErrors(async (req, res) => {
    try {
        const data = await hotel_policie.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({ message: "Hotel_policies Not Found" });
        }
        return res.status(200).json({ message: "Hotel_policies Deleted Successfully" });
    } catch (err) {
        return res.status(500).json({ err });
    }
});
