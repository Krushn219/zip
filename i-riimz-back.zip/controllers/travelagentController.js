const travelagent = require("../models/travelagentModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

// create travelagents

module.exports.createtravelagent = catchAsyncErrors(async (req, res) => {

    const { name, email, mobile_no, company, city } = req.body;
    const travelagents = await travelagent.create(
        req.body
    );
    if (!travelagents) {
        return res.status(500).send("Travelagent Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        travelagents,
    });
});

//get all travelagent

module.exports.getalltravelagent = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totaltravelagent = await travelagent.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.travelagent) {
        sort[req.query.sortBy] = req.query.travelagent === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(travelagent.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let travelagents = await apiFeature.query;
    let filteredtravelagentCount = travelagents.length;

    return res.status(200).json({
        status: true,
        totaltravelagent,
        filteredtravelagent: filteredtravelagentCount,
        page: req.query.page,
        limit: resultPerPage,
        travelagents,
    });
});
// module.exports.getalltravelagents = catchAsyncErrors(async (req, res) => {
//   const travelagents = await travelagent.find();
//   const total = await travelagent.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     travelagents,
//   });
// })

//getSingle travelagent

module.exports.getsingletravelagent = catchAsyncErrors(async (req, res, next) => {
    let travelagents = await travelagent.findById(req.params.id);
    if (!travelagents) {
        return next(new errorhandaler("Travelagent Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            travelagents,
        });
    }
});

//Update travelagent

module.exports.updatetravelagent = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let travelagents = await travelagent.findById(id);
    if (!travelagents) {
        return res.status(404).json({ msg: "Cannot Found Travelagent.." });
    }
    const data = {
        name: req.body.name || travelagents.name,
        email: req.body.email || travelagents.email,
        mobile_no: req.body.mobile_no || travelagents.mobile_no,
        company: req.body.company || travelagents.company,
        city: req.body.city || travelagents.city,
    };
    const updatetravelagent = await travelagent.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updatetravelagent,
    });

});

//Delete travelagent

module.exports.deletetravelagent = catchAsyncErrors(async (req, res) => {
    try {
        const data = await travelagent.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({
                message: "Travelagent Not Found"
            });
        }
        return res.status(200).json({
            message:
                "Travelagent Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({ err });
    }
});
