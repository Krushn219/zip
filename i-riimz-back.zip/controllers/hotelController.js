const hotel = require("../models/hotelsModel");
const ApiFeatures = require("../utils/apifeatures");
const ErrorHandler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const Admin = require("../models/adminModel");

// create hotels

module.exports.createhotels = catchAsyncErrors(async (req, res) => {
    const admin = await Admin.findById(req.body.admin_id)

    try {
        const hotels = await hotel.create(req.body);
        if (!hotels) {
            return res.status(500).send("Hotels Cannot Be Created");
        }

        admin.hotels.push(hotels._id)
        await admin.save()

        // Avoiding same data

        let adminHotels = admin.hotels;

        let uniqueChars = [...new Set(adminHotels)];

        const data = {
            hotels: uniqueChars
        };
        const updateamenities = await Admin.findByIdAndUpdate(req.params.admin_id, data, {
            new: true,
        });

        return res.status(201).json({
            status: true,
            message: "Hotel Data Created Successfully...",
            hotels,
        });
    } catch (error) {
        return res.status(500).json({
            status: true,
            message: error
        })
    }

});

//get all hotel

module.exports.getallhotels = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalhotel = await hotel.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.hotel) {
        sort[req.query.sortBy] = req.query.hotel === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(hotel.find().sort(sort).populate("amenities"), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let hotels = await apiFeature.query;
    let filteredhotelCount = hotels.length;

    return res.status(200).json({
        status: true,
        totalhotel,
        filteredhotel: filteredhotelCount,
        page: req.query.page,
        limit: resultPerPage,
        hotels,
    });
});

//getSingle hotel

module.exports.getsinglehotels = catchAsyncErrors(async (req, res, next) => {
    let hotels = await hotel.findById(req.params.id);
    if (!hotels) {
        return next(new ErrorHandler("Hotels Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            hotels,
        });
    }
});

//Update hotel

module.exports.updatehotels = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let hotels = await hotel.findById(id);
    if (!hotels) {
        return res.status(404).json({ msg: "Cannot Found Hotels.." });
    }

    const data = {
        ax_hotel_id: req.body.ax_hotel_id || hotels.ax_hotel_id,
        hotel_name: req.body.hotel_name || hotels.hotel_name,
        hotel_email: req.body.hotel_email || hotels.hotel_email,
        hotel_address: req.body.hotel_address || hotels.hotel_address,
        hotel_mobile: req.body.hotel_mobile || hotels.hotel_mobile,
        hotel_phone: req.body.hotel_phone || hotels.hotel_phone,
        hotel_city: req.body.hotel_city || hotels.hotel_city,
        hotel_state: req.body.hotel_state || hotels.hotel_state,
        hotel_country: req.body.hotel_country || hotels.hotel_country,
        hotel_pincode: req.body.hotel_pincode || hotels.hotel_pincode,
        // user_id: req.body.user_id || hotels.user_id,
        about_hotel: req.body.about_hotel || hotels.about_hotel,
        amenities: req.body.amenities || hotels.amenities,
        active: req.body.active || hotels.active,
        auth_string: req.body.auth_string || hotels.auth_string,
        password_reset_otp: req.body.password_reset_otp || hotels.password_reset_otp,
        free_cancellation_status: req.body.free_cancellation_status || hotels.free_cancellation_status,
        free_cancellation_prior_days: req.body.free_cancellation_prior_days || hotels.free_cancellation_prior_days,
        cancellation_charges: req.body.cancellation_charges || hotels.cancellation_charges,
        staymaker_rating: req.body.staymaker_rating || hotels.staymaker_rating,
        customer_rating: req.body.customer_rating || hotels.customer_rating,
        started_year: req.body.started_year || hotels.started_year,
        intro_video: req.body.intro_video || hotels.intro_video,

    };
    const updatehotel = await hotel.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updatehotel,
    });
});

//Delete hotel

module.exports.deletehotels = catchAsyncErrors(async (req, res) => {
    try {
        const data = await hotel.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({ message: "Hotels Not Found" });
        }
        return res.status(200).json({ message: "Hotels Deleted Successfully" });
    } catch (err) {
        return res.status(500).json({ err });
    }
});
