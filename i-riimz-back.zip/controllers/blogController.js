const Blog = require("../models/BlogModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const AWS = require("aws-sdk");
const fs = require("fs");
const bucketName = process.env.AWS_S3_BUCKET_NAME;
const awsConfig = {
  accessKeyId: process.env.AWS_S3_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_S3_SECRET_ACCESS_KEY,
  // region: process.env.region,
};
const S3 = new AWS.S3(awsConfig);

// create blogs

module.exports.createblogs = catchAsyncErrors(async (req, res) => {

  //upload to s3
  var img = [];
  var imgkey = [];

  const uploadToS3 = (fileData, minetype, name) => {
    return new Promise((resolve, reject) => {
      const params = {
        Bucket: bucketName,
        Key: `blog/${name}`,
        Body: fileData,
        ContentType: minetype,
      };
      S3.upload(params, async (err, data) => {
        if (err) {
          console.log(err);
          return reject(err);
        }
        img.push(data.Location);
        imgkey.push(data.Key);
        return resolve(data);
      });
    },
    );
  };

  if (req.file) {
    const pathname = req.file.path;
    const minetype = req.file.mimetype;
    const fileContent = fs.readFileSync(pathname)
    var string = pathname.split("/");
    const name = string[1]
    var imgname = req.file.filename
    await uploadToS3(fileContent, minetype, imgname);
  }
  const image = img[0];
  const key = imgkey[0];

  const blogs = await Blog.create({
    image: image,
    key: key,
    title: req.body.title,
    content: req.body.content,
    type: req.body.type,
    author: req.body.author,
    city: req.body.city,
    created_At: req.body.created_At,
  });
  if (!blogs) {
    return res.status(500).send("Blogs Cannot Be Created");
  }
  return res.status(200).json({
    status: true,
    blogs,
  });
});

//get all Blog

module.exports.getallblogs = catchAsyncErrors(async (req, res, next) => {
  const resultPerPage = Number(req.query.limit);

  let totalBlog = await Blog.countDocuments();
  const sort = {};
  // const sort = { createdAt: -1 };

  if (req.query.sortBy && req.query.Blog) {
    sort[req.query.sortBy] = req.query.Blog === "desc" ? -1 : 1;
  }

  const apiFeature = new ApiFeatures(Blog.find().sort(sort), req.query)
    .filter()
    .search()
    .pagination(resultPerPage);
  let blogs = await apiFeature.query;
  let filteredBlogCount = blogs.length;

  return res.status(200).json({
    status: true,
    totalBlog,
    filteredBlog: filteredBlogCount,
    page: req.query.page,
    limit: resultPerPage,
    blogs,
  });
});
// module.exports.getallblogs = catchAsyncErrors(async (req, res) => {
//   const blogs = await Blog.find();
//   const total = await Blog.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     blogs,
//   });
// })

//getSingle Blog

module.exports.getsingleblogs = catchAsyncErrors(async (req, res, next) => {
  let blog = await Blog.findById(req.params.id);
  if (!blog) {
    return next(new errorhandaler("Blogs Not Found", 404));
  } else {
    return res.status(200).json({
      status: true,
      blog,
    });
  }
});

//Update Blog

module.exports.updateblogs = catchAsyncErrors(async (req, res) => {
  let id = req.params.id;
  let blog = await Blog.findById(id);

  if (!blog) {
    return res.status(404).json({ msg: "Cannot Found Blogs.." });
  }
  if (!req.file) {
    const data = {
      title: req.body.title || blog.title,
      content: req.body.content || blog.content,
      type: req.body.type || blog.type,
      author: req.body.author || blog.author,
      image: blog.image,
      city: req.body.city || blog.city,
      created_At: req.body.created_At || blog.created_At,
    };
    const updateBlog = await Blog.findByIdAndUpdate(id, data, {
      new: true,
    });
    return res.status(200).json({
      status: true,
      msg: "Updated Successfully...",
      updateBlog,
    });
  } else {
    var img = [];
    var imgkey = [];

    //upload to s3

    const uploadToS3 = (fileData, minetype, name) => {
      return new Promise((resolve, reject) => {
        const params = {
          Bucket: bucketName,
          Key: `blog/${name}`,
          Body: fileData,
          ContentType: minetype,
        };
        S3.upload(params, async (err, data) => {
          if (err) {
            console.log(err);
            return reject(err);
          }
          img.push(data.Location);
          imgkey.push(data.Key);
          return resolve(data);
        });

      },
      );
    };
    if (req.file) {
      const pathname = req.file.path;
      const minetype = req.file.mimetype;
      const fileContent = fs.readFileSync(pathname)
      var string = pathname.split("/");
      const name = string[1]
      var imgname = req.file.filename
      await uploadToS3(fileContent, minetype, imgname);
    }
    const image = img[0];
    const key = imgkey[0];

    const data = {
      title: req.body.title || blog.title,
      content: req.body.content || blog.content,
      type: req.body.type || blog.type,
      author: req.body.author || blog.author,
      city: req.body.city || blog.city,
      createdAt: req.body.createdAt || blog.createdAt,
      image: image,
      key: key,
    };
    var finddata = await Blog.findById(id);

    const updateBlog = await Blog.findByIdAndUpdate(id, data, {
      new: true,
    });

    S3.deleteObject({
      Bucket: bucketName,
      Key: finddata.key
    }, async function (err) {
      if (err) {
        return res.status(500).json({
          message: err
        });
      }
    })
    let resultHandler = function (err) {
      if (err) {
        console.log("Unlink Failed", err);
      } else {
        console.log("File Deleted");
      }
    }

    fs.unlink(req.file.path, resultHandler);
    return res.status(200).json({
      status: true,
      msg: "Updated Successfully...",
      updateBlog,
    });
  }
});

//Delete Blog

module.exports.deleteblogs = catchAsyncErrors(async (req, res) => {

  try {
    const finddata = await Blog.findById(req.params.id);
    S3.deleteObject({
      Bucket: bucketName,
      Key: finddata.key
    }, async function (err) {
      await finddata.remove();
      if (err) {
        return res.status(500).json({
          message: err
        });
      } else {
        return res.status(200).json({
          message: "Blog Deleted Successfully"
        });
      }
    })
    if (!finddata) {
      return res.status(400).json({
        message: "Blog Not Found"
      });
    }
  } catch (err) {

    return res.status(500).json({ err });
  }
});
