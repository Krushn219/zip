const coupan = require("../models/coupanModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const moment = require("moment");
const AWS = require("aws-sdk");
const fs = require("fs");

const bucketName = process.env.AWS_S3_BUCKET_NAME;
const awsConfig = {
    accessKeyId: process.env.AWS_S3_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_S3_SECRET_ACCESS_KEY,
    // region: process.env.region,
};
const S3 = new AWS.S3(awsConfig);

// create coupans

module.exports.createcoupans = catchAsyncErrors(async (req, res) => {
    var img = [];
    var imgkey = [];

    //upload to s3

    const uploadToS3 = (fileData, minetype, name) => {
        return new Promise((resolve, reject) => {
            const params = {
                Bucket: bucketName,
                // Key: `Offercoupan/${Date.now().toString()}.jpg`,
                Key: `Offercoupan/${name}`,
                Body: fileData,
                ContentType: minetype,
            };
            S3.upload(params, async (err, data) => {
                if (err) {
                    console.log(err);
                    return reject(err);
                }
                img.push(data.Location);
                imgkey.push(data.Key);
                return resolve(data);
            });

        },
        );
    };

    if (req.file) {
        const pathname = req.file.path;
        const minetype = req.file.mimetype;
        const fileContent = fs.readFileSync(pathname)
        var string = pathname.split("/");
        const name = string[1]
        var imgname = req.file.filename
        await uploadToS3(fileContent, minetype, imgname);
    }
    const image = img[0];
    const key = imgkey[0];

    const coupans = await coupan.create({
        Coupon_Name: req.body.Coupon_Name,
        Coupon_Code: req.body.Coupon_Code,
        Valid_From: req.body.Valid_From,
        Valid_To: req.body.Valid_To,
        User_Type: req.body.User_Type,
        Offer_Type: req.body.Offer_Type,
        Offer_Value: req.body.Offer_Value,
        status: req.body.status,
        image: image,
        key: key,
    });
    if (!coupans) {
        return res.status(500).send("Coupans Cannot Be Created");
    }
    var from = moment(coupans.Valid_From).format("YYYY-MM-DDT00:00:00.000+00:00");
    var to = moment(coupans.Valid_To).format("YYYY-MM-DDT00:00:00.000+00:00");
    coupans.Valid_From = from
    coupans.Valid_To = to
    await coupans.save();
    let resultHandler = function (err) {
        if (err) {
            console.log("Unlink Failed", err);
        } else {
            console.log("File Deleted");
        }
    }

    fs.unlink(req.file.path, resultHandler);
    if (!coupans) {
        return res.status(500).send("coupans Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        coupans,
    });
});

//get all coupan

module.exports.getallcoupans = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalcoupan = await coupan.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.coupan) {
        sort[req.query.sortBy] = req.query.coupan === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(coupan.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let coupans = await apiFeature.query;
    let filteredcoupanCount = coupans.length;

    return res.status(200).json({
        status: true,
        totalcoupan,
        filteredcoupan: filteredcoupanCount,
        page: req.query.page,
        limit: resultPerPage,
        coupans,
    });
});

//getdatecoupans

module.exports.getdatecoupans = catchAsyncErrors(async (req, res, next) => {
    var check_date = moment().format("YYYY-MM-DDT00:00:00.000+00:00")
    let totalcoupan = await coupan.countDocuments();
    const apiFeature = new ApiFeatures(coupan.find({ "Valid_From": { '$lte': check_date }, "Valid_To": { '$gte': check_date } }), req.query)
        .filter()
        .search()
    let coupans = await apiFeature.query;
    let coupanCount = coupans.length;

    return res.status(200).json({
        status: true,
        totalcoupan,
        selectcoupan: coupanCount,
        coupans,
    });
});

// module.exports.getallcoupans = catchAsyncErrors(async (req, res) => {
//   const coupans = await coupan.find();
//   const total = await coupan.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     coupans,
//   });
// })

//getSingle coupan

module.exports.getsinglecoupans = catchAsyncErrors(async (req, res, next) => {
    let coupans = await coupan.findById(req.params.id);
    if (!coupans) {
        return next(new errorhandaler("Coupans Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            coupans,
        });
    }
});

//Update coupan

module.exports.updatecoupans = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let coupans = await coupan.findById(id);
    if (!coupans) {
        return res.status(404).json({ msg: "Cannot Found coupans.." });
    }
    try {
        if (req.file.length == 0) {
            const data = {
                Coupon_Name: req.body.Coupon_Name || coupans.Coupon_Name,
                Coupon_Code: req.body.Coupon_Code || coupans.Coupon_Code,
                Valid_From: req.body.Valid_From || coupans.Valid_From,
                Valid_To: req.body.Valid_To || coupans.Valid_To,
                User_Type: req.body.User_Type || coupans.User_Type,
                Offer_Type: req.body.Offer_Type || coupans.Offer_Type,
                Offer_Value: req.body.Offer_Value || coupans.Offer_Value,
                status: req.body.status || coupans.status,
                image: coupans.image,
                key: coupans.key,

            };
            try {
                const updatedcoupan = await coupan.findByIdAndUpdate(
                    req.params.id,
                    data,
                    {
                        new: true,
                        runValidators: true,
                        useFindAndModify: "Failed",
                    }
                );
                return res.status(200).json({
                    status: true,
                    msg: "Updated Successfully...",
                    updatedcoupan,
                });
            } catch (error) {
                res.status(404).json({
                    status: "Failed",
                    error,
                });
            }
        }
        else {

            var img = [];
            var imgkey = [];

            //upload to s3

            const uploadToS3 = (fileData, minetype, name) => {
                return new Promise((resolve, reject) => {
                    const params = {
                        Bucket: bucketName,
                        Key: `Offercoupan/${name}`,
                        Body: fileData,
                        ContentType: minetype,
                    };
                    S3.upload(params, async (err, data) => {
                        if (err) {
                            console.log(err);
                            return reject(err);
                        }
                        img.push(data.Location);
                        imgkey.push(data.Key);
                        return resolve(data);
                    });

                },
                );
            };

            if (req.file) {
                const pathname = req.file.path;
                const minetype = req.file.mimetype;
                const fileContent = fs.readFileSync(pathname)
                var string = pathname.split("/");
                const name = string[1]
                var imgname = req.file.filename
                await uploadToS3(fileContent, minetype, imgname);
            }
            const image = img[0];
            const key = imgkey[0];

            const data = {
                Coupon_Name: req.body.Coupon_Name || coupans.Coupon_Name,
                Coupon_Code: req.body.Coupon_Code || coupans.Coupon_Code,
                Valid_From: req.body.Valid_From || coupans.Valid_From,
                Valid_To: req.body.Valid_To || coupans.Valid_To,
                User_Type: req.body.User_Type || coupans.User_Type,
                Offer_Type: req.body.Offer_Type || coupans.Offer_Type,
                Offer_Value: req.body.Offer_Value || coupans.Offer_Value,
                status: req.body.status || coupans.status,
                image: image,
                key: key,

            };

            var finddata = await coupan.findById(id);
            try {
                const updatedcoupan = await coupan.findByIdAndUpdate(id, data,
                    {
                        new: true,
                        runValidators: true,
                        useFindAndModify: "Failed",
                    }
                );
                S3.deleteObject({
                    Bucket: bucketName,
                    Key: finddata.key
                }, async function (err) {
                    if (err) {
                        return res.status(500).json({
                            message: err
                        });
                    }
                })
                let resultHandler = function (err) {
                    if (err) {
                        console.log("Unlink Failed", err);
                    } else {
                        console.log("File Deleted");
                    }
                }

                fs.unlink(req.file.path, resultHandler);
                return res.status(200).json({
                    status: true,
                    msg: "Updated Successfully...",
                    updatedcoupan,
                });
            } catch (error) {
                res.status(404).json({
                    status: "Failed",
                    error: error,
                });
            }
        }
    }
    catch (error) {
        return res.status(500).json({
            status: "Failed",
            error,
        });
    }

});

//Delete coupan

module.exports.deletecoupans = catchAsyncErrors(async (req, res) => {

    try {
        const finddata = await coupan.findById(req.params.id);
        S3.deleteObject({
            Bucket: bucketName,
            Key: finddata.key
        }, async function (err) {
            await finddata.remove();
            if (err) {
                return res.status(500).json({
                    message: err
                });
            } else {
                return res.status(200).json({
                    message: "coupan Deleted Successfully"
                });
            }
        })
        if (!finddata) {
            return res.status(400).json({
                message: "coupan Not Found"
            });
        }
    } catch (err) {
        return res.status(500).json({ err });
    }
});
