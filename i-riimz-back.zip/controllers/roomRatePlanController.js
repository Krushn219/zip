const room = require("../models/roomsModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const roomRatePlan = require("../models/roomRatePlansModel");
const error = require("../middleware/error");

// create Room Rate Plan

module.exports.createRoomRatePlan = catchAsyncErrors(async (req, res) => {
    try {
        // const roomRate = await roomRatePlan.create(req.body);
        const roomRate = await roomRatePlan.create({
            ax_rateplan_id: req.body.ax_rateplan_id,
            rate_plan_name: req.body.rate_plan_name,
            hotel_id: req.body.hotel_id,
            room_id: req.body.room_id,
            price_date: req.body.price_date,
            ota_ids: req.body.ota_ids,
            price_json: req.body.price_json,
            active: req.body.active,
            start_date: req.body.start_date,
            end_date: req.body.end_date,
            commissionPerc: req.body.commissionPerc,
            taxPerc: req.body.taxPerc,
            currency: req.body.currency,
        });
        if (!roomRate) {
            return res.status(500).send("Room Rate Plan Data Cannot Be Created");
        }

        // const selectedAminities = req.params
        const occupancies = req.body.occupancies;

        const split = occupancies.split(",");


        for (let i = 0; i < split.length; i++) {

            roomRate.occupancies.push(split[i])
        }
        await roomRate.save();

        // Avoiding same data

        let occupancy = roomRate.occupancies;

        let uniqueChars = [...new Set(occupancy)];

        const data = {
            occupancies: uniqueChars
        };
        const updateoccupancies = await roomRatePlan.findByIdAndUpdate(roomRate._id, data, {
            new: true,
        });
        return res.status(201).json({
            status: true,
            message: "Room Rate Plan Data Created Successfully..",
            roomRate,
        });
    } catch (error) {
        return res.status(404).json({
            status: false,
            message: error
        });
    }


});

//get all Room Rate Plan

module.exports.getAllRoomRatePlan = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalRatePlans = await roomRatePlan.countDocuments();
    const sort = {};

    if (req.query.sortBy && req.query.room) {
        sort[req.query.sortBy] = req.query.room === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(roomRatePlan.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let roomRatePlans = await apiFeature.query;
    let filteredroomRatePlanCount = roomRatePlans.length;

    return res.status(200).json({
        status: true,
        totalRatePlans,
        filteredroom: filteredroomRatePlanCount,
        page: req.query.page,
        limit: resultPerPage,
        roomRatePlans,
    });
});

//getSingle Room Rate Plan

module.exports.getSingleRoomRatePlan = catchAsyncErrors(async (req, res, next) => {
    try {
        let ratePlan = await roomRatePlan.findById(req.params.id);
        if (!ratePlan) {
            return next(new errorhandaler("Room Rate Plan Not Found", 404));
        } else {
            return res.status(200).json({
                status: true,
                ratePlan,
            });
        }
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

});

//Update Room Rate Plan

module.exports.updateRatePlan = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let ratePlan = await roomRatePlan.findById(id);
    if (!ratePlan) {
        return res.status(404).json({ msg: "Cannot Found Rate Plan.." });
    }
    // const selectedAminities = req.params
    const occupancies = req.body.occupancies;

    const split = occupancies.split(",");

    const roomRateData = {
        ax_rateplan_id: req.body.ax_rateplan_id || ratePlan.ax_rateplan_id,
        rate_plan_name: req.body.rate_plan_name || ratePlan.rate_plan_name,
        hotel_id: req.body.hotel_id || ratePlan.hotel_id,
        room_id: req.body.room_id || ratePlan.room_id,
        price_date: req.body.price_date || ratePlan.price_date,
        ota_ids: req.body.ota_ids || ratePlan.ota_ids,
        price_json: req.body.price_json || ratePlan.price_json,
        active: req.body.active || ratePlan.active,
        occupancies: split || ratePlan.start_date,
        start_date: req.body.start_date || ratePlan.start_date,
        end_date: req.body.end_date || ratePlan.end_date,
        commissionPerc: req.body.commissionPerc || ratePlan.commissionPerc,
        taxPerc: req.body.taxPerc || ratePlan.taxPerc,
        currency: req.body.currency || ratePlan.currency,
    };

    const updateRatePlan = await roomRatePlan.findByIdAndUpdate(id, roomRateData, {
        new: true,
    });

    return res.status(200).json({
        status: true,
        message: "Room Rate Plan Updated Successfully..",
        // ratePlan,
    });

});

//Delete Room Rate Plan

module.exports.deleteRoomRatePlan = catchAsyncErrors(async (req, res) => {
    try {
        const data = await roomRatePlan.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({
                status: false,
                message: "Room Rate Plan Not Found"
            });
        }
        return res.status(200).json({
            status: true,
            message: "Room Rate Plan Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            message: error
        });
    }
});

// Room Rate Plan By Hotel Id
module.exports.hotelRoomRatePlan = catchAsyncErrors(async (req, res) => {
    try {
        const hotelRatePlan = await roomRatePlan.find({ hotel_id: req.params.hotelId });
        if (!hotelRatePlan) {
            return res.status(400).json({
                status: false,
                message: " Not Found..."
            })
        }

        const Total = hotelRatePlan.length;

        return res.status(200).json({
            status: true,
            Count: Total,
            hotelRatePlan
        })
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        })
    }

})
