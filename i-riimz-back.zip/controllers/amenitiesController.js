const amenities = require("../models/amenitiesModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const Hotel = require("../models/hotelsModel");

// create amenitiess

module.exports.createamenitiess = catchAsyncErrors(async (req, res) => {

    const data = await amenities.findOne({ name: req.body.name })
    if (data) {
        return res.status(400).send("Amenities Already Exists...")
    }
    if (!req.file) {
        const amenitiess = await amenities.create({
            name: req.body.name,
            status: req.body.status,
        });
        if (!amenitiess) {
            return res.status(400).send("Amenitiess Cannot Be Created");
        }
        return res.status(200).json({
            status: true,
            amenitiess,
        });
    }
    var image = req.file.path;

    const amenitiess = await amenities.create({
        icon: image,
        name: req.body.name,
        status: req.body.status,
    });
    if (!amenitiess) {
        return res.status(404).send("Amenitiess Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        amenitiess,
    });
});

//get all amenities

module.exports.getallamenitiess = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit);

    let totalamenities = await amenities.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.amenities) {
        sort[req.query.sortBy] = req.query.amenities === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(amenities.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let amenitiess = await apiFeature.query;
    let filteredamenitiesCount = amenitiess.length;

    return res.status(200).json({
        status: true,
        totalamenities,
        filteredamenities: filteredamenitiesCount,
        page: req.query.page,
        limit: resultPerPage,
        amenitiess,
    });
});
// module.exports.getallamenitiess = catchAsyncErrors(async (req, res) => {
//   const amenitiess = await amenities.find();
//   const total = await amenities.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     amenitiess,
//   });
// })

//getSingle amenities

module.exports.getsingleamenitiess = catchAsyncErrors(async (req, res, next) => {
    let amenitiess = await amenities.findById(req.params.id);
    if (!amenitiess) {
        return next(new errorhandaler("Amenitiess Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            amenitiess,
        });
    }
});

//Update amenities

module.exports.updateamenitiess = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let amenitiess = await amenities.findById(id);
    if (!amenitiess) {
        return res.status(404).json({ msg: "Cannot Found Amenitiess.." });
    }
    if (!req.file) {
        const data = {
            icon: amenitiess.image,
            name: req.body.name || amenitiess.name,
            status: req.body.status || amenitiess.status,
        };
        const updateamenities = await amenities.findByIdAndUpdate(id, data, {
            new: true,
        });
        return res.status(200).json({
            status: true,
            msg: "Updated Successfully...",
            updateamenities,
        });
    }
    var image = req.file.path;

    const data = {
        name: req.body.name || amenitiess.name,
        status: req.body.status || amenitiess.status,
        icon: image || amenitiess.image,
    };
    const updateamenities = await amenities.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updateamenities,
    });
});

//Delete amenities

module.exports.deleteamenitiess = catchAsyncErrors(async (req, res) => {
    try {
        const data = await amenities.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({ message: "Amenitiess Not Found" });
        }
        return res.status(200).json({ message: "Amenitiess Deleted Successfully" });
    } catch (err) {
        return res.status(500).json({ err });
    }
});

// Pushing Aminities in Hotel DATA

module.exports.aminitiesToHotel = catchAsyncErrors(async (req, res) => {
    const hotelData = await Hotel.findById(req.params.hotelId)
    if (!hotelData) {
        return res.status(404).json({ message: "Hotel Not Found..." });
    }
    try {

        // const selectedAminities = req.params
        const aminites = (req.body.amenites)

        const split = aminites.split(",");


        for (let i = 0; i < split.length; i++) {

            hotelData.amenities.push(split[i])
        }
        await hotelData.save();

        // Avoiding same data

        let amenities = hotelData.amenities;

        let uniqueChars = [...new Set(amenities)];

        const data = {
            amenities: uniqueChars
        };
        const updateamenities = await Hotel.findByIdAndUpdate(req.params.hotelId, data, {
            new: true,
        });

        return res.status(200).json({
            status: true,
            message: "Amenities Added Successfully..."
        })
    } catch (err) {
        return res.status(500).json({ err });
    }
});

