const ApiFeatures = require("../utils/apifeatures");
const ErrorHandler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const Booking = require("../models/roomBookingsModel");
const error = require("../middleware/error");
const CsvParser = require("json2csv").Parser;
const otps = require("../models/otp");
const generateOTPFunc = require("../utils/otp");
const date_IST = require("../utils/new_date");
const sendSms = require("../utils/sendSms");
const shortid = require("shortid");
const Razorpay = require('razorpay');
const moment = require('moment');
const axios = require('axios');
const { sendEmail, sendCancelEmail } = require("../utils/sendmail");
const BookingData = require("../models/bookingData");


// Room booking

module.exports.Roombooking = catchAsyncErrors(async (req, res, next) => {
    try {
        //Validate mobile input
        const mobile = req.body.mobile;
        if (!mobile) {
            return next(new ErrorHandler("Mobile Number Is Required...", 404));
        }
        //generate OTP

        const generate6digitOTp = generateOTPFunc();
        const _id = `otp_${shortid.generate()}`;

        const otpData = new otps({
            _id,
            mobile,
            status: "Booking",
            otp: generate6digitOTp,
            expiresIn: new Date(Date.now() + 5 * 60 * 1000).getTime(),
        });
        const Otp = await otps.findOne({ mobile, status: "Booking" });
        if (Otp) {
            await Otp.remove();
        }

        await otpData.save();
        const data = {
            otp: generate6digitOTp,

        };
        await sendSms(mobile, data.otp);

        res.status(200).json({
            status: true,
            msg: "Otp Sent To Your Mobile Number. Please Check",
            // otpData,
        });
    } catch (error) {
        res.status(404).json({
            message: "Unable To Send Mobile",
            error: error,
        });
    }
});

// verify Roombooking

module.exports.verifyRoombooking = catchAsyncErrors(async (req, res, next) => {
    try {
        const { otp, mobile } = req.body;

        // Validate user input
        if (!(mobile && otp)) {
            return res.status(400).json({ message: "Mobile Number Or OTP Not Found" });
        }
        const Otp = await otps.findOne({ mobile, otp, status: "Booking" });

        if (!Otp) {
            return res.status(400).json({ message: "Invalid Mobile Or Otp" });
        }
        else {
            await Otp.remove();
            return res.status(200).json({
                status: true,
            });
        }
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        })
    }
});

// create Booking

module.exports.createRoomBooking = catchAsyncErrors(async (req, res) => {

    try {
        if (req.body.amountPay == "payathotel") {

            const Bookings = await Booking.create(req.body);
            const new_date = date_IST();
            Bookings.DatenowAt = new_date;
            await Bookings.save();

            if (!Bookings) {
                return res.status(400).send("Bookings Cannot Be Created");
            }
            return res.status(201).json({
                status: true,
                message: "Booked Successfully...",
                Bookings,
            });
        }
        else {

            var total = req.body.amount
            const instance = new Razorpay({
                key_id: process.env.RAZORPAY_KEY_ID,
                key_secret: process.env.RAZORPAY_KEY_SECRET,
            });
            const options = {
                amount: total * 100, // amount in smallest currency unit
                currency: "INR",
                receipt: `receipt_hotel_${req.body.hotelId}`,
                // receipt: `receipt_hotel_${req.body.bookingId}`,
            };
            const hotels = await instance.orders.create(options);
            const Bookings = await Booking.create(req.body);
            const new_date = date_IST();
            Bookings.DatenowAt = new_date;
            await Bookings.save();

            return res.status(201).json({
                status: true,
                message: "Booked Successfully...",
                hotels,
                Bookings
            });
        }
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        })
    }
});

//get all Booking

module.exports.getAllRoomBooking = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalBooking = await Booking.countDocuments();
    // const sort = {};
    const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.hotel) {
        sort[req.query.sortBy] = req.query.booking === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(Booking.find().sort(sort).populate("user"), req.query)
        .filter()
        .search()
        .pagination(resultPerPage)
    let bookings = await apiFeature.query;
    let filteredBookingCount = bookings.length;

    return res.status(200).json({
        status: true,
        totalBooking,
        filteredBooking: filteredBookingCount,
        page: req.query.page,
        limit: resultPerPage,
        bookings,
    });
});

//getSingle hotel

module.exports.getSingleRoomBooking = catchAsyncErrors(async (req, res, next) => {
    try {
        let booking = await Booking.findById(req.params.id)
        if (!booking) {
            return next(new ErrorHandler("Booking Not Found", 404));
        } else {
            return res.status(200).json({
                status: true,
                booking,
            });
        }
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

});

//getSingle booking(user)

module.exports.getuserRoomBooking = catchAsyncErrors(async (req, res, next) => {
    try {
        let booking = await Booking.find({ user: req.params.user_id })
        let filtereCount = booking.length;

        if (!booking) {
            return next(new ErrorHandler("Booking Not Found", 404));
        } else {
            return res.status(200).json({
                status: true,
                Count: filtereCount,
                booking,
            });
        }
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

});

//Update Booking

module.exports.updateRoomBooking = catchAsyncErrors(async (req, res) => {
    let booking = await Booking.findById(req.params.id);
    if (!booking) {
        return res.status(404).json({ msg: "Cannot Found booking.." });
    }
    try {
        if (req.body.paymentStatus) {
            return next(new ErrorHandler("cannot update paymentStatus..", 404));
        }
        const data = {
            bookingId: req.body.bookingId || booking.bookingId,
            hotelId: req.body.hotelId || booking.hotelId,
            hotelname: req.body.hotelname || booking.hotelname,
            checkInDate: req.body.checkInDate || booking.checkInDate,
            checkOutDate: req.body.checkOutDate || booking.checkOutDate,
            totalAmount: req.body.totalAmount || booking.totalAmount,
            user: req.body.user || booking.user,
            customerEmail: req.body.customerEmail || booking.customerEmail,
            customerName: req.body.customerName || booking.customerName,
            hotel_id: req.body.hotel_id || booking.hotel_id,
            contactNo: req.body.contactNo || booking.contactNo,
            noOfGuest: req.body.noOfGuest || booking.noOfGuest,
            // paymentStatus: req.body.paymentStatus || booking.paymentStatus,
        };
        const updateBooking = await Booking.findByIdAndUpdate(req.params.id, data, {
            new: true,
        });
        return res.status(200).json({
            status: true,
            msg: "Updated Successfully...",
            updateBooking,
        });
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

});

exports.updateBooking = catchAsyncErrors(async (req, res, next) => {
    const Bookings = await Booking.findOne({
        bookingId: req.params.bookingId
    });

    if (!Bookings) {
        return next(new ErrorHandler("Booking not found with this Id", 404));
    }

    // if (Bookings.paymentStatus === "Confirmed") {
    //     return next(new ErrorHandler("You have already Confirmed this Booking", 400));
    // }

    Bookings.paymentStatus = req.body.paymentStatus;

    if (req.body.paymentStatus === "Cancelled") {
        const new_date = date_IST();
        Bookings.discription = req.body.discription;
        Bookings.CancelledAt = new_date
    }
    await Bookings.save({ validateBeforeSave: false });
    res.status(200).json({
        Bookings,
        success: true,
    });
});

// get booking Cancelled  

exports.getCancelledStatus = catchAsyncErrors(async (req, res, next) => {
    var paymentStatus = "Cancelled";

    let allBooking = await Booking.find({ paymentStatus });
    let Cancelleddbooking = allBooking.length;

    if (!allBooking) {
        return next(new ErrorHandler("Booking not found", 404));
    } else {
        return res.status(200).json({
            success: true,
            filtereBooking: Cancelleddbooking,
            allBooking,
        });
    }
});

// get booking Confirmed

exports.getConfirmedStatus = catchAsyncErrors(async (req, res, next) => {
    var paymentStatus = "Confirmed";

    let allBooking = await Booking.find({ paymentStatus });
    let Confirmedbooking = allBooking.length;

    if (!allBooking) {
        return next(new ErrorHandler("Booking not found", 404));
    } else {
        return res.status(200).json({
            success: true,
            filtereBooking: Confirmedbooking,
            allBooking,
        });
    }
});

// get booking Pending

exports.getPendingStatus = catchAsyncErrors(async (req, res, next) => {
    var paymentStatus = "Pending";

    let allBooking = await Booking.find({ paymentStatus });
    let Pendingbooking = allBooking.length;

    if (!allBooking) {
        return next(new ErrorHandler("Booking not found", 404));
    } else {
        return res.status(200).json({
            success: true,
            filtereBooking: Pendingbooking,
            allBooking,
        });
    }
});

//Delete hotel

module.exports.deleteRoomBooking = catchAsyncErrors(async (req, res) => {
    try {
        const data = await Booking.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({ message: "Booking Not Found" });
        }
        return res.status(200).json({
            status: true,
            message: "Booking Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({
            status: false,
            message: err
        });
    }
});

// Confirmed booking mail

// module.exports.sendmail = catchAsyncErrors(async (req, res, next) => {
//     const email = req.params.email
//     const bookingId = req.params.bookingId

//     try {
//         const config = {
//             headers: {
//                 "X-SF-API-KEY": process.env.X_SF_API_KEY
//             }
//         };
//         axios
//             .get(
//                 `https://api.stayflexi.com/core/api/v1/beservice/bookinginfo?bookingId=${bookingId}`,
//                 config,
//                 null)
//             .then(function (response) {
//                 var sendData = response.data;
//                 const config = {
//                     headers: {
//                         "X-SF-API-KEY": process.env.X_SF_API_KEY
//                     }
//                 };
//                 axios
//                     .get(
//                         `https://api.stayflexi.com/core/api/v1/beservice/hotelcontent?hotelId=${sendData.hotelId}`,
//                         config,
//                         null)
//                     .then(async function (response) {
//                         var checkin = moment(new Date(sendData.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('ddd, DD MMM YYYY')
//                         var checkout = moment(new Date(sendData.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('ddd, DD MMM YYYY')
//                         var checkintime = moment(new Date(sendData.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format("hh:mm A")
//                         var checkouttime = moment(new Date(sendData.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format("hh:mm A")

//                         if (sendData.paymentDetails.payAtHotel == true) {
//                             var Amount_paid = 0.00
//                             var Balance_due = sendData.paymentDetails.sellRate
//                         }
//                         if (sendData.paymentDetails.payAtHotel == false) {
//                             var Amount_paid = sendData.paymentDetails.sellRate
//                             var Balance_due = 0.00
//                         }
//                         const Bookings = await Booking.findOne({
//                             bookingId: bookingId
//                         });
//                         let taxamount = Bookings.tax || 0.00
//                         let Finaltotal = Bookings.amount || 0.00
//                         var subtotal = Finaltotal - taxamount || 0.00

//                         const bookingdata = {
//                             hotelName: sendData.hotelName,
//                             latitude: response.data.latitude,
//                             longitude: response.data.longitude,
//                             roomStays: sendData.roomStays,
//                             checkin: checkin,
//                             checkintime: checkintime,
//                             checkout: checkout,
//                             checkouttime: checkouttime,
//                             hotelAddress: sendData.hotelAddress,
//                             hotelState: sendData.hotelState,
//                             hotelCity: sendData.hotelCity,
//                             hotelCountry: sendData.hotelCountry,
//                             hotelZipcode: sendData.hotelZipcode,
//                             hotelEmail: sendData.hotelEmail,
//                             hotelContact: sendData.hotelContact,
//                             cancellationPolicyInfo: sendData.cancellationPolicyInfo.policyDescription,
//                             // promoAmount: sendData.promoAmount.toFixed(2),
//                             subtotal: subtotal.toFixed(2),
//                             tax: taxamount.toFixed(2),
//                             Finaltotal: Finaltotal.toFixed(2),
//                             Amount_paid: Amount_paid.toFixed(2),
//                             Balance_due: Balance_due.toFixed(2),
//                             bookingId: bookingId
//                         };
//                         // return console.log("bookingdata", bookingdata);
//                         sendEmail(email, bookingdata)

//                         // mail send to client
//                         const mail = "info.iipl@iroomz.in"
//                         sendEmail(mail, bookingdata)

//                         return res.status(200).json({
//                             status: true,
//                             msg: "Email Sent To Your Mail...Please Check",
//                         })
//                     })
//                     .catch(function (error) {
//                         return res.status(500).json({
//                             message: "Unable To Send email",
//                             error: error
//                         })
//                     })
//             })
//             .catch(function (error) {
//                 return res.status(500).json({
//                     message: "Unable To Send email",
//                     error: error
//                 })
//             })
//     } catch (err) {
//         return res.status(500).json({
//             status: false,
//             message: "Unable To Send email",
//             err: err
//         });
//     }
// });

//changes by krushnavandan 0n 8/7/23
module.exports.sendmail = catchAsyncErrors(async (req, res, next) => {
    const email = req.params.email
    const bookingId = req.params.bookingId

    const bookingData = await BookingData.create(req.body)

    try {
        const config = {
            headers: {
                "X-SF-API-KEY": process.env.X_SF_API_KEY
            }
        };
        axios
            .get(
                `https://api.stayflexi.com/core/api/v1/beservice/bookinginfo?bookingId=${bookingId}`,
                config,
                null)
            .then(function (response) {
                var sendData = response.data;


                const config = {
                    headers: {
                        "X-SF-API-KEY": process.env.X_SF_API_KEY
                    }
                };
                axios
                    .get(
                        `https://api.stayflexi.com/core/api/v1/beservice/hotelcontent?hotelId=${sendData.hotelId}`,
                        config,
                        null)
                    .then(async function (response) {
                        var checkin = moment(new Date(sendData.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('ddd, DD MMM YYYY')
                        var checkout = moment(new Date(sendData.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('ddd, DD MMM YYYY')
                        var checkintime = moment(new Date(sendData.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format("hh:mm A")
                        var checkouttime = moment(new Date(sendData.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format("hh:mm A")

                        if (sendData.paymentDetails.payAtHotel == true) {
                            var Amount_paid = 0.00
                            var Balance_due = sendData.paymentDetails.sellRate
                        }
                        if (sendData.paymentDetails.payAtHotel == false) {
                            var Amount_paid = sendData.paymentDetails.sellRate
                            var Balance_due = 0.00
                        }


                        // const Bookings = await Booking.findOne({
                        //     bookingId: bookingId
                        // });

                        // console.log("Bookings++++", Bookings)
                        // let taxamount = Bookings.tax || 0.00
                        // let Finaltotal = Bookings.amount || 0.00
                        // var subtotal = Finaltotal - taxamount || 0.00

                        //changes by krushn 19-07-23
                        let taxamount = req.body.data.tax || 0.00
                        let Finaltotal = req.body.data.paymentDetails.roomRate || 0.00
                        var subtotal = Finaltotal - taxamount || 0.00

                        const bookingdata = {
                            hotelName: sendData.hotelName,
                            latitude: response.data.latitude,
                            longitude: response.data.longitude,
                            // roomStays: sendData.roomStays,
                            roomStays: req.body.data.roomStays,
                            checkin: checkin,
                            checkintime: checkintime,
                            checkout: checkout,
                            checkouttime: checkouttime,
                            hotelAddress: sendData.hotelAddress,
                            hotelState: sendData.hotelState,
                            hotelCity: sendData.hotelCity,
                            hotelCountry: sendData.hotelCountry,
                            hotelZipcode: sendData.hotelZipcode,
                            hotelEmail: sendData.hotelEmail,
                            hotelContact: sendData.hotelContact,
                            cancellationPolicyInfo: sendData.cancellationPolicyInfo.policyDescription,
                            // promoAmount: sendData.promoAmount.toFixed(2),
                            subtotal: subtotal.toFixed(2),
                            tax: Number(taxamount).toFixed(2),
                            Finaltotal: Finaltotal.toFixed(2),
                            Amount_paid: Amount_paid.toFixed(2),
                            Balance_due: Balance_due.toFixed(2),
                            bookingId: bookingId
                        };

                        await sendEmail(email, bookingdata)

                        // mail send to client
                        const mail = "info.iipl@iroomz.in"
                        await sendEmail(mail, bookingdata)

                        return res.status(200).json({
                            status: true,
                            msg: "Email Sent To Your Mail...Please Check",
                        })
                    })
                    .catch(function (error) {
                        return res.status(500).json({
                            message: "Unable To Send email",
                            error: error
                        })
                    })
            })
            .catch(function (error) {
                return res.status(500).json({
                    message: "Unable To Send email",
                    error: error
                })
            })
    } catch (err) {
        return res.status(500).json({
            status: false,
            message: "Unable To Send email",
            err: err
        });
    }
});

// cancelled booking mail

module.exports.sendcancelmail = catchAsyncErrors(async (req, res, next) => {

    const bookingId = req.params.bookingId
    try {
        const config = {
            headers: {
                "X-SF-API-KEY": process.env.X_SF_API_KEY
            }
        };
        axios
            .get(
                `https://api.stayflexi.com/core/api/v1/beservice/bookinginfo?bookingId=${bookingId}`, config, null)
            .then(async function (response) {
                var sendData = response.data;

                var checkin = moment(new Date(sendData.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('ddd, DD MMM YYYY')
                var checkout = moment(new Date(sendData.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format('ddd, DD MMM YYYY')
                var checkintime = moment(new Date(sendData.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format("hh:mm A")
                var checkouttime = moment(new Date(sendData.actualCheckout.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).format("hh:mm A")

                let Policy = sendData.cancellationPolicyInfo.policyDescription.split("within ")
                const array = Policy[1].charAt(0);
                var datenow = moment().format('DD-MM-yyyy HH:mm:ss:a')
                var actualdate = moment(new Date(sendData.actualCheckin.replace(/(\d{2})-(\d{2})-(\d{4})/, "$2/$1/$3"))).subtract(array, 'days').format('DD-MM-yyyy HH:mm:ss:a')
                if (sendData.paymentDetails.payAtHotel == true) {
                    var Amount_paid = 0.00
                    var Balance_due = sendData.paymentDetails.sellRate
                }
                if (sendData.paymentDetails.payAtHotel == false) {
                    var Amount_paid = sendData.paymentDetails.sellRate
                    var Balance_due = 0.00
                }

                const Bookings = await Booking.findOne({
                    bookingId: bookingId
                });
                let taxamount = Bookings.tax || 0.00
                let Finaltotal = Bookings.amount || 0.00
                var subtotal = Finaltotal - taxamount || 0.00

                const bookingdata = {
                    date: actualdate,
                    datenow: datenow,
                    hotelName: sendData.hotelName,
                    roomTypeName: sendData.roomTypeName,
                    ratePlanName: sendData.ratePlanName,
                    checkin: checkin,
                    checkintime: checkintime,
                    checkout: checkout,
                    checkouttime: checkouttime,
                    firstName: sendData.customerDetails.firstName,
                    emailId: sendData.customerDetails.emailId,
                    phoneNumber: sendData.customerDetails.phoneNumber,
                    hotelAddress: sendData.hotelAddress,
                    hotelState: sendData.hotelState,
                    hotelCity: sendData.hotelCity,
                    hotelCountry: sendData.hotelCountry,
                    hotelZipcode: sendData.hotelZipcode,
                    hotelEmail: sendData.hotelEmail,
                    hotelContact: sendData.hotelContact,
                    cancellationPolicyInfo: sendData.cancellationPolicyInfo.policyDescription,
                    // promoAmount: sendData.promoAmount.toFixed(2),
                    subtotal: subtotal.toFixed(2),
                    tax: taxamount.toFixed(2),
                    Finaltotal: Finaltotal.toFixed(2),
                    Amount_paid: Amount_paid.toFixed(2),
                    Balance_due: Balance_due.toFixed(2),
                    bookingId: bookingId
                };

                const email = sendData.customerDetails.emailId;
                await sendCancelEmail(email, bookingdata)

                // mail send to client
                const mail = "info.iipl@iroomz.in"
                await sendCancelEmail(mail, bookingdata)

                // To Update in Database
                const updatedStatus = "CANCELLED";

                let bookingData = await BookingData.findOne({ "data.bookingId": bookingId })
                if (!bookingData) {
                    return next(new ErrorHandler("Booking Not Found", 404));
                }

                const id = await bookingData.id;

                const updatedBookingData = await BookingData.findByIdAndUpdate(
                    id,
                    { "data.bookingStatus": updatedStatus },
                    { new: true }
                );

                if (!updatedBookingData) {
                    return res.status(404).json({
                        status: false,
                        message: "Booking data not found",
                    });
                }

                return res.status(200).json({
                    status: true,
                    msg: "Email Sent To Your Mail...Please Check",
                })
            })
            .catch(function (error) {
                res.status(500).json({
                    status: false,
                    message: "Unable To Send email",
                    err: error.message
                });
            })
    } catch (err) {
        res.status(500).json({
            status: false,
            message: "Unable To Send email",
            err: err.message
        });
    }
});

// Bookings By Hotel Id

module.exports.bookingByHotel = catchAsyncErrors(async (req, res) => {
    try {
        const resultPerPage = Number(req.query.limit) || 10;

        let totalBooking = await Booking.countDocuments();
        const sort = {};

        if (req.query.sortBy && req.query.hotel) {
            sort[req.query.sortBy] = req.query.booking === "desc" ? -1 : 1;
        }

        const apiFeature = new ApiFeatures(Booking.find({ hotel_id: req.params.hotelId }).sort(sort), req.query)
            .filter()
            .search()
            .pagination(resultPerPage);
        let bookings = await apiFeature.query;
        let filteredBookingCount = bookings.length;

        return res.status(200).json({
            status: true,
            totalBooking,
            filteredBooking: filteredBookingCount,
            page: req.query.page,
            limit: resultPerPage,
            bookings,
        });
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

})

// Bookings By valid date

module.exports.bookingByHoteldate = catchAsyncErrors(async (req, res) => {
    firstday = req.params.firstday
    lastDay = req.params.lastDay
    try {
        const resultPerPage = Number(req.query.limit) || 10;

        let totalBooking = await Booking.countDocuments();
        const sort = {};

        if (req.query.sortBy && req.query.hotel) {
            sort[req.query.sortBy] = req.query.booking === "desc" ? -1 : 1;
        }
        const apiFeature = new ApiFeatures(Booking.find({
            "checkInDate": {
                '$gte': firstday, '$lte': lastDay
            }
        }).sort(sort), req.query)
            .filter()
            .search()
            .pagination(resultPerPage);
        let bookings = await apiFeature.query;
        let filteredBookingCount = bookings.length;

        return res.status(200).json({
            status: true,
            totalBooking,
            filteredBooking: filteredBookingCount,
            page: req.query.page,
            limit: resultPerPage,
            bookings,
        });
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

})

// Bookings By status

module.exports.bookingByHotelstatus = catchAsyncErrors(async (req, res, next) => {
    firstday = req.params.firstday
    lastDay = req.params.lastDay
    try {
        // const resultPerPage = Number(req.query.limit) || 10;
        // let totalBooking = await Booking.countDocuments();
        const sort = {};
        if (req.query.sortBy && req.query.hotel) {
            sort[req.query.sortBy] = req.query.booking === "desc" ? -1 : 1;
        }
        const apiFeature = new ApiFeatures(Booking.find({
            "checkInDate": {
                '$gte': firstday, '$lte': lastDay
            },
            "paymentStatus": { $in: req.params.status },
        }).sort(sort), req.query)
            .filter()
            .search()
        // .pagination(resultPerPage);
        let bookings = await apiFeature.query;
        if (bookings.length == 0) {
            return next(new ErrorHandler("Booking Not Found", 404));
        }
        var booking = [];

        bookings.forEach((obj) => {
            const { bookingId, hotelname, checkInDate, checkOutDate, noOfGuest, customerName, customerEmail, contactNo, paymentStatus } = obj;
            var Date = obj.checkInDate
            var CheckInDate = Date.toLocaleDateString();
            var Date = obj.checkOutDate
            var CheckOutDate = Date.toLocaleDateString();
            booking.push({ bookingId, hotelname, CheckInDate, CheckOutDate, noOfGuest, customerName, customerEmail, contactNo, paymentStatus });
        });

        const csvFields = ["bookingId", "hotelname", "CheckInDate", "CheckOutDate", "noOfGuest", "customerName", "customerEmail", "contactNo", "paymentStatus"];
        const csvParser = new CsvParser({ csvFields });
        const csvData = csvParser.parse(booking);
        let rgx = /"/g;
        let removedQuotes = csvData.replace(rgx, '');
        const csvFileTxt = removedQuotes.toString()
        return res.status(200).end(
            csvFileTxt
        );

    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

})

// Bookings By status(all)

module.exports.bookingByHotelall = catchAsyncErrors(async (req, res, next) => {
    firstday = req.params.firstday
    lastDay = req.params.lastDay

    try {
        // const resultPerPage = Number(req.query.limit) || 10;
        // let totalBooking = await Booking.countDocuments();
        const sort = {};
        if (req.query.sortBy && req.query.hotel) {
            sort[req.query.sortBy] = req.query.booking === "desc" ? -1 : 1;
        }
        const apiFeature = new ApiFeatures(Booking.find({ "checkInDate": { '$gte': firstday, '$lte': lastDay } }).sort(sort), req.query)
            .filter()
            .search()
        // .pagination(resultPerPage);

        let bookings = await apiFeature.query;
        if (bookings.length == 0) {
            return next(new ErrorHandler("Booking Not Found", 404));
        }
        var booking = [];

        bookings.forEach((obj) => {
            const { bookingId, hotelname, checkInDate, checkOutDate, noOfGuest, customerName, customerEmail, contactNo, paymentStatus } = obj;
            var Date = obj.checkInDate
            var CheckInDate = Date.toLocaleDateString();
            var Date = obj.checkOutDate
            var CheckOutDate = Date.toLocaleDateString();
            booking.push({ bookingId, hotelname, CheckInDate, CheckOutDate, noOfGuest, customerName, customerEmail, contactNo, paymentStatus });
        });

        const csvFields = ["bookingId", "hotelname", "CheckInDate", "CheckOutDate", "noOfGuest", "customerName", "customerEmail", "contactNo", "paymentStatus"];
        const csvParser = new CsvParser({ csvFields });
        const csvData = csvParser.parse(booking);
        let rgx = /"/g;
        let removedQuotes = csvData.replace(rgx, '');
        const csvFileTxt = removedQuotes.toString()

        return res.status(200).end(
            csvFileTxt
        );
    } catch (error) {
        return res.status(400).json({
            status: false,
            message: error
        });
    }

})

/* --------------- Total Bookings --------------- */

// day 

exports.filtersBookingday = catchAsyncErrors(async (req, res) => {

    const new_date = date_IST();
    var date_now = new_date.getDate()
    var first = new Date(new_date.setDate(date_now - 1));
    var last = new Date(new_date.setDate(date_now + 1));
    try {
        const apiFeature = new ApiFeatures(Booking.find({
            "DatenowAt": { '$gt': first, '$lt': last },
        }))
        let data = await apiFeature.query;
        let totalBooking = await Booking.countDocuments();
        let avg = 0 + data?.length / totalBooking;
        return res.status(200).json({
            success: true,
            date: new_date,
            average: parseFloat(avg.toFixed(2)),
            count: data?.length,
            Booking: data,
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// week 

exports.filtersBookingweek = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    var first = new_date.getDate()
    var lastDayWeek = new Date(new_date.setDate(first - 6));
    const firstDayWeek = date_IST();

    // .getDay()
    try {
        const data = await Booking.aggregate([
            {
                $match: {
                    createdAt: {
                        $gt: lastDayWeek,
                        $lt: firstDayWeek,
                    },
                },
            }
        ]);
        let totalBooking = await Booking.countDocuments();
        let avg = 0 + data?.length / totalBooking;
        return res.status(200).json({
            success: true,
            average: parseFloat(avg.toFixed(2)),
            start: firstDayWeek,
            end: lastDayWeek,
            count: data?.length,
            Booking: data,
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// month 

exports.filtersBookingmonth = catchAsyncErrors(async (req, res) => {
    const date = date_IST();
    month = req.query.month || 1;
    let totalBooking = await Booking.countDocuments();
    const lastMonth = new Date(date.setMonth(date.getMonth()));
    const previousMonth = new Date(
        date.setMonth(lastMonth.getMonth() - month)
    );

    try {
        const monthdata = await Booking.aggregate([
            {
                $match: {
                    createdAt: { $gte: previousMonth },
                }
            },
            {
                $group: {
                    _id: { month: { $month: { $toDate: "$createdAt" } } },
                    Booking: { $count: {} }, // or { $sum: 1 } prior to Mongo 5
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);
        var month = [];
        for (let i = 0; i < monthdata.length; i++) {
            month.push(monthdata[i].Booking)
        }
        const monthsum = month.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let monthBooking = 0 + monthsum / totalBooking;
        return res.status(200).json({
            success: true,
            monthavg: parseFloat(monthBooking.toFixed(2)),
            count: monthsum,
            monthdata
        });
    } catch (err) {
        return res.status(500).json(err.message);
    }
});

// year 

exports.filtersBookingyear = catchAsyncErrors(async (req, res) => {
    year = req.query.year || 1;
    let totalBooking = await Booking.countDocuments();
    const date = date_IST();
    const lastyear = new Date(
        date.setFullYear(date.getFullYear())
    );
    const previousyear = new Date(
        date.setFullYear(lastyear.getFullYear() - year)
    );
    try {
        const data = await Booking.aggregate([
            { $match: { createdAt: { $gte: previousyear } } },
            {
                $group: {
                    _id: { year: { $year: { $toDate: "$createdAt" } } },
                    Booking: { $count: {} },
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);
        var year = [];
        for (let i = 0; i < data.length; i++) {
            year.push(data[i].Booking)
        }
        const yearsum = year.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let yearBooking = 0 + yearsum / totalBooking;

        return res.status(200).json({
            success: true,
            yearavg: parseFloat(yearBooking.toFixed(2)),
            count: yearsum,
            data
        });
    } catch (err) {
        return res.status(500).json(err);
    }
});

/* --------------- Upcoming Bookings --------------- */

// day 

exports.UpcomingBookingday = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    var date = new_date.getDate()
    var date_now = new Date(new_date.setDate(date + 1));
    const now = date_now.getDate()
    var first = new Date(new_date.setDate(now - 1));
    var last = new Date(new_date.setDate(now + 1));
    try {
        const apiFeature = new ApiFeatures(Booking.find({
            "checkInDate": { '$gt': first, '$lt': last },
        }))
        let Bookings = await apiFeature.query;
        let totalBooking = await Booking.countDocuments();
        let avg = 0 + Bookings?.length / totalBooking;

        return res.status(200).json({
            success: true,
            date: date_now,
            average: parseFloat(avg.toFixed(2)),
            count: Bookings?.length,
            Booking: Bookings,
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// week 

exports.Upcomingbookingweek = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    var first = new_date.getDate()
    var lastDayWeek = new Date(new_date.setDate(first + 6));
    var firstDayWeek = new Date(new_date.setDate(first));

    try {
        const apiFeature = new ApiFeatures(Booking.find({
            "checkInDate": { '$gte': firstDayWeek },
            "checkOutDate": { '$lt': lastDayWeek }
        }))
        let Bookings = await apiFeature.query;

        let totalBooking = await Booking.countDocuments();
        let avg = 0 + Bookings?.length / totalBooking;

        return res.status(200).json({
            success: true,
            start: firstDayWeek,
            end: lastDayWeek,
            average: parseFloat(avg.toFixed(2)),
            count: Bookings?.length,
            Booking: Bookings,
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// month 

exports.UpcomingBookingmonth = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    month = req.query.month || 1;
    const lastMonth = new Date(new_date.setMonth(new_date.getMonth()));
    const previousMonth = new Date(
        new_date.setMonth(lastMonth.getMonth() + month)
    );
    try {
        const apiFeature = new ApiFeatures(Booking.find({
            "checkInDate": { '$gte': lastMonth },
            "checkOutDate": { '$lt': previousMonth }
        }))
        let Bookings = await apiFeature.query;

        let totalBooking = await Booking.countDocuments();
        let avg = 0 + Bookings?.length / totalBooking;

        return res.status(200).json({
            success: true,
            start: lastMonth,
            end: previousMonth,
            average: parseFloat(avg.toFixed(2)),
            count: Bookings?.length,
            Booking: Bookings,
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// year 

exports.UpcomingBookingyear = catchAsyncErrors(async (req, res) => {
    year = req.query.year || 1;
    const new_date = date_IST();
    const lastyear = new Date(
        new_date.setFullYear(new_date.getFullYear())
    );
    const previousyear = new Date(
        new_date.setFullYear(lastyear.getFullYear() + year)
    );
    try {
        const apiFeature = new ApiFeatures(Booking.find({
            "checkInDate": { '$gte': lastyear },
            "checkOutDate": { '$lt': previousyear }
        }))
        let Bookings = await apiFeature.query;

        let totalBooking = await Booking.countDocuments();
        let avg = 0 + Bookings?.length / totalBooking;

        return res.status(200).json({
            success: true,
            start: lastyear,
            end: previousyear,
            average: parseFloat(avg.toFixed(2)),
            count: Bookings?.length,
            Booking: Bookings,
        });
    } catch (err) {
        return res.status(500).json(err);
    }
});

/* --------------- Confirmed Bookings --------------- */

// day 

exports.ConfirmedBookingday = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    var date_now = new_date.getDate()
    var first = new Date(new_date.setDate(date_now - 1));
    var last = new Date(new_date.setDate(date_now + 1));

    try {
        const apiFeature = new ApiFeatures(Booking.find({
            "DatenowAt": { '$gt': first, '$lt': last },
            "paymentStatus": { '$eq': "Confirmed" }
        }))
        let data = await apiFeature.query;
        let totalBooking = await Booking.countDocuments();
        let avg = 0 + data?.length / totalBooking;
        return res.status(200).json({
            success: true,
            date: new_date,
            average: parseFloat(avg.toFixed(2)),
            count: data?.length,
            Booking: data,
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// week 

exports.Confirmedbookingweek = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    var first = new_date.getDate();
    var lastDayWeek = new Date(new_date.setDate(first - 6));
    var firstDayWeek = date_IST();
    try {
        const data = await Booking.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: lastDayWeek,
                        $lte: firstDayWeek,
                    },
                    paymentStatus: {
                        $eq: "Confirmed",
                    },
                },
            }
        ]);
        let totalBooking = await Booking.countDocuments();
        let avg = 0 + data?.length / totalBooking;
        return res.status(200).json({
            success: true,
            start: firstDayWeek,
            end: lastDayWeek,
            average: parseFloat(avg.toFixed(2)),
            count: data?.length,
            Booking: data,
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// month 

exports.ConfirmedBookingmonth = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    month = req.query.month || 1;
    let totalBooking = await Booking.countDocuments();
    const lastMonth = new Date(new_date.setMonth(new_date.getMonth()));
    const previousMonth = new Date(
        new_date.setMonth(lastMonth.getMonth() - month)
    );
    try {
        const monthdata = await Booking.aggregate([
            {
                $match: {
                    createdAt: { $gte: previousMonth },
                    paymentStatus: {
                        $eq: "Confirmed",
                    },
                }
            },
            {
                $group: {
                    _id: { month: { $month: { $toDate: "$createdAt" } } },
                    Booking: { $count: {} }, // or { $sum: 1 } prior to Mongo 5
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);
        var month = [];
        for (let i = 0; i < monthdata.length; i++) {
            month.push(monthdata[i].Booking)
        }
        const monthsum = month.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let monthBooking = 0 + monthsum / totalBooking;
        return res.status(200).json({
            success: true,
            monthavg: parseFloat(monthBooking.toFixed(2)),
            count: monthsum,
            monthdata
        });
    } catch (err) {
        return res.status(500).json(err.message);
    }
});

// year 

exports.ConfirmedBookingyear = catchAsyncErrors(async (req, res) => {
    year = req.query.year || 1;
    const new_date = date_IST();
    let totalBooking = await Booking.countDocuments();
    const lastyear = new Date(
        new_date.setFullYear(new_date.getFullYear())
    );
    const previousyear = new Date(
        new_date.setFullYear(lastyear.getFullYear() - year)
    );
    try {
        const data = await Booking.aggregate([
            {
                $match: {
                    createdAt: { $gte: previousyear },
                    paymentStatus: {
                        $eq: "Confirmed",
                    },
                }
            },
            {
                $group: {
                    _id: { year: { $year: { $toDate: "$createdAt" } } },
                    Booking: { $count: {} },
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);
        var year = [];
        for (let i = 0; i < data.length; i++) {
            year.push(data[i].Booking)
        }
        const yearsum = year.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let yearBooking = 0 + yearsum / totalBooking;
        return res.status(200).json({
            success: true,
            yearavg: parseFloat(yearBooking.toFixed(2)),
            count: yearsum,
            data
        });
    } catch (err) {
        return res.status(500).json(err);
    }
});

/* --------------- recent Bookings chart--------------- */

// day 

exports.recentBookingday = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    var date_now = new_date.getDate()
    var first = new Date(new_date.setDate(date_now - 1));
    var last = new Date(new_date.setDate(date_now + 1));
    let totalBooking = await Booking.countDocuments();

    try {
        /* --------------- Confirmed data: check for daily Confirmed Booking--------------- */

        const Confirmeddata = await Booking.aggregate([
            {
                $match: {
                    DatenowAt: {
                        $gt: first,
                        $lt: last,
                    },
                    paymentStatus: {
                        $eq: "Confirmed",
                    },
                },
            },
            // {
            //     $group: {
            //         _id: { hour: { $hour: { $toDate: "$createdAt" } } },
            //         date: { $first: '$createdAt' },
            //         Booking: { $count: {} },
            //         data: { $push: "$$ROOT" },
            //     },
            // },
            { $sort: { _id: 1 } },
        ]);
        var Confirmed = [];

        for (let i = 0; i < Confirmeddata.length; i++) {
            Confirmed.push(Confirmeddata[i].Booking)
        }
        const Confirmedsum = Confirmed.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        // let ConfirmedgBooking = 0 + Confirmedsum / totalBooking;
        let ConfirmedgBooking = 0 + Confirmeddata?.length / totalBooking;

        /* --------------- Confirmed data: check for daily Confirmed Booking--------------- */

        const Cancelleddata = await Booking.aggregate([
            {
                $match: {
                    CancelledAt: {
                        $gt: first,
                        $lt: last,
                    },
                    paymentStatus: {
                        $eq: "Cancelled",
                    },
                },
            },
            // {
            //     $group: {
            //         _id: { hour: { $hour: { $toDate: "$CancelledAt" } } },
            //         date: { $first: '$CancelledAt' },
            //         Booking: { $count: {} },
            //         data: { $push: "$$ROOT" },
            //     },
            // },
            { $sort: { _id: 1 } },
        ]);
        var Cancelled = [];

        for (let i = 0; i < Cancelleddata.length; i++) {
            Cancelled.push(Cancelleddata[i].Booking)
        }
        const Cancelledsum = Cancelled.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        // let CancelledBooking = 0 + Cancelledsum / totalBooking;
        let CancelledBooking = 0 + Cancelleddata?.length / totalBooking;

        return res.status(200).json({
            success: true,
            date_now: date_IST(),
            // Cancelledavg: parseFloat(CancelledBooking.toFixed(2)),
            // Confirmedavg: parseFloat(ConfirmedgBooking.toFixed(2)),
            // Cancelledlength: Cancelledsum,
            // Confirmedlength: Confirmedsum,
            Cancelledavg: parseFloat(CancelledBooking.toFixed(2)),
            Confirmedavg: parseFloat(ConfirmedgBooking.toFixed(2)),
            Cancelledlength: Cancelleddata?.length,
            Confirmedlength: Confirmeddata?.length,
            Cancelleddata,
            Confirmeddata
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// week 

exports.recentBookingweek = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    var first = new_date.getDate()
    let totalBooking = await Booking.countDocuments();
    var lastDayWeek = new Date(new_date.setDate(first - 6));
    var firstDayWeek = date_IST();
    try {
        /* --------------- Confirmed data: check for weekly Confirmed Booking--------------- */

        const Confirmeddata = await Booking.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: lastDayWeek,
                        $lte: firstDayWeek,
                    },
                    paymentStatus: {
                        $eq: "Confirmed",
                    },
                },
            },
            {
                $group: {
                    _id: { day: { $dayOfWeek: { $toDate: "$createdAt" } } },
                    Date: { $first: { createdAt: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } } } },
                    Booking: { $count: {} }, // or { $sum: 1 } prior to Mongo 5
                    data: { $push: "$$ROOT" },
                },
            },
        ]);

        var Confirmed = [];

        for (let i = 0; i < Confirmeddata.length; i++) {
            Confirmed.push(Confirmeddata[i].Booking)
        }
        const Confirmedsum = Confirmed.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let ConfirmedgBooking = 0 + Confirmedsum / totalBooking;

        /* --------------- Cancelled data: check for weekly Cancelled Booking --------------- */

        const Cancelleddata = await Booking.aggregate([
            {
                $match: {
                    CancelledAt: {
                        $gte: lastDayWeek,
                        $lte: firstDayWeek,
                    },
                    paymentStatus: {
                        $eq: "Cancelled",
                    },
                }
            },
            {
                $group: {
                    _id: { day: { $dayOfWeek: { $toDate: "$CancelledAt" } } },
                    Date: { $first: { CancelledAt: { $dateToString: { format: "%Y-%m-%d", date: "$CancelledAt" } } } },
                    Booking: { $count: {} },
                    data: { $push: "$$ROOT" },
                },
            },
        ]);
        var Cancelled = [];

        for (let i = 0; i < Cancelleddata.length; i++) {
            Cancelled.push(Cancelleddata[i].Booking)
        }
        const Cancelledsum = Cancelled.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let CancelledBooking = 0 + Cancelledsum / totalBooking;

        return res.status(200).json({
            success: true,
            start: firstDayWeek,
            end: lastDayWeek,
            Cancelledavg: parseFloat(CancelledBooking.toFixed(2)),
            Confirmedavg: parseFloat(ConfirmedgBooking.toFixed(2)),
            Cancelledlength: Cancelledsum,
            Confirmedlength: Confirmedsum,
            Cancelleddata,
            Confirmeddata
        });
    } catch (err) {
        res.status(500).json(err.message);
    }
});

// month 

exports.recentBookingmonth = catchAsyncErrors(async (req, res) => {
    const new_date = date_IST();
    month = req.query.month || 12;
    let totalBooking = await Booking.countDocuments();
    const lastMonth = new Date(new_date.setMonth(new_date.getMonth()));
    const previousMonth = new Date(
        new_date.setMonth(lastMonth.getMonth() - month)
    );
    try {
        /* --------------- Confirmed data: check for monthly Confirmed Booking--------------- */

        const Confirmeddata = await Booking.aggregate([
            {
                $match: {
                    createdAt: { $gte: previousMonth },
                    paymentStatus: { $eq: "Confirmed" }
                }
            },
            {
                $group: {
                    _id: { month: { $month: { $toDate: "$createdAt" } } },
                    Booking: { $count: {} }, // or { $sum: 1 } prior to Mongo 5
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);
        var Confirmed = [];
        for (let i = 0; i < Confirmeddata.length; i++) {
            Confirmed.push(Confirmeddata[i].Booking)
        }
        const Confirmedsum = Confirmed.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let ConfirmedgBooking = 0 + Confirmedsum / totalBooking;

        /* --------------- Cancelled data: check for monthly Cancelled Booking --------------- */

        const Cancelleddata = await Booking.aggregate([
            {
                $match: {
                    CancelledAt: { $gte: previousMonth },
                    paymentStatus: { $eq: "Cancelled" }
                }
            },
            {
                $group: {
                    _id: { month: { $month: { $toDate: "$CancelledAt" } } },
                    Booking: { $count: {} }, // or { $sum: 1 } prior to Mongo 5
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);
        var Cancelled = [];
        for (let i = 0; i < Cancelleddata.length; i++) {
            Cancelled.push(Cancelleddata[i].Booking)
        }
        const Cancelledsum = Cancelled.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let CancelledBooking = 0 + Cancelledsum / totalBooking;

        return res.status(200).json({
            success: true,
            Cancelledavg: parseFloat(CancelledBooking.toFixed(2)),
            Confirmedavg: parseFloat(ConfirmedgBooking.toFixed(2)),
            Cancelledlength: Cancelledsum,
            Confirmedlength: Confirmedsum,
            Cancelleddata,
            Confirmeddata,
            month: "month"
        });
    } catch (err) {
        return res.status(500).json(err.message);
    }
});

// year 

exports.recentBookingyear = catchAsyncErrors(async (req, res) => {
    year = req.query.year || 1;
    const new_date = date_IST();
    let totalBooking = await Booking.countDocuments();
    const lastyear = new Date(new_date.setFullYear(new_date.getFullYear()))
    const previousyear = new Date(new_date.setFullYear(lastyear.getFullYear() - year))
    try {
        /* --------------- Confirmed data: check for yearly Confirmed Booking--------------- */

        const Confirmeddata = await Booking.aggregate([
            {
                $match: {
                    createdAt: { $gte: previousyear },
                    paymentStatus: {
                        $eq: "Confirmed",
                    },
                }
            },
            {
                $group: {
                    _id: { year: { $year: { $toDate: "$createdAt" } } },
                    Booking: { $count: {} },
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);

        var Confirmed = [];

        for (let i = 0; i < Confirmeddata.length; i++) {
            Confirmed.push(Confirmeddata[i].Booking)
        }
        const Confirmedsum = Confirmed.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let ConfirmedgBooking = 0 + Confirmedsum / totalBooking;

        /* --------------- Cancelled data: check for yearly Cancelled Booking --------------- */

        const Cancelleddata = await Booking.aggregate([
            {
                $match: {
                    CancelledAt: { $gte: previousyear },
                    paymentStatus: {
                        $eq: "Cancelled",
                    },
                }
            },
            {
                $group: {
                    _id: { year: { $year: { $toDate: "$CancelledAt" } } },
                    Booking: { $count: {} },
                    data: { $push: "$$ROOT" },
                },
            },
            { $sort: { _id: 1 } },
        ]);

        var Cancelled = [];

        for (let i = 0; i < Cancelleddata.length; i++) {
            Cancelled.push(Cancelleddata[i].Booking)
        }
        const Cancelledsum = Cancelled.reduce(add, 0);

        function add(accumulator, a) {
            return accumulator + a;
        }
        let CancelledBooking = 0 + Cancelledsum / totalBooking;

        return res.status(200).json({
            success: true,
            Cancelledavg: parseFloat(CancelledBooking.toFixed(2)),
            Confirmedavg: parseFloat(ConfirmedgBooking.toFixed(2)),
            Cancelledlength: Cancelledsum,
            Confirmedlength: Confirmedsum,
            Cancelleddata,
            Confirmeddata,
            year: "year"

        });
    } catch (err) {
        return res.status(500).json(err);
    }
});