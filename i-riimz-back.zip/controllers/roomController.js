const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const Room = require("../models/roomsModel");

// create Room

module.exports.createRoom = catchAsyncErrors(async (req, res) => {
    var image = req.file.path;

    try {
        const {
            ax_room_id,
            active,
            room_name,
            rate_plan_json,
            ax_hotel_id,
            hotel_id,
            room_video_url
        } = req.body;


        const rooms = await Room.create({
            cover_photo: image,
            ax_room_id,
            active,
            room_name,
            rate_plan_json,
            ax_hotel_id,
            hotel_id,
            room_video_url
        });
        if (!rooms) {
            return res.status(500).send("Room Cannot Be Created");
        }
        return res.status(201).json({
            status: true,
            rooms,
        });
    } catch (error) {
        return res.status(404).json({
            status: false,
            message: error,
        });
    }


});

//get all Room

module.exports.getAllRooms = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let totalRoom = await Room.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.room) {
        sort[req.query.sortBy] = req.query.room === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(Room.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let rooms = await apiFeature.query;
    let filteredRoomCount = rooms.length;

    return res.status(200).json({
        status: true,
        totalRoom,
        filteredRoom: filteredRoomCount,
        page: req.query.page,
        limit: resultPerPage,
        rooms,
    });
});

//getSingle Room

module.exports.getSingleRoom = catchAsyncErrors(async (req, res, next) => {
    try {
        let room = await Room.findById(req.params.id);
        if (!room) {
            return next(new errorhandaler("Room Not Found", 404));
        } else {
            return res.status(200).json({
                status: true,
                room,
            });
        }
    } catch (error) {
        return res.status(404).json({
            status: false,
            message: error
        });
    }

});

//Update Room

module.exports.updateRoom = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let room = await Room.findById(id);

    if (!room) {
        return res.status(404).json({ msg: "Cannot Found Room.." });
    }
    try {
        if (!req.file) {
            const data = {
                cover_photo: room.cover_photo,
                ax_room_id: req.body.ax_room_id || room.ax_room_id,
                active: req.body.active || room.active,
                room_name: req.body.room_name || room.room_name,
                rate_plan_json: req.body.rate_plan_json || room.rate_plan_json,
                ax_hotel_id: req.body.ax_hotel_id || room.ax_hotel_id,
                hotel_id: req.body.hotel_id || room.hotel_id,
                room_video_url: req.body.room_video_url || room.room_video_url,
            };
            const updateRoom = await Room.findByIdAndUpdate(id, data, {
                new: true,
            });
            res.status(200).json({
                status: true,
                msg: "Room Updated Successfully...",
                updateRoom,
            });
        } else {
            var image = req.file.path;

            const data = {
                cover_photo: image,
                ax_room_id: req.body.ax_room_id || room.ax_room_id,
                active: req.body.active || room.active,
                room_name: req.body.room_name || room.room_name,
                rate_plan_json: req.body.rate_plan_json || room.rate_plan_json,
                ax_hotel_id: req.body.ax_hotel_id || room.ax_hotel_id,
                hotel_id: req.body.hotel_id || room.hotel_id,
            };
            const updateRoom = await Room.findByIdAndUpdate(id, data, {
                new: true,
            });
            return res.status(200).json({
                status: true,
                msg: "Room Updated Successfully...",
                updateRoom,
            });
        }
    } catch (error) {
        return res.status(404).json({
            status: false,
            msg: error
        });
    }

});

//Delete Blog

module.exports.deleteRoom = catchAsyncErrors(async (req, res) => {

    try {
        const data = await Room.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(404).json({
                message: "Room Not Found"
            });
        }
        return res.status(200).json({
            status: true,
            message: "Room Deleted Successfully"
        });
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        });
    }
});


// Room By Hotel Id
module.exports.RoomByHotel = catchAsyncErrors(async (req, res) => {
    try {
        const rooms = await Room.find({ hotel_id: req.params.hotelId }).populate("hotel_id");
        if (!rooms) {
            return res.status(400).json({
                status: false,
                message: " Not Found..."
            })
        }
        var hotelname = rooms[0].hotel_id.hotel_name
        const resultPerPage = Number(req.query.limit) || 10;
        let totalRoom = await Room.countDocuments();
        const sort = {};

        if (req.query.sortBy && req.query.room) {
            sort[req.query.sortBy] = req.query.room === "desc" ? -1 : 1;
        }

        const apiFeature = new ApiFeatures(Room.find({ hotel_id: req.params.hotelId }).sort(sort), req.query)
            .filter()
            .search()
            .pagination(resultPerPage);

        let roomsByHotel = await apiFeature.query;
        let filteredRoomCount = roomsByHotel.length;

        return res.status(200).json({
            status: true,
            totalRoom,
            Count: filteredRoomCount,
            page: req.query.page,
            limit: resultPerPage,
            hotelname: hotelname,
            roomsByHotel,
        });
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        })
    }
})
