const agent = require("../models/agentModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const bcrypt = require("bcryptjs");

// create agents

module.exports.createagents = catchAsyncErrors(async (req, res) => {

    const { name, email, password, mobile, status } = req.body;
    encryptedPassword = await bcrypt.hash(password, 10);
    const agents = await agent.create({
        name,
        email,
        password: encryptedPassword,
        mobile,
        status,
    });
    if (!agents) {
        return res.status(500).send("Agents Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        agents,
    });
});

//get all agent

module.exports.getallagents = catchAsyncErrors(async (req, res, next) => {

    const resultPerPage = Number(req.query.limit) || 10;
    let totalagent = await agent.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.agent) {
        sort[req.query.sortBy] = req.query.agent === "desc" ? -1 : 1;
    }
    const apiFeature = new ApiFeatures(agent.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let agents = await apiFeature.query;
    let filteredagentCount = agents.length;

    return res.status(200).json({
        status: true,
        totalagent,
        filteredagent: filteredagentCount,
        page: req.query.page,
        limit: resultPerPage,
        agents,
    });
});
// module.exports.getallagents = catchAsyncErrors(async (req, res) => {
//   const agents = await agent.find();
//   const total = await agent.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     agents,
//   });
// })

//getSingle agent

module.exports.getsingleagents = catchAsyncErrors(async (req, res, next) => {
    let agents = await agent.findById(req.params.id);
    if (!agents) {
        return next(new errorhandaler("Agents Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            agents,
        });
    }
});

//Update agent

module.exports.updateagents = catchAsyncErrors(async (req, res) => {

    let id = req.params.id;
    let agents = await agent.findById(id);
    if (!agents) {
        return res.status(404).json({ msg: "Cannot Found Agents.." });
    }
    if (req.body.password) {

        //Encrypt agent password
        var Password = req.body.password;
        encryptedPassword = await bcrypt.hash(Password, 10);

        const data = {
            password: encryptedPassword,
            name: req.body.name || agents.name,
            email: req.body.email || agents.email,
            mobile: req.body.mobile || agents.mobile,
            status: req.body.status || agents.status,
        };
        try {
            const updatedagent = await agent.findByIdAndUpdate(id, data, {
                new: true,
            });
            return res.status(200).json({
                status: true,
                msg: "Updated Successfully....",
                updatedagent,
            });
        } catch (error) {
            res.status(400).json({
                status: false,
                error,
            });
        }
    } else {

        const data = {
            name: req.body.name || agents.name,
            email: req.body.email || agents.email,
            password: agents.password,
            mobile: req.body.mobile || agents.mobile,
            status: req.body.status || agents.status,
        };
        const updateagent = await agent.findByIdAndUpdate(id, data, {
            new: true,
        });
        return res.status(200).json({
            status: true,
            msg: "Updated Successfully...",
            updateagent,
        });
    }
});

//Delete agent

module.exports.deleteagents = catchAsyncErrors(async (req, res) => {
    try {
        const data = await agent.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({
                message: "Agents Not Found"
            });
        }
        return res.status(200).json({
            message:
                "Agents Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({ err });
    }
});
