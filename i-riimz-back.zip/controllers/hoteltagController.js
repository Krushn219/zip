const hoteltag = require("../models/hoteltagModel");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const axios = require('axios');

// create hoteltags

module.exports.createhoteltag = catchAsyncErrors(async (req, res) => {
    const hoteltags = await hoteltag.create(req.body);
    if (!hoteltags) {
        return res.status(500).send("hoteltag Cannot Be Created");
    }
    return res.status(200).json({
        status: true,
        message: "hoteltag create Successfully...",
        hoteltags,
    });
});

//get all hoteltag

module.exports.getallhoteltag = catchAsyncErrors(async (req, res, next) => {

    const resultPerPage = Number(req.query.limit) || 10;
    let totalhoteltag = await hoteltag.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.hoteltag) {
        sort[req.query.sortBy] = req.query.hoteltag === "desc" ? -1 : 1;
    }
    const apiFeature = new ApiFeatures(hoteltag.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let hoteltags = await apiFeature.query;
    let filteredhoteltagCount = hoteltags.length;

    return res.status(200).json({
        status: true,
        totalhoteltag,
        filteredhoteltag: filteredhoteltagCount,
        page: req.query.page,
        limit: resultPerPage,
        hoteltags,
    });
});
// module.exports.getallhoteltag = catchAsyncErrors(async (req, res) => {
//   const hoteltags = await hoteltag.find();
//   const total = await hoteltag.countDocuments();
//   res.status(200).json({
//     status: true,
//     total: total,
//     hoteltags,
//   });
// })

//getSingle hoteltag

module.exports.getsinglehoteltag = catchAsyncErrors(async (req, res, next) => {
    let hoteltags = await hoteltag.findById(req.params.id);
    if (!hoteltags) {
        return next(new errorhandaler("hoteltag Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            hoteltags,
        });
    }
});

// hoteltag By Hotel Id

module.exports.hoteltageByHotel = catchAsyncErrors(async (req, res, next) => {
    let hoteltags = await hoteltag.find({ hotel_id: req.params.hotelId });
    if (!hoteltags) {
        return next(new errorhandaler("hoteltag Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            hoteltags,
        });
    }
});

//Update hoteltag

module.exports.updatehoteltag = catchAsyncErrors(async (req, res) => {

    let id = req.params.id;
    let hoteltags = await hoteltag.findById(id);
    if (!hoteltags) {
        return res.status(404).json({ msg: "Cannot Found hoteltag.." });
    }
    const data = {
        hotel_id: req.body.hotel_id || hoteltags.hotel_id,
        tags: req.body.tags || hoteltags.tags,
        nots: req.body.nots || hoteltags.nots,
    };
    try {
        const updatedhoteltag = await hoteltag.findByIdAndUpdate(id, data, {
            new: true,
        });
        return res.status(200).json({
            status: true,
            msg: "Updated Successfully....",
            updatedhoteltag,
        });
    } catch (error) {
        res.status(400).json({
            status: false,
            error,
        });
    }
});

//Delete hoteltag

module.exports.deletehoteltag = catchAsyncErrors(async (req, res) => {
    try {
        const data = await hoteltag.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({
                message: "hoteltag Not Found"
            });
        }
        return res.status(200).json({
            message:
                "hoteltag Deleted Successfully"
        });
    } catch (err) {
        return res.status(500).json({ err });
    }
});

// hotel filter

module.exports.hoteltagefilter = catchAsyncErrors(async (req, res, next) => {
    try {
        let hoteltags = await hoteltag.find({
            "tags.text": req.params.tags
        });
        const hotellocation = [];
        for (let i = 0; i < hoteltags.length; i++) {
            var hotelid = hoteltags[i].hotel_id
            const config = {
                headers: {
                    "X-SF-API-KEY": process.env.X_SF_API_KEY
                }
            };
            await axios
                .get(
                    `https://api.stayflexi.com/core/api/v1/beservice/hotelcontent?hotelId=${hotelid}`,
                    config,
                    null)
                .then(async function (response) {
                    var city = response.data.city
                    var state = response.data.state
                    var location = `${city}, ${state}`.toLowerCase();
                    hotellocation.push(location);
                })
                .catch(function (error) {
                    return res.status(500).json({
                        message: "Unable To response",
                        error
                    })
                })
        }
        return res.status(200).json({
            status: true,
            data: hotellocation,
        });
    } catch (error) {
        return res.status(500).json({
            message: "Unable To response",
            error
        })
    }
});