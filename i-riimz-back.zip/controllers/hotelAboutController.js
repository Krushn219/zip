const aboutHotel = require("../models/hotelAbout");
const ApiFeatures = require("../utils/apifeatures");
const errorhandaler = require("../utils/errorhandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");

// create About Hotel

module.exports.createHotelAbout = catchAsyncErrors(async (req, res) => {

    const hotels = await aboutHotel.create(req.body);
    if (!hotels) {
        return res.status(500).send("Can Not Create About Hotels...");
    }
    return res.status(200).json({
        status: true,
        hotels,
    });
});

//Get all About Hotel

module.exports.getAllAboutHotel = catchAsyncErrors(async (req, res, next) => {
    const resultPerPage = Number(req.query.limit) || 10;

    let total = await aboutHotel.countDocuments();
    const sort = {};
    // const sort = { createdAt: -1 };

    if (req.query.sortBy && req.query.hotel) {
        sort[req.query.sortBy] = req.query.hotel === "desc" ? -1 : 1;
    }

    const apiFeature = new ApiFeatures(aboutHotel.find().sort(sort), req.query)
        .filter()
        .search()
        .pagination(resultPerPage);
    let about = await apiFeature.query;
    let filteredAboutHotelCount = about.length;

    return res.status(200).json({
        status: true,
        total,
        filteredhotel: filteredAboutHotelCount,
        page: req.query.page,
        limit: resultPerPage,
        data: about,
    });
});

//Get Single About Hotel

module.exports.getSingleAboutHotel = catchAsyncErrors(async (req, res, next) => {
    let hotels = await aboutHotel.findById(req.params.id);
    if (!hotels) {
        return next(new errorhandaler("Hotels Not Found", 404));
    } else {
        return res.status(200).json({
            status: true,
            hotels,
        });
    }
});

//Update hotel

module.exports.updateAboutHotel = catchAsyncErrors(async (req, res) => {
    let id = req.params.id;
    let hotels = await aboutHotel.findById(id);
    if (!hotels) {
        return res.status(404).json({ msg: "Cannot Found Hotels.." });
    }

    const data = {
        hotel_id: req.body.ax_hotel_id || hotels.ax_hotel_id,
        content: req.body.content || hotels.content,

    };
    const updatehotel = await aboutHotel.findByIdAndUpdate(id, data, {
        new: true,
    });
    return res.status(200).json({
        status: true,
        msg: "Updated Successfully...",
        updatehotel,
    });
});

//Delete hotel

module.exports.deleteAboutHotel = catchAsyncErrors(async (req, res) => {
    try {
        const data = await aboutHotel.findByIdAndDelete(req.params.id);
        if (!data) {
            return res.status(400).json({ message: "About Hotel Not Found" });
        }
        return res.status(200).json({ message: "About Hotel Deleted Successfully" });
    } catch (err) {
        return res.status(500).json({ err });
    }
});


module.exports.getAboutHotelByUser = catchAsyncErrors(async (req, res) => {

    try {
        const aboutHotelUser = await aboutHotel.find({ hotel_id: req.params.hotelId })
        if (!aboutHotelUser) {
            return res.status(404).json({
                status: false,
                message: "About Hotel Not Found..."
            })
        }

        const count = aboutHotelUser.length;
        return res.status(200).json({
            status: true,
            total: count,
            data: aboutHotelUser
        });
    } catch (error) {
        return res.status(500).json({
            status: false,
            message: error
        });

    }
})
