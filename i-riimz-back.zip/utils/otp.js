// const generateOTPFunc = () => {

//     // Declare a digits variable 
//     // var OTP = Math.floor(1000 + Math.random() * 999999);
//     // console.log("OTP", OTP);
//     // which stores all digits
//     var digits = '0123456789';
//     let OTP = '';
//     for (let i = 0; i < 6; i++) {
//         OTP += digits[Math.floor(Math.random() * 10)];
//     }
//     return OTP;
// }

// module.exports = generateOTPFunc


const generateOTPFunc = () => {
    var min = 100000;
    var max = 999999;

    var OTP = Math.floor(Math.random() * (max - min + 1)) + min;

    return OTP;

}

module.exports = generateOTPFunc

