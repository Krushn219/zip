const nodemailer = require("nodemailer");
const path = require("path");
const express = require("express");
const app = express();
app.set("view engine", "handlebars");
const smtpTransport = require("nodemailer-smtp-transport");
const hbs = require("nodemailer-express-handlebars");
const viewPath = path.resolve(__dirname, "../templates/views/");
// const { engine } = require("../../dist/index.js"); // "express-handlebars"
// app.engine("handlebars", engine());

// Confirmed booking mail
const sendEmail = async (email, data) => {
    return new Promise((resolve, reject) => {
        try {
            var transporter = nodemailer.createTransport(
                smtpTransport({
                    host: "stmp.gmail.com",
                    port: 587,
                    service: "gmail",
                    requireTLS: true,
                    auth: {
                        type: "OAuth2",
                        user: process.env.SMPT_MAIL,
                        pass: process.env.SMPT_PASSWORD,
                        clientId: process.env.MAILCLIENT_ID,
                        clientSecret: process.env.MAILCLIENT_SECRET,
                        refreshToken: process.env.MAILREFRESH_TOKEN,
                    },
                })
            );
            transporter.use(
                "compile",
                hbs({
                    viewEngine: {
                        extName: ".handlebars",
                        //  : viewPath,
                        layoutsDir: viewPath,
                        defaultLayout: false,
                        // partialsDir: partialsPath,
                        express,
                    },
                    viewPath: viewPath,
                    extName: ".handlebars",
                })
            );

            let from = `${data.hotelName} <noreply@iroomz.in>`

            const mailOptions = {
                from: from,
                to: email,
                subject: "iRoomz Booking Confirmation",
                template: "index",
                // attachments: [
                //   {
                //     filename: "abc.jpg",
                //     path: path.resolve(__dirname, "../image/abc.jpg"),
                //   },
                // ],
                context: {
                    data: data,
                },
            };
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.error("Error sending email:", error);
                    reject(error);
                } else {
                    console.log("Email Sent Successfully");
                    console.log("Email sent: " + info.response);
                    resolve();
                }
            });
        } catch (error) {
            console.error("Error sending email:", error);
            reject(error);
        }
    });
};

// cancelled booking mail
const sendCancelEmail = async (email, data) => {
    return new Promise((resolve, reject) => {
        try {
            var transporter = nodemailer.createTransport(
                smtpTransport({
                    host: "stmp.gmail.com",
                    port: 587,
                    service: "gmail",
                    requireTLS: true,
                    auth: {
                        type: "OAuth2",
                        user: process.env.SMPT_MAIL,
                        pass: process.env.SMPT_PASSWORD,
                        clientId: process.env.MAILCLIENT_ID,
                        clientSecret: process.env.MAILCLIENT_SECRET,
                        refreshToken: process.env.MAILREFRESH_TOKEN,
                    },
                })
            );
            transporter.use(
                "compile",
                hbs({
                    viewEngine: {
                        extName: ".handlebars",
                        layoutsDir: viewPath,
                        defaultLayout: false,
                        express,
                    },
                    viewPath: viewPath,
                    extName: ".handlebars",
                })
            );

            let from = `${data.hotelName} <noreply@iroomz.in>`

            const mailOptions = {
                from: from,
                to: email,
                subject: "iRoomz  Booking Cancellation",
                template: "cancel",
                context: {
                    data: data,
                },
            };
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.error("Error sending email:", error);
                    reject(error);
                } else {
                    console.log("Email Sent Successfully");
                    console.log("Email sent: " + info.response);
                    resolve();
                }
            });
        } catch (error) {
            console.error("Error sending email:", error);
            reject(error);
        }
    });
};
module.exports = { sendEmail, sendCancelEmail };

