const moment = require('moment');

const date_IST = () => {
    var date = new Date()
    var date_now = moment(date).add(330, 'minutes').toDate();

    return date_now;

}

module.exports = date_IST