const handlebars = require('handlebars');

handlebars.registerHelper('sum', function (a, b) {
    const num1 = parseInt(a);
    const num2 = parseInt(b);
    return num1 + num2;
});
handlebars.registerHelper('_toInt', function (str) {
    return parseInt(str, 10);
});
handlebars.registerHelper('or', function (a, b, options) {
    if (a || b) {
        return options.fn(this);
    } else {
        return options.inverse(this);
    }
})
// less than or equal to
handlebars.registerHelper('le', function (a, b) {
    var next = arguments[arguments.length - 1];
    return (a >= b) ? next.fn(this) : next.inverse(this);
});