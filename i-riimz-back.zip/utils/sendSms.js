const axios = require('axios')
const ErrorHandler = require("../utils/errorhandler");

// "API KEY "- "lnJIHMuL"
// "Entity ID" - 1201160863469758957
// "Entity Name" - i roomz india pvt ltd
// "Sender Id / Header" - iroomz
// "Template Id" - 1207162555283944528

const sendSms = async (mobile, otp) => {
    try {
        // url = `https://api.onex-aura.com/api/sms?key=lnJIHMuL&to=${mobile}&from=iroomz&body=Dear User, ${otp} is your one-time password (OTP). Please enter the OTP to proceed. Thank You, Team iRoomz&entityid=1201160863469758957&templateid=1207162555283944528`

        url = `https://api.onex-aura.com/api/sms?key=NALVxpwJ&to=${mobile}&from=iroomz&body=Dear Guest,
${otp} is your one time password. Please enter the OTP to proceed.
Thank you,
Team Iroomz india pvt ltd.&entityid=1201160863469758957&templateid=1207165769323735841`
        await axios.get(url,
            {
                withCredentials: true,
                headers: {
                    "Content-Type": "application/json",
                    'charset': "utf-8"
                }
            },
        )
            .then((res) => {
                // console.log("response", res)

                if (res.data.status == 100) {
                    console.log("response", res.data)
                }
                else {
                    console.log("res", res.data)
                    throw new Error(res.data.description);
                }
            })
            .catch((error) => {
                console.error("error", error)
            })
    } catch (error) {
        console.error(error)
    }
}
module.exports = sendSms;

