const nodemailer = require("nodemailer");
const smtpTransport = require("nodemailer-smtp-transport");
const forgetEmail = async (email) => {
    return new Promise((resolve, reject) => {
        try {
            const transporter = nodemailer.createTransport(
                smtpTransport({
                    host: "stmp.gmail.com",
                    port: 587,
                    service: "gmail",
                    requireTLS: true,
                    auth: {
                        type: "OAuth2",
                        user: process.env.SMPT_MAIL,
                        pass: process.env.SMPT_PASSWORD,
                        clientId: process.env.MAILCLIENT_ID,
                        clientSecret: process.env.MAILCLIENT_SECRET,
                        refreshToken: process.env.MAILREFRESH_TOKEN,
                    },
                })
            );
            // const url = `http://localhost:3002/forgotPassword`;
            const url = `http://159.89.161.90:3000/forgotPassword`;
            let from = `i-roomz`;

            const mailConfigurations = {
                from: from || process.env.SMPT_MAIL,
                to: email,
                subject: "For forget password",
                html: `please click the link <a  href=${url}> ${url}</a> and reset Your password`,
            };

            transporter.sendMail(mailConfigurations, (error, info) => {
                if (error) {
                    console.error("Error sending email:", error);
                    reject(error);
                } else {
                    console.log("Email Sent Successfully");
                    console.log("Email sent: " + info.response);
                    resolve();
                }
            });
        } catch (error) {
            console.error("Error sending email:", error);
            reject(error);
        }
    });
};

const reviewEmail = async (email, hotel_id, hotel_name) => {
    console.log("email@@@@@@", email)
    return new Promise((resolve, reject) => {
        try {
            const transporter = nodemailer.createTransport(
                smtpTransport({
                    host: "stmp.gmail.com",
                    port: 587,
                    service: "gmail",
                    requireTLS: true,
                    auth: {
                        type: "OAuth2",
                        user: process.env.SMPT_MAIL,
                        pass: process.env.SMPT_PASSWORD,
                        clientId: process.env.MAILCLIENT_ID,
                        clientSecret: process.env.MAILCLIENT_SECRET,
                        refreshToken: process.env.MAILREFRESH_TOKEN,
                    },
                })
            );
            // const url = `http://localhost:3000/rating-review/${hotel_id}`;
            const url = `http://159.89.161.90:3000/rating-review/${hotel_id}`;

            let from = `${hotel_name} <noreply@iroomz.in>`

            const mailConfigurations = {
                from: from,
                to: email,
                subject: "For Hotel Review & Rating",
                // html: `please click the <a  href=${url}>link</a> to review our service`,
                html: `please click the link <a  href=${url}> ${url}</a> to review our service`,
            };

            transporter.sendMail(mailConfigurations, (error, info) => {
                if (error) {
                    console.error("Error sending email:", error);
                    reject(error);
                } else {
                    console.log("Email Sent Successfully");
                    console.log("Email sent: " + info.response);
                    resolve();
                }
            });
        } catch (error) {
            console.error("Error sending email:", error);
            reject(error);
        }
    });

};

const serviceEmail = async (email, hotel_id, hotel_name) => {
    return new Promise((resolve, reject) => {
        try {
            const transporter = nodemailer.createTransport(
                smtpTransport({
                    host: "stmp.gmail.com",
                    port: 587,
                    service: "gmail",
                    requireTLS: true,
                    auth: {
                        type: "OAuth2",
                        user: process.env.SMPT_MAIL,
                        pass: process.env.SMPT_PASSWORD,
                        clientId: process.env.MAILCLIENT_ID,
                        clientSecret: process.env.MAILCLIENT_SECRET,
                        refreshToken: process.env.MAILREFRESH_TOKEN,
                    },
                })
            );
            // const url = `http://localhost:3000/review-within-stay/22629`;
            const url = `http://159.89.161.90:3000/review-within-stay/${hotel_id}`;

            let from = `${hotel_name} <noreply@iroomz.in>`

            const mailConfigurations = {
                from: from,
                to: email,
                subject: "For review our service",
                // html: `please click the <a  href=${url}>link</a> to review our service`,
                html: `please click the link <a href=${url}> ${url}</a> to review our service`,
            };
            transporter.sendMail(mailConfigurations, (error, info) => {
                if (error) {
                    console.error("Error sending email:", error);
                    reject(error);
                } else {
                    console.log("Email Sent Successfully");
                    console.log("Email sent: " + info.response);
                    resolve();
                }
            });
        } catch (error) {
            console.error("Error sending email:", error);
            reject(error);
        }
    });
};

module.exports = { forgetEmail, reviewEmail, serviceEmail };
