const socket = io();

var userName;

var chats = document.querySelector(".chats");
var usersList = document.querySelector(".user-list");
var usersCount = document.querySelector(".users-count");
var userMsg = document.querySelector("#user-msg");
var msgSend = document.querySelector("#user-send");

do {
    userName = prompt("Enter your name...");
} while (!userName);

/****** Joining new user */
socket.emit("New user Joined..", userName);

/****** Notifying joining of user */
socket.on('user-connected', (socket_name) => {
    userJoinLeft(socket_name, 'joined');
})

/********** Function to create join/left status */
function userJoinLeft(name, status) {
    let div = document.createElement("div");
    div.classList.add('user-join');
    let content = `<p><b>${name}</b>&nbsp&nbsp${status} the chat</p>`;
    div.innerHTML = content;
    chats.appendChild(div);
    chats.scrollTop=chats.scrollHeight;
}

/*********  Notifying user has left */
socket.on('user-disconnected', (user) => {
    userJoinLeft(user, 'left');
})

/******* for updating userList and userCount */
socket.on('user-list',(users)=>{
    usersList.innerHTML="";
    users_arr = Object.values(users);
    for(i=0; i<users_arr.length; i++){
        let p = document.createElement('p');
        p.innerText=users_arr[i];
        usersList.appendChild(p);
    }
    usersCount.innerHTML=users_arr.length;
})


/************ For sending massages */
msgSend.addEventListener('click',()=>{
    let data = {
        user : userName,
        msg: userMsg.value
    };
    if(userMsg.value != ''){
        appendMessage(data,'outgoing');
        socket.emit('message',data);
        userMsg.value = '';
    }
});

function appendMessage(data,status){
    let div = document.createElement('div');
    div.classList.add('message',status);
    let content = `
        <h5>${data.user}<h5>
        <p>${data.msg}</p>
    `;
    div.innerHTML=content;
    chats.appendChild(div);
    chats.scrollTop=chats.scrollHeight;
}


socket.on('message',(data)=>{
    appendMessage(data,'incoming')
})
