const express = require('express');
const http = require('http')
const port = process.env.PORT || 4000;
const app = express();
const path = require('path');
const { createServer } = require("http");
const server = http.createServer(app)
const { Server } = require("socket.io");


app.use(express.static(__dirname + '/public'))

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html')
})


/* Socket.io Setup */

const io = new Server(server);
var users = {};

io.on('connection', (socket) => {
    // console.log(socket.id);
    socket.on("New user Joined..",(userName)=>{
        users[socket.id]=userName;
        // console.log(users);
        socket.broadcast.emit("user-connected",userName);
        io.emit("user-list",users);
    })

    socket.on("disconnect",()=>{
        socket.broadcast.emit('user-disconnected',user=users[socket.id]);
        delete users[socket.id];
        io.emit("user-list",users);
    })

    socket.on("message",(data)=>{
        socket.broadcast.emit("message",{user: data.user, msg: data.msg});
    })

});


/* Socket.io Setup End */




server.listen(port, function (err) {
    if (err) {
        console.log("Cannot connect server");
    }
    console.log("Server is running on port::", port)
})