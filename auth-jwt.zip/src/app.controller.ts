import { Controller, Get, Post, Request, UseGuards } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { AuthService } from './auth/auth.service';
import { RoleGuard } from './role.guard';
import { CONSTANTS } from './user/constants';

@Controller('app')
export class AppController {
  constructor(private authService: AuthService) {}

  @Post('login')
  @UseGuards(AuthGuard('local'))
  // login(): string {
  //   return 'login Route';
  // }
  login(@Request() req): string {
    const token = this.authService.generateToken(req.user);
    // return req.user;
    return token;
  }

  @Get('android-developer')
  @UseGuards(AuthGuard('jwt'), new RoleGuard(CONSTANTS.ROLES.ANDROID_DEVELOPER))
  androidDeveloperData(@Request() req): string {
    return (
      'This is private Data for Android Developer' + JSON.stringify(req.user)
    );
  }

  @Get('web-developer')
  @UseGuards(AuthGuard('jwt'), new RoleGuard(CONSTANTS.ROLES.WEB_DEVELOPER))
  webDeveloperData(@Request() req): string {
    return 'This is private Data for Web Developer' + JSON.stringify(req.user);
  }
}
