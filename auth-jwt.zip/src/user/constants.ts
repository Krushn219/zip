export const CONSTANTS = {
  ROLES: {
    ANDROID_DEVELOPER: 'android-developer',
    WEB_DEVELOPER: 'web-developer',
    IOS_DEVELOPER: 'ios-developer',
  },
};
