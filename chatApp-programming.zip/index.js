const dotenv = require("dotenv");
dotenv.config();
const express = require("express");
const port = process.env.PORT || 5000;
const app = express();
const http = require("http").Server(app);
const db = require("./config/database");
const bodyParser = require("body-parser");
const path = require("path");
const session = require("express-session");
const { SESSION_SECRET } = process.env;

const userRoutes = require("./routes/userRoute");

const User = require("./models/User");
const Chat = require("./models/Chat");

// View Engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "js")));

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded());
app.use(express.json());

app.use(express.static(__dirname + "/public"));
app.use("/public/images", express.static("/public/images"));

// Session
app.use(session({ secret: SESSION_SECRET }));

// app.get("/", (req, res) => {
//   return res.send("Welcome To Home Page...");
// });

app.use("/user", userRoutes);

// Socket
const io = require("socket.io")(http);

var usp = io.of("/user-namespace");

usp.on("connection", async function (socket) {
  console.log("User connected..");

  var userId = socket.handshake.auth.token;

  await User.findByIdAndUpdate({ _id: userId }, { $set: { is_online: "1" } });

  // User Broadcast online status
  socket.broadcast.emit("getOnlineUser", { user_id: userId });

  socket.on("disconnect", async function () {
    console.log("User Disconnected...");
    var userId = socket.handshake.auth.token;

    await User.findByIdAndUpdate({ _id: userId }, { $set: { is_online: "0" } });

    // User Broadcast offline status
    socket.broadcast.emit("getOfflineUser", { user_id: userId });
  });

  // Chatting implementation
  socket.on("newChat", function (data) {
    socket.broadcast.emit("loadNewChat", data);
  });

  // Load old Chats
  socket.on("existChat", async function (data) {
    var chats = await Chat.find({
      $or: [
        { sender_id: data.sender_id, receiver_id: data.receiver_id },
        { sender_id: data.receiver_id, receiver_id: data.sender_id },
      ],
    });

    socket.broadcast.emit("loadChats", { chats: chats });
  });
});

http.listen(port, (error) => {
  if (error) {
    console.log("Something went wrong..");
  }
  console.log("App is running on Port::", port);
});
