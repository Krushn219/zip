const User = require("../models/User");
const Chat = require("../models/Chat");
const bcrypt = require("bcrypt");

module.exports.home = async (req, res) => {
  return res.send("Welcome To User Controller...");
};

module.exports.registerLoad = async (req, res) => {
  try {
    res.render("register");
  } catch (error) {
    return res.status(404).json({
      success: false,
      message: error.message,
    });
  }
};

module.exports.register = async (req, res) => {
  try {
    const hashPassword = await bcrypt.hash(req.body.password, 10);

    const user = await User.create({
      name: req.body.name,
      email: req.body.email,
      password: hashPassword,
      image: "images/" + req.file.filename,
    });

    if (user) {
      return res.render("register", { message: "Registered Successfully..." });
    }
  } catch (error) {
    return res.status(404).json({
      success: false,
      message: error.message,
    });
  }
};

module.exports.loadLogin = async (req, res) => {
  try {
    res.render("login");
  } catch (error) {
    console.log(error.message);
  }
};

module.exports.login = async (req, res) => {
  try {
    const email = req.body.email;
    const password = req.body.password;

    const userData = await User.findOne({ email: email });

    if (userData) {
      const passwordMatch = bcrypt.compare(password, userData.password);
      if (passwordMatch) {
        req.session.user = userData;

        return res.redirect("/user/dashboard");
      } else {
        res.render("login", { message: error.message });
      }
    } else {
      res.render("login", { message: error.message });
    }
  } catch (error) {
    console.log(error.message);
  }
};

module.exports.logout = async (req, res) => {
  try {
    req.session.destroy();
    return res.redirect("/user/login");
  } catch (error) {
    console.log(error.message);
  }
};

module.exports.dashboard = async (req, res) => {
  try {
    const users = await User.find({ _id: { $nin: [req.session.user._id] } });
    // console.log("users.....", users);
    res.render("dashboard", { user: req.session.user, users: users });
  } catch (error) {
    console.log(error.message);
  }
};

module.exports.saveChat = async (req, res) => {
  try {
    var chat = new Chat({
      sender_id: req.body.sender_id,
      receiver_id: req.body.receiver_id,
      message: req.body.message,
    });

    var newChat = await chat.save();
    res.status(201).send({
      success: true,
      msg: "Chat Inserted...",
      data: newChat,
    });
  } catch (error) {
    res.status(400).send({
      success: false,
      msg: error.message,
    });
  }
};
