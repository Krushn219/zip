const express = require("express");

const router = express.Router();

const userController = require("../controllers/userController");
const { upload } = require("../utils/multer");

const auth = require("../middleware/auth");

router.get("/", userController.home);

router.get("/register", auth.isLogout, userController.registerLoad);
router.post("/register", upload, userController.register);

router.get("/login", auth.isLogout, userController.loadLogin);
router.post("/login", userController.login);
router.get("/logout", auth.isLogin, userController.logout);

router.get("/dashboard", auth.isLogin, userController.dashboard);
router.post("/save-chat", auth.isLogin, userController.saveChat);

router.get("*", (req, res) => {
  res.redirect("/login");
});

module.exports = router;
