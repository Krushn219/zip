from django.db import models

# Create your models here.
class ContactEnquiry(models.Model):
    form_name = models.CharField(max_length=50)
    form_email = models.CharField(max_length=30)
    form_subject = models.CharField(max_length=50)
    form_message = models.TextField()
