from django.contrib import admin

# Register your models here.

from contactEnquiry.models import ContactEnquiry

class ContactEnquiryAdmin(admin.ModelAdmin):
     list_display = ('form_name','form_email','form_subject','form_message')
     
admin.site.register(ContactEnquiry,ContactEnquiryAdmin)
