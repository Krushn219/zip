from django.contrib import admin

# Register your models here.
# from vege.models import Receipe,Department,StudentId,Student
from vege.models import *
from django.db.models import Sum

class ReceipeAdmin(admin.ModelAdmin):
    list_display = ['receipe_name','receipe_description','receipe_image','is_deleted']

class StudentAdmin(admin.ModelAdmin):
    list_display = ['student_name','student_email','student_age']
    
class SubjectMarksAdmin(admin.ModelAdmin):
    list_display = ['student','subject','marks']
    
class ReportCardAdmin(admin.ModelAdmin):
    list_display = ['student','student_rank','total_marks','date_of_report_card_generation']
    ordering = ['student_rank']
    def total_marks(self, obj):
        subject_marks = SubjectMarks.objects.filter(student = obj.student)
        marks = (subject_marks.aggregate(marks = Sum('marks')))
        return marks['marks']

admin.site.register(Receipe,ReceipeAdmin)

admin.site.register(StudentId)
admin.site.register(Student,StudentAdmin)
admin.site.register(Department)

admin.site.register(Subject)
admin.site.register(SubjectMarks,SubjectMarksAdmin)
admin.site.register(ReportCard,ReportCardAdmin)
