from django.shortcuts import render
from vege.models import Student


# Create your views here.

def receipe(request):
    
    return render(request,"receipe.html")

def get_student(req):
    querySet = Student.objects.all()
    context = {'student':querySet}
    return render(req,"student.html",context)
