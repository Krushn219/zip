"""
URL configuration for onepagewebsite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from onepagewebsite import views
from django.conf import settings
from django.conf.urls.static import static #To show images
# from vege import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.homePage,name = "home"),
    path('about/',views.aboutUs,name = "about"),
    path('service/',views.service, name = "service"),
    path('contact/',views.contact, name = "contact"),
    path('booking/',views.booking, name = "booking"),
    path('team/',views.team, name = "team"),
    path('testimonial/',views.testimonial,name = "testimonial"),
    path('404/',views.notfound,name = "404"),
    path('userform',views.userForm),
    path('calculator',views.calculator),
    path('marksheet',views.marksheet),
    # path('news/<newsId>',views.newsDetails), // Before slug
    path('news/<slug>',views.newsDetails),
    path('saveInquiry/',views.saveInquiry,name = "saveInquiry"),
    
    path('receipes/',views.receipes, name = "receipes"),
    path('delete_receipe/<int:id>/',views.delete_receipe, name = "delete_receipe"),
    path('update_receipe/<int:id>/',views.update_receipe, name = "update_receipe"),
    
    path('register/',views.register, name = "register"),
    path('login/',views.login_page, name = "login_page"),
    path('logout/',views.logout_page, name = "logout_page"),
    
    # Student
    path('students/',views.get_student, name = "students"),
    path('see-marks/<student_id>/',views.see_marks, name = "see-marks"),
    path('send_email/',views.send_email, name = "send_email"),
    
    
    
    
    # path('course/<int:courseId>',views.courseDetails)
]

if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
