
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render
from .forms import usersForm
from service.models import Service
from news.models import News
# from vege.models import Receipe
from vege.models import *
# from cars.models import *
from django.core.paginator import Paginator
from contactEnquiry.models import ContactEnquiry
from django.core.mail import send_mail,EmailMultiAlternatives
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required

# from django.contrib.auth import get_user_model 
# User = get_user_model()


# def homePage(req):
#     serviceData = Service.objects.all()
#     # serviceData = Service.objects.all().order_by('service_title')
#     # serviceData = Service.objects.all().order_by('service_title')[:2] // To apply Limit
    
#     # To Filter
#     if req.method == "GET":
#         title = req.GET.get('service')
#         if title != None :
#             # serviceData = Service.objects.filter(service_title = title)
#             serviceData = Service.objects.filter(service_title__icontains = title)
    
 
#     newsData = News.objects.all()
#     data = {
#         'serviceData' :serviceData,
#         'newsData' : newsData
#     }
#     return render(req,"index.html",data)

# ________________________________ Pagination __________________
# For pagination
def homePage(req):
    # Cars.objects.create(car_name = f'Nexon-{random.randint(0,100)}') # To Use Signals
    
    # Without HTML Data
    # send_mail(
    #     "Testing",
    #     "mail from Djnago.",
    #     "krushn.219@gmail.com",
    #     ["drashtigreewebsolutions@gmail.com"],
    #     fail_silently=False,
    # )   
    
    # With HTML Data
    subject = 'Testing'
    from_email = 'krushn.219@gmail.com'
    # to = 'drashtigreewebsolutions@gmail.com'
    to = 'drashtivirani4@gmail.com'
    html_content = "<p>This is an <strong>important</strong> message.</p>"
    msg = EmailMultiAlternatives(subject, html_content, from_email, [to])
    msg.content_subtype = 'html'
    msg.send()
    
    serviceData = Service.objects.all()
    
    # Pagination
    pagination = Paginator(serviceData,2)
    page = req.GET.get('page')
    serviceData = pagination.get_page(page)
    totalPage = serviceData.paginator.num_pages
 
    newsData = News.objects.all()
    data = {
        'serviceData' :serviceData,
        'newsData' : newsData,
        'lastPage' : totalPage,
        'totalPage':[n+1 for n in range(totalPage)]
    }
    return render(req,"index.html",data)
    
 
# def newsDetails(req,newsId):  // Before slug 
def newsDetails(req,slug):   
    # newsData = News.objects.get(id=newsId) // Before slug
    newsData = News.objects.get(news_slug=slug)
    data ={
        'newsData' : newsData
    }
    return render(req,"newsdetails.html",data)

#  Before Dynamic ---------------------------------
# def homePage(req):
#     # data = {
#     #     'title':'Home Page',
#     #     'clist':['PHP','Java','Django'],
#     #     'student':[
#     #         {'name':'Krishna','phone':9099590111},
#     #         {'name':'Test','phone':9099590000}
#     #     ],
#     #     'numbers':[10,20,30,40,50]
#     # }
#     return render(req,"index.html")

def aboutUs(req):
    return render(req,"about.html")

def service(req):
    return render(req,"service.html")

def contact(req):
    return render(req,"contact.html")

def booking(req):
    return render(req,"booking.html")

def team(req):
    return render(req,"team.html")

def testimonial(req):
    return render(req,"testimonial.html")

def notfound(req):
    return render(req,"404.html")

def userForm(req):
    fn = usersForm()
    data={'from':fn}
    try:
        if req.method == "POST":
            name = req.POST.get('name')
            email = req.POST.get('email')
            subject = req.POST.get('subject')
            message = req.POST.get('message')
            # data={
            #     name,
            #     email,
            #     subject,
            #     message
            # }
            data={
                'form':fn
            }
            
            return HttpResponseRedirect('/userform',data)
            # url = "/userform/?data={}".format(data)
            # return HttpResponseRedirect(url)
            
        
    except:
        pass
    
    # name =req.GET['name']
    #         print(name)
    #         email = req.GET['email']
    #         subject = req.GET['subject']
    #         message = req.GET.get('message')
    #         data = {name,email,subject,message}
    
    return render(req,"userform.html",data)


def calculator(req):
    c =''
    try:
        if req.method == "POST":
            val1 = eval(req.POST.get('val1'))
            val2 = eval(req.POST.get('val2'))
            opr = req.POST.get('operator')
            
            if opr == "+":
                c = val1 + val2
            elif opr == "-":
                c = val1 - val2
            elif opr == "*":
                c = val1 * val2
            elif opr == "/":
                c = val1 / val2
    except :
        c = "Invalid Opr...."
        
    print(c)
    return render(req,'calculator.html',{'data':c})
    
    
def marksheet(req):
    if req.method == "POST":
        if req.POST.get('sub1') or req.POST.get('sub2') or req.POST.get('sub3') or req.POST.get('sub4') or req.POST.get('sub5') == '':
            return render(req,"marksheet.html",{'error':True})
        if eval(req.POST.get('sub1') or req.POST.get('sub2') or req.POST.get('sub3') or req.POST.get('sub4') or req.POST.get('sub5')) > 100 :
            # data={
            #     'e':"please enter valid numbers"
            # }
            # return render(req,"marksheet.html",data)
            return render(req,"marksheet.html",{'error':True})
            
        
        elif eval(req.POST.get('sub1') and req.POST.get('sub2') and req.POST.get('sub3') and req.POST.get('sub4') and req.POST.get('sub5')) < 35:
            data={
                'division' : "Better Luck Next Time.."
            }
            return render(req,"marksheet.html",data)
        else:
            s1 = eval(req.POST.get('sub1'))
            s2 = eval(req.POST.get('sub2'))
            s3 = eval(req.POST.get('sub3'))
            s4 = eval(req.POST.get('sub4'))
            s5 = eval(req.POST.get('sub5'))
            
            t = s1+s2+s3+s4+s5
            p = t * 100 /500
            
            if p>70 and p<100:
                d = "Distinction"
            elif p>60 and p<70:
                d = "First"
            elif p>45 and p<60:
                d = "Second"
            elif p>35 and p<45:
                d = "Third"
            else:
                d = "Better Luck Next Time.."
                
            data ={
                'total':t,
                'percentage':p,
                'division':d
            }
            return render(req,"marksheet.html",data)
    return render(req,"marksheet.html")


def saveInquiry(req):
    msg = ''
    if req.method == "POST":
        name = req.POST.get('name')
        email = req.POST.get('email')
        subject = req.POST.get('subject')
        message = req.POST.get('message')
        data = ContactEnquiry(form_name=name,form_email=email,form_subject=subject,form_message=message)
        data.save()
        msg = "Inserted Successfully..."
    return render(req,"contact.html",{'msg':msg})
# ---------------- Receipes ---------------------
    
@login_required(login_url='/login/')
def receipes(req):
    if req.method == "POST":
        
        #Create
        data = req.POST
        receipe_name = data.get('receipe_name')
        receipe_description = data.get('receipe_description')
        receipe_image = req.FILES.get('receipe_image')
        Receipe.objects.create(
            receipe_name = receipe_name,
            receipe_description = receipe_description,
            receipe_image = receipe_image
        )
        return HttpResponseRedirect('/receipes/')
    
    # querySet = Receipe.objects.all()  #before ReceipeManager in models.py
    querySet = Receipe.admin_objects.all()
    
    #Search
    if req.GET.get("search"):
        querySet = querySet.filter(receipe_name__icontains = req.GET.get("search"))
    
    context = {'receipes':querySet}   
    # return render(req,'receipe.html',context)
    return render(req,'receipes/receipe.html',context)

def delete_receipe(req,id):
    # querySet = Receipe.objects.get(id = id) #before ReceipeManager in models.py
    querySet = Receipe.admin_objects.get(id = id)
    querySet.delete()
    return HttpResponseRedirect('/receipes/')

def update_receipe(req,id):
    # querySet = Receipe.objects.get(id = id) #before ReceipeManager in models.py
    querySet = Receipe.admin_objects.get(id = id) 
    
    if req.method == "POST":
        data = req.POST
        
        receipe_name = data.get('receipe_name')
        receipe_description = data.get('receipe_description')
        receipe_image = req.FILES.get('receipe_image')
        
        querySet.receipe_name = receipe_name
        querySet.receipe_description = receipe_description
        if receipe_image:
            querySet.receipe_image = receipe_image
        
        querySet.save()
        return HttpResponseRedirect('/receipes/')
    context = {'receipe':querySet}
    return render(req,"receipes/update_receipe.html",context)
 
# ---------------- User ---------------------
 
def register(req):   
    if req.method == "POST":
        first_name = req.POST.get("first_name") 
        last_name = req.POST.get("last_name") 
        username = req.POST.get("user_name") 
        password = req.POST.get("password") 
        
        user = User.objects.filter(username = username)
        if user.exists():
            messages.error(req, "User Already Exists...")
            return HttpResponseRedirect('/register/')
        
        
        user = User.objects.create(
            first_name=first_name,
            last_name=last_name,
            username=username,
        )
        user.set_password(password)
        user.save()
        messages.error(req, "Account Created Successfully...")
        return HttpResponseRedirect('/register/')
    return render(req,'register.html')
   
def login_page(req):    
    if req.method == "POST":
        
        username = req.POST.get("name") 
        password = req.POST.get("password") 
        
        if not User.objects.filter(username = username).exists():
            
            messages.error(req, "Invalid Username...")
            return HttpResponseRedirect('/login/')
        
        user = authenticate(username = username, password = password)
        
        if user is None:
            messages.error(req, "Invalid Credentials...")
            return HttpResponseRedirect('/login/')
        else:
            login(req,user)
            return HttpResponseRedirect('/receipes/')
        
    return render(req,'login.html')

def logout_page(req):
    logout(req)
    return HttpResponseRedirect('/login/')
 
 
 #------------------------- Student ----------------------------------
from django.db.models import Q, Sum
def get_student(req):
    querySet = Student.admin_objects.all()
    # querySet = Student.objects.all() #before StudentManager in models.py(custom object manager)
    
    # Search
    if req.GET.get('search'):
        search = req.GET.get('search')
        # querySet= querySet.filter(student_name__icontains = search)
        
        querySet= querySet.filter(
            Q(student_name__icontains = search) |
            Q(department__department__icontains = search) |
            Q(student_id__student_id__icontains = search) |
            Q(student_email__icontains = search) 
            )
    
    # Pagination
    paginator = Paginator(querySet, 10)  # Show 10 contacts per page.
    page_number = req.GET.get("page",1)
    page_obj = paginator.get_page(page_number)
    studentPage = page_obj.paginator.num_pages
    
    context = {
        'students':page_obj,
        'lastPage' : studentPage,
        'studentPage':[n+1 for n in range(studentPage)]
        }
    return render(req,"reports/student.html",context)

from vege.seed import generate_report_card
def see_marks(req,student_id):
    # generate_report_card() # To generate report card , use only once 
    querySet = SubjectMarks.objects.filter(student__student_id__student_id = student_id)
    total_marks = querySet.aggregate(total_marks = Sum('marks'))
    
    context = {
        'students':querySet,
        'total_marks':total_marks,
        }
    return render(req,'reports/see_marks.html',context)

from vege.utils import send_email_to_client,send_email_with_attachment
from django.conf import settings
def send_email(req):
    # send_email_to_client()
    
    # Mail With Attachment
    
    subject = "This email is from django server with Attachment"
    messages = "Hey please find this attach file with email"
    recipient_list = ['drashtigreewebsolutions@gmail.com']
    file_path = f"{settings.BASE_DIR}/abc.jpg"
    
    send_email_with_attachment(subject,messages,recipient_list,file_path)
    
    return HttpResponseRedirect('/students/')
    
def courseDetails(req,courseId):
    return HttpResponse(courseId)