from django.contrib import admin

# Register your models here.
from news.models import News

class NewsAdmin(admin.ModelAdmin):
    list_display = ('news_title','news_description','news_image')

admin.site.register(News,NewsAdmin)
