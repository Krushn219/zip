from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,JsonResponse
from .models import *
import random

def home(req):
    # return HttpResponse("Hello From Django...")
    querySet = Category.objects.all()
    if req.GET.get('category'):
        return HttpResponseRedirect(f"/quiz/?category = {req.GET.get('category')}")
    context = {'categories':querySet}
    return render(req,'home.html',context)

def quiz(req):
    context = {'category' : req.GET.get('category')}
    return render(req,'quiz.html',context)

def get_quiz(req):
    try:
        question_objs = Questions.objects.all()
        
        if req.GET.get('category'):
            question_objs = question_objs.filter(category__category_name__icontains = req.GET.get('category'))
            print(question_objs)
        question_objs = list(question_objs)
        random.shuffle(question_objs)
        data = []
        for question_obj in question_objs:
            data.append({
                "uid":question_obj.uid,
                "category" :question_obj.category.category_name,
                "question" :question_obj.question,
                "marks" :question_obj.marks,
                "answers":question_obj.get_answers()
            })
            
        payload = {'status' :True, 'data' :data}
        return JsonResponse(payload)
        
        
    except Exception as e:
        print(e)
        return HttpResponse("Something went wrong")
