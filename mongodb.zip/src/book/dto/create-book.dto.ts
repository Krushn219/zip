export class CreateBookDto {
  title: string;
  author: string;
  published: number;
}
