import { Module } from '@nestjs/common';
import { PostgresDataSource } from '/home/hp/Documents/Krushnavandan/Learning/NewTech/Nest.js/nest-postgres-typeorm/src/providers/database.provider';

@Module({
  imports: [],
  providers: [],
  exports: [],
})
export class DatabaseModule {}
