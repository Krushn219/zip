export enum StatusEnum {
  Suggestion = 'suggestion',
  live = 'live',
  InProgress = 'in-progress',
  Planned = 'planned',
}
