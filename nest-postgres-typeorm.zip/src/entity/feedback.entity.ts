import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';
import { StatusEnum } from '/home/hp/Documents/Krushnavandan/Learning/NewTech/Nest.js/nest-postgres-typeorm/src/models/data.model';

@Entity()
export class Feedback {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  title: string;

  @Column({ type: 'enum', enum: StatusEnum, default: StatusEnum.Suggestion })
  status: string;

  @Column({ default: 0 })
  upVotes: number;

  @Column('text', { default: '' })
  description: string;

  @Column({ default: 0 })
  comments: number;
}
