export class BookEntity {
  id: number;
  title: string;
  price: number;
}
