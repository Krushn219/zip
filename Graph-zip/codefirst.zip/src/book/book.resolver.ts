import { Query, Resolver } from '@nestjs/graphql';
import { Book } from './book.schema';

@Resolver((of) => Book)
export class BookResolver {
  @Query((returns) => [Book], { name: 'books' })
  getAllBooks() {
    return [
      { id: 1, title: 'Harry Potter', price: 500 },
      { id: 2, title: 'Robbin Hood', price: 700 },
      { id: 3, title: 'Hunger Games', price: 900 },
    ];
  }
}
