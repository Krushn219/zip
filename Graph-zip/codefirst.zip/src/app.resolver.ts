import { Query } from '@nestjs/graphql';

export class AppResolver {
  @Query((returns) => String)
  index(): string {
    return 'NestJs Graphql Server';
  }
}
