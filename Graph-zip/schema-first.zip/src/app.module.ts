import { ApolloDriver } from '@nestjs/apollo';
import { Module } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { BookModule } from './book/book.module';

@Module({
  imports: [
    GraphQLModule.forRoot({
      driver: ApolloDriver,
      playground: true, // only while using local in production this should be false
      typePaths: ['./**/*.graphql'], //only use at schemaFirst Approach
    }),
    BookModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}
